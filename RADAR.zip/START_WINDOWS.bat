@echo off
REM Zapusk spravochnika v Windows: dvazhdy shchelknite etot fayl.
call "%~dp0scripts\start_windows.bat"
