"""Надёжный запуск справочника одной командой: python run.py

Что делает:
  1. проверяет версию Python и наличие зависимостей (понятное сообщение, если чего-то нет);
  2. проверяет, что модель загружается (при несовместимости версий библиотек — переобучает её);
  3. находит свободный порт (8000, затем 8001…); если справочник уже запущен — просто открывает браузер;
  4. слушает одновременно 127.0.0.1 и ::1, поэтому адрес http://localhost:8000 открывается
     в любом браузере (Windows часто сначала пробует IPv6);
  5. открывает браузер только ПОСЛЕ того, как сервер начал отвечать.

Переменные окружения: PORT (порт), HOST (например 0.0.0.0 для доступа из сети), NO_BROWSER=1.
"""
import os
import socket
import sys
import threading
import time
import urllib.request
import webbrowser

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
sys.path.insert(0, HERE)
os.environ.setdefault("PYTHONUTF8", "1")

# Консоль Windows может не поддерживать UTF-8 — не падаем на русских сообщениях
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def say(msg: str):
    print(msg, flush=True)


def fail(msg: str):
    say("")
    say("ОШИБКА: " + msg)
    say("")
    sys.exit(1)


if sys.version_info[:2] != (3, 14):
    fail("нужен Python 3.14 (установлен %s). Скачайте Python 3.14: https://www.python.org/downloads/" % sys.version.split()[0])

missing = []
for mod in ("fastapi", "uvicorn", "sqlalchemy", "sklearn", "pandas", "numpy", "httpx", "bcrypt", "jwt", "openpyxl", "wordfreq", "multipart"):
    try:
        __import__(mod)
    except Exception:
        missing.append(mod)
if missing:
    fail("не установлены пакеты: %s.\nВыполните в папке backend:  python -m pip install -r requirements.txt" % ", ".join(missing))

import uvicorn  # noqa: E402


def check_model():
    """Загружаем модель; если файл создан другой версией scikit-learn/numpy — переобучаем."""
    from app.ml import model as M
    try:
        import numpy as np
        from app.ml import features as F
        m = M.WeakSignalModel.load()
        # пробное предсказание — ловит скрытую несовместимость версий
        m.pipeline.predict_proba(np.zeros((1, len(F.FEATURE_NAMES))))
        say("Модель загружена.")
    except Exception as e:  # noqa: BLE001
        say("Модель не загрузилась (%s) — переобучаю на встроенном датасете, это займёт около минуты…" % type(e).__name__)
        from app.ml import train
        train.run(write_docs=False)
        M.reset_model(None)
        say("Модель переобучена.")


def answering(url: str) -> bool:
    try:
        with urllib.request.urlopen(url + "/api/health", timeout=2) as r:
            return r.status == 200 and b"status" in r.read(200)
    except Exception:
        return False


def port_free(host: str, port: int) -> bool:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind((host, port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def make_sockets(host: str, port: int):
    socks = []
    s4 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s4.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) if os.name != "nt" else None
    s4.bind((host, port))
    socks.append(s4)
    if host in ("127.0.0.1", "localhost") and socket.has_ipv6:
        try:
            s6 = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
            if hasattr(socket, "IPV6_V6ONLY"):
                s6.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 1)
            s6.bind(("::1", port))
            socks.append(s6)
        except OSError:
            pass  # IPv6 отключён — достаточно IPv4
    for s in socks:
        s.listen(128)
        s.set_inheritable(True)
    return socks


def main():
    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    probe = "127.0.0.1" if host in ("0.0.0.0", "localhost") else host

    # уже запущен?
    for p in range(port, port + 10):
        if answering("http://%s:%d" % (probe, p)):
            url = "http://localhost:%d" % p
            say("Справочник уже запущен: " + url)
            if not os.getenv("NO_BROWSER"):
                webbrowser.open(url)
            return

    chosen = None
    for p in range(port, port + 10):
        if port_free(host if host != "localhost" else "127.0.0.1", p):
            chosen = p
            break
    if chosen is None:
        fail("порты %d–%d заняты другими программами. Укажите свободный: set PORT=8050 (Windows) или PORT=8050 (Linux/macOS)" % (port, port + 9))
    if chosen != port:
        say("Порт %d занят другой программой — использую порт %d." % (port, chosen))

    check_model()
    url = "http://localhost:%d" % chosen

    def open_when_ready():
        for _ in range(240):
            if answering("http://%s:%d" % (probe, chosen)):
                say("")
                say("=" * 64)
                say("  Справочник открыт:  " + url)
                say("  Запасной адрес:     http://127.0.0.1:%d" % chosen)
                say("  Документация API:   %s/docs" % url)
                say("  Остановка сервера:  Ctrl+C или закройте это окно")
                say("=" * 64)
                if not os.getenv("NO_BROWSER"):
                    webbrowser.open(url)
                return
            time.sleep(0.5)
        say("Сервер не ответил за 2 минуты — посмотрите сообщения выше.")

    threading.Thread(target=open_when_ready, daemon=True).start()
    say("Запускаю сервер… (первый запуск может занять до 30 секунд)")
    config = uvicorn.Config("app.main:app", log_level="info")
    server = uvicorn.Server(config)
    if host in ("127.0.0.1", "localhost"):
        server.run(sockets=make_sockets("127.0.0.1", chosen))
    else:
        config.host, config.port = host, chosen
        server.run()


if __name__ == "__main__":
    main()
