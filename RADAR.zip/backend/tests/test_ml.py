"""Проверки ML-модуля и методологии."""
import json
import os

from app.ml import features as F
from app.ml.dataset import DEFAULT_BACKGROUND, DEFAULT_DATASET, load_training_set, read_table, to_records
from app.ml.model import get_model

BACKEND = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def test_dataset_loads_100_signals():
    recs = to_records(read_table(DEFAULT_DATASET), default_label=1)
    assert len(recs) == 100
    assert all(r["label"] == 1 for r in recs)
    assert {r["area"] for r in recs} == {"Edge", "Защита ИИ", "Индустриальный ИИ", "Инфраструктура ИИ", "Роботы", "Финтех"}


def test_background_labels_zero():
    recs = to_records(read_table(DEFAULT_BACKGROUND), default_label=None)
    assert len(recs) == 132
    assert all(r["label"] == 0 for r in recs)


def test_training_set_balanced_enough():
    recs = load_training_set()
    y = [r["label"] for r in recs]
    assert sum(y) == 100 and len(y) - sum(y) == 132


def test_features_in_range():
    rec = {"name": "Нейроморфный чип", "why": "Противоречие между энергопотреблением и точностью; переход на спайковые сети",
           "stage": "Прототип/PoC", "trend": "Растёт быстро", "sources": "", "companies": ""}
    f = F.extract(rec)
    assert set(F.FEATURE_NAMES) <= set(f)
    assert all(0.0 <= v <= 1.0 for k, v in f.items() if k != "stage_level")
    assert 0 < F.methodology_index(f) < 1


def test_model_separates_signal_and_mature():
    m = get_model()
    weak = m.score_record({"name": "Спайковые нейросети на мемристорах", "why": "Первые прототипы, пилотные испытания; противоречие энергия/точность снимается сменой принципа вычислений, стартапы получили seed-раунды",
                           "stage": "Прототип/PoC", "trend": "Растёт быстро", "companies": "", "sources": ""})
    mature = m.score_record({"name": "Облачное хранение файлов", "why": "Массовое внедрение, стандарт отрасли, сотни миллионов пользователей, рынок насыщен",
                             "stage": "Массовое внедрение", "trend": "Стабильный уровень / насыщение", "companies": "", "sources": ""})
    assert weak["probability"] > 0.5 > mature["probability"]
    assert mature["exclusion_reasons"]


def test_validation_report_meets_target():
    p = os.path.join(BACKEND, "reports", "validation_report.json")
    rep = json.load(open(p, encoding="utf-8"))
    assert rep["main_model_repeated_cv"]["accuracy"]["mean"] >= 0.75
    assert rep["methodology_index_no_training"]["accuracy"] >= 0.75
    assert rep["stress_test_hard_background"]["accuracy"] >= 0.75
