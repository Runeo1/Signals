"""Regression coverage for audit_weak_signals.md. Network replies are controlled fixtures."""
import asyncio
import copy
import time
from types import SimpleNamespace

import pytest
from app import db
from app.services import pipeline as P, evidence as E, translate as T, llm
from app.services.candidates import extract_candidates
from app.services.quality import evidence_gate


def document(n=0, abstract=None):
    return dict(title='Photonic security sensor experimental prototype ' + str(n),
                abstract=abstract or 'We demonstrate a laboratory prototype of a photonic security sensor. The device reduces energy consumption in cybersecurity monitoring compared with conventional sensors.',
                source_id='openalex', source_name='OpenAlex', source_type='paper',
                url='https://arxiv.org/abs/2601.%05d' % n, language='en', year=2026,
                date='2026-01-01', trust='высокий')


def setup_search(monkeypatch, p=.8, docs=None, n=1, translated=True, mature=False):
    docs = [document()] if docs is None else docs
    async def fetch(client, sid, query, limit, key):
        return dict(id=sid, status='ok', error=None, ms=1, link='', docs=docs)
    async def evidence(*args, **kwargs):
        return dict(growth=E.growth_metrics(None), coverage={'publications':'unavailable'})
    candidates = [dict(phrase='photonic security sensor', df=len(docs), doc_ids=list(range(len(docs))), sources=['openalex']) for _ in range(n)]
    score = dict(probability=p, features={'stage_level': 6 if mature else 2}, exclusion_reasons=[], predictors=[], methodology_predictors=[])
    monkeypatch.setattr(P.S, 'fetch_source', fetch)
    monkeypatch.setattr(P.E, 'gather_evidence', evidence)
    monkeypatch.setattr(P, 'extract_candidates', lambda *a, **k: candidates)
    monkeypatch.setattr(P, 'get_model', lambda: SimpleNamespace(score_record=lambda *a, **k: copy.deepcopy(score)))
    if translated:
        monkeypatch.setattr(P, 'translate_many', lambda texts,*a: [('Фотонный датчик безопасности: лабораторный прототип снижает потребление энергии при обнаружении угроз в сетях связи.', 'контролируемый перевод') if t else ('','') for t in texts])
    else:
        monkeypatch.setattr(P, 'translate_many', lambda texts,*a: [('', '') for _ in texts])


@pytest.mark.parametrize('mode', ['hybrid','methodology','library'])
def test_threshold_without_reasons(monkeypatch, mode):
    setup_search(monkeypatch, p=.1)
    job=P.new_job('cybersecurity', mode, ['openalex'])
    asyncio.run(P.run(job, {}, allow_online_translation=False))
    assert job['status']=='done'
    assert job['result']['stats']['top']==0
    assert job['result']['stats']['weak_signals']==0
    assert len(job['result']['excluded'])==1


def test_unknown_is_not_zero_or_early():
    g=E.growth_metrics(None)
    assert g['total'] is None and g['total_est'] is None and g['recent'] is None
    text=E.textualize({'phrase':'database systems'}, {'growth':g}, [document(abstract='Database systems are commonly described in academic publications.')])
    assert 'Не определена' in text['stage']
    assert 'Почти не освещается' not in text['why']
    zero=E.growth_metrics({'source':'OpenAlex', 'total':0, 'years':{}})
    assert zero['total']==0


@pytest.mark.parametrize('mode', ['hybrid','library'])
def test_mature_blocked_in_every_mode(monkeypatch, mode):
    docs=[document(abstract='The photonic security sensor is widely deployed and commercially available to millions of users. We demonstrate a prototype improvement.')]
    setup_search(monkeypatch, docs=docs)
    j=P.new_job('cybersecurity',mode,['openalex']);asyncio.run(P.run(j,{}))
    assert j['result']['items']==[] and j['result']['excluded']


def test_empty_saved_after_finished_at(monkeypatch):
    setup_search(monkeypatch, docs=[])
    saves=[]
    j=P.new_job('cybersecurity','hybrid',['openalex'])
    asyncio.run(P.run(j,{},lambda k,p:saves.append((k,copy.deepcopy(p['job'])))))
    finals=[s for k,s in saves if k=='result']
    assert len(finals)==1 and finals[0]['status']=='done' and finals[0]['finished_at']
    assert finals[0]['result']['items']==[]


@pytest.mark.parametrize('failure', ['exception','cancel'])
def test_terminal_failure_saved(monkeypatch,failure):
    async def fail(*a):
        if failure=='cancel':raise asyncio.CancelledError()
        raise ValueError('fixture')
    monkeypatch.setattr(P,'_run',fail)
    saved=[];j=P.new_job('q','hybrid',[])
    asyncio.run(P.run(j,{},lambda k,p:saved.append(copy.deepcopy(p['job']))))
    assert len(saved)==1 and saved[0]['finished_at']
    assert saved[0]['status']==('error' if failure=='exception' else 'cancelled')


def test_missing_translation_is_incomplete_not_top(monkeypatch):
    setup_search(monkeypatch, translated=False)
    j=P.new_job('cybersecurity','hybrid',['openalex']);asyncio.run(P.run(j,{}))
    r=j['result'];assert not r['items'] and len(r['incomplete'])==1
    assert not r['incomplete'][0]['is_weak_signal'] and r['report_status']=='partial'
    assert r['incomplete'][0]['description']==''


def test_full_top_15_and_strict_confidence_boundary(monkeypatch):
    setup_search(monkeypatch,p=.75,n=16)
    j=P.new_job('cybersecurity','hybrid',['openalex']);asyncio.run(P.run(j,{}))
    r=j['result'];assert len(r['items'])==15 and r['stats']['weak_signals']==15
    assert r['stats']['confident_75']==0 and r['report_status']=='complete'
    assert [i['rank'] for i in r['items']]==list(range(1,16))


def test_noise_and_offtopic_candidates_removed():
    docs=[document(i, 'Abstract India validated against operational benefits and skills gaps. Quantum computing and renewable energy support education.') for i in range(3)]
    for d in docs:d['title']='Abstract India operational benefits ' + str(d['year'])
    assert extract_candidates(docs, 'cybersecurity')==[]


def test_low_trust_and_missing_metadata():
    d=document();d.update(url='https://example.net/promotion',trust='пониженный')
    assert not evidence_gate('photonic security sensor',[d],'cybersecurity')['eligible']
    d=document();d['date']=None;d['year']=None
    assert not evidence_gate('photonic security sensor',[d],'cybersecurity')['eligible']


def test_translation_failure_bounded_no_per_field_fallback(monkeypatch):
    T._CACHE.clear();T._CIRCUIT.clear();calls=[]
    monkeypatch.setattr(llm,'available',lambda:False)
    def fail(*args):calls.append(1);return None
    monkeypatch.setattr(T,'_google',fail)
    monkeypatch.setattr(T,'_mymemory',lambda *a:None)
    monkeypatch.setattr(T,'translate',lambda *a:pytest.fail('per-field fallback forbidden'))
    assert len(T.translate_many(['long source '+str(i) for i in range(30)]))==30
    assert len(calls)==1


@pytest.mark.parametrize('cfg', [dict(provider='openai',model='gpt-4.1',base_url='https://openrouter.ai/v1'),dict(provider='openai',model='unlisted'),dict(provider='yandexgpt',model='yandexgpt',folder_id='folder')])
def test_llm_policy(cfg):
    with pytest.raises(ValueError):llm.validate_config(cfg)


def test_env_cannot_bypass_policy(monkeypatch):
    db.init_db();monkeypatch.setattr(llm,'_RUNTIME',{})
    for k,v in {'LLM_PROVIDER':'openai','LLM_MODEL':'unlisted','LLM_API_KEY':'test'}.items():monkeypatch.setenv(k,v)
    monkeypatch.setattr(llm.httpx,'post',lambda *a,**k:pytest.fail('unapproved request'))
    assert llm.chat('system','data') is None
    with db.session() as s:assert s.query(db.AuditLog).filter(db.AuditLog.event=='llm_call').count()>0


def test_llm_success_is_durable_and_secrets_not_logged(monkeypatch):
    db.init_db();monkeypatch.setattr(llm,'_RUNTIME',dict(provider='openai',model='gpt-4.1',api_key='private-test-key',base_url='',folder_id=''))
    monkeypatch.setattr(llm.httpx,'post',lambda *a,**k:SimpleNamespace(raise_for_status=lambda:None,json=lambda:{'choices':[{'message':{'content':'Перевод'}}]}))
    assert llm.chat('system','source')=='Перевод'
    with db.session() as s:
        logs=s.query(db.AuditLog).filter(db.AuditLog.event.in_(['llm_call','llm_call_started'])).all()
        assert any(x.details.get('ok') is True for x in logs)
        assert all('private-test-key' not in str(x.details) for x in logs)


def test_fresh_cross_validation_not_saved_report():
    from sklearn.model_selection import cross_val_score, StratifiedKFold
    from app.ml.dataset import load_training_set
    from app.ml.model import build_model
    from app.ml.features import vectorize
    records=load_training_set();X,_=vectorize(records)
    accuracy=cross_val_score(build_model(),X,[r['label'] for r in records],cv=StratifiedKFold(5,shuffle=True,random_state=42)).mean()
    assert accuracy>=.8
