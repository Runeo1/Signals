import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_tmp = tempfile.mkdtemp()
os.environ.setdefault("DATABASE_URL", "sqlite:///" + os.path.join(_tmp, "test.sqlite3"))
