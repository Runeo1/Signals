"""Сквозные проверки REST API (без обращения к внешним источникам)."""
import io

from fastapi.testclient import TestClient

from app.main import app


def _client():
    return TestClient(app)


def test_auth_flow_and_catalog():
    with _client() as c:
        st = c.get("/api/auth/status").json()
        if not st["password_set"]:
            r = c.post("/api/auth/setup", json={"password": "test1234"})
            assert r.status_code == 200
        r = c.post("/api/auth/login", json={"password": "wrong"})
        assert r.status_code == 401
        tok = c.post("/api/auth/login", json={"password": "test1234"}).json()["token"]
        h = {"Authorization": "Bearer " + tok}
        assert c.get("/api/catalog").status_code == 401
        cat = c.get("/api/catalog", headers=h).json()
        assert len(cat) >= 100
        assert all(0 <= i["probability"] <= 1 for i in cat)
        # вход без пароля: включаем и проверяем
        assert c.post("/api/auth/require", json={"require_password": False, "current": "test1234"}, headers=h).status_code == 200
        assert c.get("/api/catalog").status_code == 200
        assert c.post("/api/auth/open").status_code == 200
        assert c.post("/api/auth/require", json={"require_password": True, "current": "test1234"}, headers=h).status_code == 200
        assert c.get("/api/catalog").status_code == 401
        # смена пароля
        assert c.post("/api/auth/change", json={"current": "test1234", "new": "new12345"}, headers=h).status_code == 200
        assert c.post("/api/auth/login", json={"password": "new12345"}).status_code == 200
        c.post("/api/auth/change", json={"current": "new12345", "new": "test1234"}, headers=h)


def _h(c):
    return {"Authorization": "Bearer " + c.post("/api/auth/login", json={"password": "test1234"}).json()["token"]}


def test_sources_and_model_endpoints():
    with _client() as c:
        h = _h(c)
        src = c.get("/api/sources", headers=h).json()
        assert len(src) >= 24
        info = c.get("/api/model/info", headers=h).json()
        assert info["report"]["target_met"] is True
        sc = c.post("/api/model/score", json={"name": "Квантовые сенсоры", "why": "первые прототипы", "stage": "Прототип/PoC", "trend": "Растёт"}, headers=h).json()
        assert 0 <= sc["probability"] <= 1


def test_validate_upload_with_labels():
    csv = ("Технология,Почему это слабый сигнал,Стадия развития,Тренд упоминаний,label\n"
           "Спайковые сети на мемристорах,первые прототипы и seed-раунды стартапов,Прототип/PoC,Растёт быстро,1\n"
           "Облачная почта,массовое внедрение и стандарт отрасли,Массовое внедрение,Стабильный уровень,0\n")
    with _client() as c:
        h = _h(c)
        r = c.post("/api/model/validate", files={"file": ("t.csv", io.BytesIO(csv.encode("utf-8")), "text/csv")}, headers=h)
        assert r.status_code == 200
        d = r.json()
        assert d["n_rows"] == 2 and d["metrics"] is not None
        assert d["metrics"]["accuracy"] == 1.0


def test_run_management_endpoints():
    with _client() as c:
        h = _h(c)
        assert c.delete("/api/runs/does-not-exist", headers=h).status_code == 404
        assert c.post("/api/search/does-not-exist/cancel", headers=h).status_code == 409
        assert c.get("/api/runs", headers=h).status_code == 200
        assert c.get("/api/health").json()["status"] == "ok"
