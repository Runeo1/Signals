// Адрес backend API. Пусто — тот же сервер (Docker/nginx или FastAPI раздаёт интерфейс сам).
// Пример для раздельного размещения: window.RADAR_API = "https://radar-api.example.org";
window.RADAR_API = "";
