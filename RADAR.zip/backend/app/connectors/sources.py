# -*- coding: utf-8 -*-
"""
Коннекторы к открытым источникам (модуль парсинга / ETL).

Каждый коннектор возвращает список нормализованных документов:
  {source_id, source_name, source_type, title, abstract, url, date, year,
   language, authors, venue, trust}

Категории доступа:
  free      — работает без ключа;
  optional  — работает без ключа, ключ повышает лимиты;
  key       — нужен ключ (оператор вводит в «Настройках API-ключей»);
  link      — у сервиса нет открытого API: формируются ссылки для ручной проверки.
"""
import asyncio
import html
import re
import time
import xml.etree.ElementTree as ET
from typing import Dict, List, Optional
from urllib.parse import quote, quote_plus

import httpx

UA = "WeakSignalsRadar/2.0 (research prototype; mailto:radar@example.org)"
TIMEOUT = httpx.Timeout(20.0, connect=10.0)

_TAG = re.compile(r"<[^>]+>")


def strip_tags(s) -> str:
    if s is None:
        return ""
    if isinstance(s, list):
        s = " ".join(str(x) for x in s)
    return html.unescape(_TAG.sub(" ", str(s))).replace("\n", " ").strip()


def _year(s) -> Optional[int]:
    m = re.search(r"(19|20)\d{2}", str(s or ""))
    return int(m.group(0)) if m else None


def doc(source_id, source_name, source_type, title, abstract="", url="", date="", language="en",
        authors="", venue="", trust=None) -> Dict:
    title = strip_tags(title)[:500]
    return {
        "source_id": source_id, "source_name": source_name, "source_type": source_type,
        "title": title, "abstract": strip_tags(abstract)[:3000], "url": url or "",
        "date": str(date or "")[:10], "year": _year(date), "language": language or "en",
        "authors": strip_tags(authors)[:300], "venue": strip_tags(venue)[:200],
        "trust": trust or TRUST_BY_TYPE.get(source_type, "средний"),
    }


TRUST_BY_TYPE = {
    "preprint": "высокий", "article": "высокий", "patent": "высокий", "clinical_trial": "высокий",
    "dataset": "высокий", "report": "высокий", "government": "высокий",
    "news": "средний", "fiction": "средний (идеи, не доказательство)", "book": "средний",
    "social": "пониженный", "blog": "пониженный", "press_release": "пониженный",
}

TYPE_RU = {
    "preprint": "Препринт", "article": "Научная статья", "patent": "Патент", "clinical_trial": "Клиническое испытание",
    "dataset": "Набор данных / ПО", "report": "Технический отчёт", "news": "СМИ / новости",
    "fiction": "Научная фантастика", "book": "Книга", "press_release": "Пресс-релиз", "blog": "Блог",
}


# ---------------------------------------------------------------------------
# Реализации
# ---------------------------------------------------------------------------
async def _curl(url: str, timeout: int = 25) -> str:
    import shutil
    if not shutil.which("curl"):
        raise RuntimeError("curl недоступен для запасного запроса")
    proc = await asyncio.create_subprocess_exec("curl", "-s", "-m", str(timeout), "-A", UA, url,
                                                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    out, _ = await proc.communicate()
    txt = out.decode("utf-8", "replace")
    if not txt.strip().startswith("<?xml"):
        raise RuntimeError("пустой ответ")
    return txt


async def _get(client: httpx.AsyncClient, url: str, retries: int = 2, **kw) -> httpx.Response:
    """GET с повтором при 429/503 (уважаем лимиты открытых API)."""
    for attempt in range(retries + 1):
        r = await client.get(url, **kw)
        if r.status_code in (406, 429, 503) and attempt < retries:
            ra = r.headers.get("Retry-After", "")
            delay = float(ra) if ra.replace(".", "", 1).isdigit() else 3.0 * (attempt + 1)
            await asyncio.sleep(min(delay, 8.0))
            continue
        r.raise_for_status()
        return r
    return r


async def arxiv(client, q, limit, key=None):
    terms = [w for w in re.split(r"\s+", q.strip()) if w]
    sq = " AND ".join("all:%s" % w for w in terms) or "all:*"
    url = "https://export.arxiv.org/api/query?search_query=%s&start=0&max_results=%d&sortBy=submittedDate&sortOrder=descending" % (quote_plus(sq), limit)
    try:
        r = await _get(client, url, retries=1, headers={"Accept": "application/atom+xml", "Accept-Encoding": "identity"})
        text = r.text
    except httpx.HTTPStatusError as e:
        # Часть CDN-узлов arXiv отклоняет Python-клиентов по TLS-отпечатку (HTTP 406).
        # Запасной путь — системный curl (есть в Docker-образе).
        if e.response.status_code != 406:
            raise
        text = await _curl(url)
    root = ET.fromstring(text)
    ns = {"a": "http://www.w3.org/2005/Atom"}
    out = []
    for e in root.findall("a:entry", ns):
        link = (e.findtext("a:id", default="", namespaces=ns) or "").replace("http://", "https://")
        authors = ", ".join(a.findtext("a:name", default="", namespaces=ns) for a in e.findall("a:author", ns)[:4])
        out.append(doc("arxiv", "arXiv", "preprint", e.findtext("a:title", "", ns), e.findtext("a:summary", "", ns),
                       link, e.findtext("a:published", "", ns), "en", authors, "arXiv"))
    return out


async def openalex(client, q, limit, key=None):
    params = {"filter": "title_and_abstract.search:%s" % q, "per-page": min(limit, 50), "sort": "publication_date:desc",
              "mailto": "radar@example.org",
              "select": "id,doi,title,publication_date,language,abstract_inverted_index,primary_location,authorships,type"}
    if key:
        params["api_key"] = key
    r = await _get(client, "https://api.openalex.org/works", params=params)
    out = []
    for w in r.json().get("results", []):
        inv = w.get("abstract_inverted_index") or {}
        abstract = ""
        if inv:
            pos = sorted((p, word) for word, ps in inv.items() for p in ps)
            abstract = " ".join(word for _, word in pos)
        loc = (w.get("primary_location") or {}).get("source") or {}
        authors = ", ".join(((a.get("author") or {}).get("display_name") or "") for a in (w.get("authorships") or [])[:4])
        stype = "preprint" if (w.get("type") == "preprint") else "article"
        out.append(doc("openalex", "OpenAlex", stype, w.get("title"), abstract, w.get("doi") or w.get("id"),
                       w.get("publication_date"), w.get("language") or "en", authors, loc.get("display_name", "")))
    return out


async def crossref(client, q, limit, key=None, prefix=None, sid="crossref", sname="Crossref", stype="article"):
    base = "https://api.crossref.org/prefixes/%s/works" % prefix if prefix else "https://api.crossref.org/works"
    params = {"query.bibliographic": q, "rows": limit, "sort": "relevance",
              "filter": "from-pub-date:2022-01-01", "select": "DOI,title,abstract,issued,author,container-title,type"}
    r = await _get(client, base, params=params)
    out = []
    for it in r.json().get("message", {}).get("items", []):
        dp = ((it.get("issued") or {}).get("date-parts") or [[None]])[0]
        date = "-".join(str(x).zfill(2) for x in dp if x) if dp and dp[0] else ""
        authors = ", ".join("%s %s" % (a.get("given", ""), a.get("family", "")) for a in (it.get("author") or [])[:4])
        out.append(doc(sid, sname, stype if it.get("type") != "posted-content" else "preprint",
                       (it.get("title") or [""])[0], it.get("abstract", ""), "https://doi.org/" + it.get("DOI", ""),
                       date, it.get("language") or "en", authors, (it.get("container-title") or [""])[0]))
    return out


async def ssrn(client, q, limit, key=None):
    return await crossref(client, q, limit, prefix="10.2139", sid="ssrn", sname="SSRN (через Crossref)", stype="preprint")


async def europepmc(client, q, limit, key=None, preprints=False):
    query = q + (" AND SRC:PPR" if preprints else " AND PUB_YEAR:[2022 TO 2030]")
    params = {"query": query, "format": "json", "pageSize": limit, "resultType": "core", "sort": "P_PDATE_D desc"}
    r = await _get(client, "https://www.ebi.ac.uk/europepmc/webservices/rest/search", params=params)
    out = []
    for it in r.json().get("resultList", {}).get("result", []):
        src = it.get("source", "MED")
        url = ("https://europepmc.org/article/%s/%s" % (src, it.get("id"))) if it.get("id") else ""
        if it.get("doi"):
            url = "https://doi.org/" + it["doi"]
        sid, sname = ("biorxiv", "bioRxiv / medRxiv / препринты (Europe PMC)") if preprints else ("pubmed", "PubMed / Europe PMC")
        out.append(doc(sid, sname, "preprint" if src == "PPR" else "article", it.get("title"), it.get("abstractText", ""),
                       url, it.get("firstPublicationDate") or it.get("pubYear"), (it.get("language") or "eng")[:2],
                       it.get("authorString", ""), it.get("journalTitle", "") or it.get("bookOrReportDetails", {}).get("publisher", "")))
    return out


async def biorxiv(client, q, limit, key=None):
    return await europepmc(client, q, limit, preprints=True)


async def doaj(client, q, limit, key=None):
    r = await _get(client, "https://doaj.org/api/search/articles/%s" % quote(q), params={"pageSize": min(limit, 50), "sort": "created_date:desc"})
    out = []
    for it in r.json().get("results", []):
        b = it.get("bibjson", {})
        link = ""
        for l in b.get("link", []):
            link = l.get("url") or link
        for i in b.get("identifier", []):
            if i.get("type") == "doi":
                link = "https://doi.org/" + i.get("id")
        authors = ", ".join(a.get("name", "") for a in b.get("author", [])[:4])
        out.append(doc("doaj", "DOAJ", "article", b.get("title"), b.get("abstract", ""), link,
                       "%s-%s" % (b.get("year", ""), str(b.get("month", "01")).zfill(2)) if b.get("year") else "",
                       ((b.get("journal") or {}).get("language") or ["en"])[0][:2].lower(), authors, (b.get("journal") or {}).get("title", "")))
    return out


async def datacite(client, q, limit, key=None):
    r = await _get(client, "https://api.datacite.org/dois", params={"query": q, "page[size]": limit, "sort": "-created"})
    out = []
    for it in r.json().get("data", []):
        a = it.get("attributes", {})
        desc = " ".join(d.get("description", "") for d in (a.get("descriptions") or [])[:1])
        authors = ", ".join(c.get("name", "") for c in (a.get("creators") or [])[:4])
        out.append(doc("datacite", "DataCite", "dataset", ((a.get("titles") or [{}])[0]).get("title", ""), desc,
                       "https://doi.org/" + a.get("doi", ""), a.get("created") or a.get("publicationYear"),
                       a.get("language") or "en", authors, a.get("publisher", "") if isinstance(a.get("publisher"), str) else ""))
    return out


async def zenodo(client, q, limit, key=None):
    params = {"q": q, "size": limit, "sort": "mostrecent"}
    if key:
        params["access_token"] = key
    r = await _get(client, "https://zenodo.org/api/records", params=params)
    out = []
    for it in r.json().get("hits", {}).get("hits", []):
        m = it.get("metadata", {})
        authors = ", ".join(c.get("name", "") for c in (m.get("creators") or [])[:4])
        rtype = ((m.get("resource_type") or {}).get("type") or "")
        st = "preprint" if rtype in ("publication",) else "dataset"
        out.append(doc("zenodo", "Zenodo", st, m.get("title"), m.get("description", ""),
                       (it.get("links") or {}).get("self_html") or ("https://doi.org/" + it.get("doi", "")),
                       m.get("publication_date"), (m.get("language") or "en")[:2], authors, "Zenodo"))
    return out


async def osti(client, q, limit, key=None):
    r = await _get(client, "https://www.osti.gov/api/v1/records", params={"q": q, "rows": limit, "sort": "publication_date desc"},
                   headers={"Accept": "application/json"})
    out = []
    for it in r.json():
        url = ("https://doi.org/" + it["doi"]) if it.get("doi") else ("https://www.osti.gov/biblio/%s" % it.get("osti_id", ""))
        out.append(doc("osti", "OSTI.GOV", "report", it.get("title"), it.get("description", ""), url,
                       it.get("publication_date"), (it.get("language") or "en")[:2].lower(), ", ".join((it.get("authors") or [])[:4]),
                       it.get("journal_name", "") or "OSTI"))
    return out


async def hal(client, q, limit, key=None):
    params = {"q": q, "rows": limit, "wt": "json", "sort": "producedDate_tdate desc",
              "fl": "title_s,abstract_s,uri_s,producedDate_s,language_s,authFullName_s,docType_s,journalTitle_s"}
    r = await _get(client, "https://api.archives-ouvertes.fr/search/", params=params)
    out = []
    for it in r.json().get("response", {}).get("docs", []):
        out.append(doc("hal", "HAL", "article", (it.get("title_s") or [""])[0], (it.get("abstract_s") or [""])[0],
                       it.get("uri_s", ""), it.get("producedDate_s", ""), (it.get("language_s") or ["en"])[0],
                       ", ".join((it.get("authFullName_s") or [])[:4]), it.get("journalTitle_s", "")))
    return out


async def clinicaltrials(client, q, limit, key=None):
    params = {"query.term": q, "pageSize": limit, "sort": "LastUpdatePostDate:desc",
              "fields": "NCTId,BriefTitle,BriefSummary,StartDate,Phase,OverallStatus,LeadSponsorName"}
    r = await _get(client, "https://clinicaltrials.gov/api/v2/studies", params=params)
    out = []
    for s in r.json().get("studies", []):
        p = s.get("protocolSection", {})
        ident = p.get("identificationModule", {})
        desc = (p.get("descriptionModule") or {}).get("briefSummary", "")
        status = p.get("statusModule", {})
        phases = ", ".join((p.get("designModule") or {}).get("phases", []) or [])
        sponsor = ((p.get("sponsorCollaboratorsModule") or {}).get("leadSponsor") or {}).get("name", "")
        nct = ident.get("nctId", "")
        out.append(doc("clinicaltrials", "ClinicalTrials.gov", "clinical_trial", ident.get("briefTitle"),
                       ("[%s; %s] " % (phases or "фаза не указана", status.get("overallStatus", ""))) + desc,
                       "https://clinicaltrials.gov/study/" + nct, (status.get("startDateStruct") or {}).get("date", ""),
                       "en", sponsor, "ClinicalTrials.gov"))
    return out


async def gdelt(client, q, limit, key=None):
    query = '"%s"' % q if " " in q and len(q.split()) <= 4 else q
    params = {"query": query + " sourcelang:english", "mode": "artlist", "maxrecords": min(limit, 75), "format": "json",
              "timespan": "12m", "sort": "datedesc"}
    r = await _get(client, "https://api.gdeltproject.org/api/v2/doc/doc", params=params)
    if "limit" in r.text[:200].lower() and not r.text.strip().startswith("{"):
        await asyncio.sleep(6)
        r = await _get(client, "https://api.gdeltproject.org/api/v2/doc/doc", params=params)
    try:
        arts = r.json().get("articles", [])
    except Exception:
        arts = []
    out = []
    for a in arts:
        d = a.get("seendate", "")
        date = "%s-%s-%s" % (d[:4], d[4:6], d[6:8]) if len(d) >= 8 else ""
        out.append(doc("gdelt", "GDELT (мировые СМИ)", "news", a.get("title"), "", a.get("url"), date,
                       (a.get("language") or "English")[:2].lower(), "", a.get("domain", "")))
    return out


async def openlibrary(client, q, limit, key=None):
    params = {"q": q, "subject": "science fiction", "limit": limit, "fields": "key,title,first_publish_year,author_name,subject,language"}
    r = await _get(client, "https://openlibrary.org/search.json", params=params)
    out = []
    for it in r.json().get("docs", []):
        subj = ", ".join((it.get("subject") or [])[:6])
        out.append(doc("isfdb", "Open Library / ISFDB (фантастика)", "fiction", it.get("title"),
                       "Тематика: " + subj, "https://openlibrary.org" + it.get("key", ""), it.get("first_publish_year") or "",
                       (it.get("language") or ["eng"])[0][:2], ", ".join((it.get("author_name") or [])[:3]), "Open Library"))
    return out


async def google_patents(client, q, limit, key=None, country=None):
    inner = "q=(%s)&num=%d&sort=new" % (q, min(limit, 50))
    if country:
        inner += "&country=" + country
    r = await _get(client, "https://patents.google.com/xhr/query", params={"url": inner, "exp": ""})
    out = []
    for cl in r.json().get("results", {}).get("cluster", []):
        for it in cl.get("result", []):
            p = it.get("patent", {})
            pid = (it.get("id") or "").replace("patent/", "")
            out.append(doc("patents", "Google Patents (WIPO/EPO/USPTO/RU)", "patent", p.get("title"), p.get("snippet", ""),
                           "https://patents.google.com/patent/" + pid, p.get("filing_date") or p.get("publication_date"),
                           p.get("language") or "en", p.get("inventor", ""), p.get("assignee", "")))
    return out


async def cyberleninka(client, q, limit, key=None):
    r = await client.post("https://cyberleninka.ru/api/search", json={"mode": "articles", "q": q, "size": min(limit, 20), "from": 0},
                          headers={"Content-Type": "application/json"})
    r.raise_for_status()
    out = []
    for a in r.json().get("articles", []):
        out.append(doc("cyberleninka", "КиберЛенинка (РФ)", "article", a.get("name"), a.get("annotation", ""),
                       "https://cyberleninka.ru" + a.get("link", ""), str(a.get("year", "")), "ru",
                       ", ".join(a.get("authors") or [])[:200], a.get("journal", "")))
    return out


async def semantic_scholar(client, q, limit, key=None):
    headers = {"x-api-key": key} if key else {}
    params = {"query": q, "limit": min(limit, 50), "fields": "title,abstract,year,url,publicationDate,venue,authors,externalIds",
              "year": "2022-"}
    r = await _get(client, "https://api.semanticscholar.org/graph/v1/paper/search", params=params, headers=headers)
    out = []
    for it in r.json().get("data", []):
        out.append(doc("semantic", "Semantic Scholar", "article", it.get("title"), it.get("abstract") or "", it.get("url"),
                       it.get("publicationDate") or it.get("year"), "en",
                       ", ".join(a.get("name", "") for a in (it.get("authors") or [])[:4]), it.get("venue", "")))
    return out


async def nasa_ads(client, q, limit, key=None):
    r = await _get(client, "https://api.adsabs.harvard.edu/v1/search/query",
                   params={"q": q, "rows": limit, "sort": "date desc", "fl": "title,abstract,bibcode,pubdate,author,pub"},
                   headers={"Authorization": "Bearer " + (key or "")})
    out = []
    for it in r.json().get("response", {}).get("docs", []):
        out.append(doc("ads", "NASA ADS", "article", (it.get("title") or [""])[0], it.get("abstract", ""),
                       "https://ui.adsabs.harvard.edu/abs/%s" % it.get("bibcode", ""), it.get("pubdate", ""), "en",
                       ", ".join((it.get("author") or [])[:4]), it.get("pub", "")))
    return out


async def core(client, q, limit, key=None):
    r = await _get(client, "https://api.core.ac.uk/v3/search/works", params={"q": q, "limit": limit},
                   headers={"Authorization": "Bearer " + (key or "")})
    out = []
    for it in r.json().get("results", []):
        url = (it.get("links") or [{}])[0].get("url", "") if it.get("links") else it.get("downloadUrl", "")
        out.append(doc("core", "CORE", "article", it.get("title"), it.get("abstract", ""), url, it.get("publishedDate") or it.get("yearPublished"),
                       ((it.get("language") or {}).get("code") or "en"), ", ".join(a.get("name", "") for a in (it.get("authors") or [])[:4]), ""))
    return out


async def newsapi(client, q, limit, key=None):
    r = await _get(client, "https://newsapi.org/v2/everything", params={"q": q, "pageSize": min(limit, 100), "sortBy": "publishedAt", "apiKey": key})
    out = []
    for a in r.json().get("articles", []):
        out.append(doc("newsapi", "NewsAPI", "news", a.get("title"), a.get("description", ""), a.get("url"),
                       a.get("publishedAt", ""), "en", a.get("author") or "", (a.get("source") or {}).get("name", "")))
    return out


async def lens(client, q, limit, key=None):
    body = {"query": q, "size": limit, "include": ["lens_id", "biblio", "abstract", "date_published"]}
    r = await client.post("https://api.lens.org/patent/search", json=body, headers={"Authorization": "Bearer " + (key or "")})
    r.raise_for_status()
    out = []
    for it in r.json().get("data", []):
        t = ((it.get("biblio") or {}).get("invention_title") or [{}])[0].get("text", "")
        ab = (it.get("abstract") or [{}])[0].get("text", "")
        out.append(doc("lens", "Lens.org", "patent", t, ab, "https://www.lens.org/lens/patent/" + it.get("lens_id", ""),
                       it.get("date_published", ""), "en"))
    return out


async def patentsview(client, q, limit, key=None):
    body = {"q": {"_text_any": {"patent_abstract": q}}, "f": ["patent_id", "patent_title", "patent_abstract", "patent_date"],
            "s": [{"patent_date": "desc"}], "o": {"size": limit}}
    r = await client.post("https://search.patentsview.org/api/v1/patent/", json=body, headers={"X-Api-Key": key or ""})
    r.raise_for_status()
    out = []
    for it in r.json().get("patents", []):
        out.append(doc("uspto", "USPTO / PatentsView", "patent", it.get("patent_title"), it.get("patent_abstract", ""),
                       "https://patents.google.com/patent/US%s" % it.get("patent_id", ""), it.get("patent_date", ""), "en"))
    return out


async def epo_ops(client, q, limit, key=None):
    # key в формате "consumer_key:consumer_secret"
    ck, _, cs = (key or "").partition(":")
    tok = await client.post("https://ops.epo.org/3.2/auth/accesstoken", data={"grant_type": "client_credentials"}, auth=(ck, cs))
    tok.raise_for_status()
    at = tok.json().get("access_token")
    r = await _get(client, "https://ops.epo.org/3.2/rest-services/published-data/search/biblio",
                   params={"q": 'txt="%s"' % q, "Range": "1-%d" % min(limit, 25)},
                   headers={"Authorization": "Bearer " + at, "Accept": "application/json"})
    out = []
    data = r.json()
    docs = (((data.get("ops:world-patent-data") or {}).get("ops:biblio-search") or {}).get("ops:search-result") or {}).get("exchange-documents") or []
    if isinstance(docs, dict):
        docs = [docs]
    for d in docs:
        ed = d.get("exchange-document", {})
        bib = ed.get("bibliographic-data", {})
        titles = bib.get("invention-title")
        if isinstance(titles, list):
            t = next((x.get("$") for x in titles if x.get("@lang") == "en"), titles[0].get("$"))
        else:
            t = (titles or {}).get("$", "")
        num = "%s%s%s" % (ed.get("@country", ""), ed.get("@doc-number", ""), ed.get("@kind", ""))
        out.append(doc("epo", "EPO OPS", "patent", t, "", "https://worldwide.espacenet.com/patent/search?q=pn%3D" + num,
                       "", "en"))
    return out


async def repec(client, q, limit, key=None):
    r = await _get(client, "https://api.repec.org/call.cgi", params={"code": key, "searchword": q})
    out = []
    for it in (r.json() if isinstance(r.json(), list) else [])[:limit]:
        out.append(doc("repec", "RePEc / IDEAS", "article", it.get("title", ""), "", it.get("url", ""), it.get("year", ""), "en"))
    return out


# ---------------------------------------------------------------------------
# Реестр
# ---------------------------------------------------------------------------
SOURCES = [
    # id, название, группа, доступ, функция, ссылка на получение ключа, ссылка для ручного поиска
    ("arxiv", "arXiv — препринты", "Наука", "free", arxiv, "", "https://arxiv.org/search/?query={q}&searchtype=all"),
    ("semantic", "Semantic Scholar — статьи и цитирования", "Наука", "optional", semantic_scholar, "https://www.semanticscholar.org/product/api#api-key-form", "https://www.semanticscholar.org/search?q={q}"),
    ("wipo", "WIPO PATENTSCOPE — PCT-патенты", "Патенты", "link", None, "https://www.wipo.int/patentscope/en/data/", "https://patentscope.wipo.int/search/en/result.jsf?query={q}"),
    ("newsapi", "NewsAPI — СМИ и новости", "СМИ", "key", newsapi, "https://newsapi.org/register", "https://news.google.com/search?q={q}"),
    ("openalex", "OpenAlex — научный граф", "Наука", "optional", openalex, "https://openalex.org/settings/api", "https://openalex.org/works?search={q}"),
    ("crossref", "Crossref — DOI и метаданные", "Наука", "free", crossref, "", "https://search.crossref.org/?q={q}"),
    ("pubmed", "PubMed / Europe PMC — биомедицина", "Наука", "free", europepmc, "", "https://europepmc.org/search?query={q}"),
    ("biorxiv", "bioRxiv / medRxiv — препринты", "Наука", "free", biorxiv, "", "https://www.biorxiv.org/search/{q}"),
    ("doaj", "DOAJ — открытые журналы", "Наука", "free", doaj, "", "https://doaj.org/search/articles?source=%7B%22query%22%3A%7B%22query_string%22%3A%7B%22query%22%3A%22{q}%22%7D%7D%7D"),
    ("datacite", "DataCite — исследовательские данные", "Данные", "free", datacite, "", "https://commons.datacite.org/?query={q}"),
    ("zenodo", "Zenodo — данные, ПО, препринты", "Данные", "free", zenodo, "", "https://zenodo.org/search?q={q}"),
    ("osti", "OSTI.GOV — энергетика и физика", "Наука", "free", osti, "", "https://www.osti.gov/search/semantic:{q}"),
    ("core", "CORE — репозитории", "Наука", "key", core, "https://core.ac.uk/services/api#form", "https://core.ac.uk/search?q={q}"),
    ("hal", "HAL — открытые исследования", "Наука", "free", hal, "", "https://hal.science/search/index/?q={q}"),
    ("ssrn", "SSRN — экономика и общество", "Экономика", "free", ssrn, "", "https://papers.ssrn.com/sol3/results.cfm?txtKey_Words={q}"),
    ("repec", "RePEc — экономика и финансы", "Экономика", "key", repec, "https://ideas.repec.org/api.html", "https://ideas.repec.org/cgi-bin/htsearch?q={q}"),
    ("ads", "NASA ADS — космос и астрофизика", "Наука", "key", nasa_ads, "https://ui.adsabs.harvard.edu/user/settings/token", "https://ui.adsabs.harvard.edu/search/q={q}"),
    ("clinicaltrials", "ClinicalTrials.gov — испытания", "Клиника", "free", clinicaltrials, "", "https://clinicaltrials.gov/search?term={q}"),
    ("who", "WHO ICTRP — испытания", "Клиника", "link", None, "https://www.who.int/tools/clinical-trials-registry-platform", "https://trialsearch.who.int/?SearchAll={q}"),
    ("epo", "EPO OPS — европейские патенты", "Патенты", "key", epo_ops, "https://developers.epo.org/", "https://worldwide.espacenet.com/patent/search?q={q}"),
    ("uspto", "USPTO / PatentsView — патенты США", "Патенты", "key", patentsview, "https://patentsview-support.atlassian.net/servicedesk/customer/portals", "https://ppubs.uspto.gov/pubwebapp/"),
    ("lens", "Lens.org — патенты + статьи", "Патенты", "key", lens, "https://www.lens.org/lens/user/subscriptions#scholar", "https://www.lens.org/lens/search/patent/list?q={q}"),
    ("gdelt", "GDELT — мировые медиа", "СМИ", "free", gdelt, "", "https://api.gdeltproject.org/api/v2/doc/doc?query={q}&mode=artlist"),
    ("isfdb", "ISFDB / Open Library — фантастика", "Фантастика", "free", openlibrary, "", "https://www.isfdb.org/cgi-bin/se.cgi?arg={q}&type=All+Titles"),
    # Аналоги, добавленные в соответствии с методологией
    ("patents", "Google Patents — мировые патенты (аналог, без ключа)", "Патенты", "free", google_patents, "", "https://patents.google.com/?q=({q})"),
    ("cyberleninka", "КиберЛенинка — российские научные статьи (аналог)", "Наука", "free", cyberleninka, "", "https://cyberleninka.ru/search?q={q}"),
]

SOURCE_INDEX = {s[0]: s for s in SOURCES}
# Источники, использующиеся по умолчанию (бесплатные и надёжные)
DEFAULT_SOURCES = ["arxiv", "openalex", "crossref", "pubmed", "biorxiv", "doaj", "zenodo", "osti", "hal", "ssrn",
                   "clinicaltrials", "gdelt", "isfdb", "patents", "cyberleninka", "datacite", "semantic"]
# Источники, которые принимают русскоязычный запрос
RU_SOURCES = {"cyberleninka"}

ACCESS_RU = {"free": "без ключа", "optional": "без ключа (ключ повышает лимиты)", "key": "нужен API-ключ",
             "link": "нет открытого API — ссылки для ручной проверки"}


def registry(keys: Dict[str, str]) -> List[Dict]:
    out = []
    for sid, name, group, access, fn, key_url, search_url in SOURCES:
        has_key = bool(keys.get(sid))
        usable = access in ("free", "optional") or (access == "key" and has_key)
        out.append({"id": sid, "name": name, "group": group, "access": access, "access_ru": ACCESS_RU[access],
                    "key_url": key_url, "has_key": has_key, "usable": usable and fn is not None,
                    "search_url": search_url, "default": sid in DEFAULT_SOURCES,
                    "key_hint": "consumer_key:consumer_secret" if sid == "epo" else ""})
    return out


def manual_link(sid: str, q: str) -> str:
    s = SOURCE_INDEX.get(sid)
    return s[6].replace("{q}", quote_plus(q)) if s else ""


async def fetch_source(client: httpx.AsyncClient, sid: str, q: str, limit: int, key: Optional[str]) -> Dict:
    s = SOURCE_INDEX[sid]
    t0 = time.time()
    access, fn = s[3], s[4]
    if fn is None:
        return {"id": sid, "status": "link", "docs": [], "error": "", "ms": 0, "link": manual_link(sid, q)}
    if access == "key" and not key:
        return {"id": sid, "status": "need_key", "docs": [], "error": "Требуется API-ключ", "ms": 0, "link": manual_link(sid, q)}
    try:
        docs = await fn(client, q, limit, key)
        return {"id": sid, "status": "ok", "docs": docs, "error": "", "ms": int((time.time() - t0) * 1000), "link": manual_link(sid, q)}
    except httpx.HTTPStatusError as e:
        code = e.response.status_code
        msg = {401: "ключ недействителен", 403: "доступ запрещён / нужен ключ", 429: "превышен лимит запросов"}.get(code, "HTTP %d" % code)
        return {"id": sid, "status": "error", "docs": [], "error": msg, "ms": int((time.time() - t0) * 1000), "link": manual_link(sid, q)}
    except Exception as e:  # сеть, таймаут, формат
        return {"id": sid, "status": "error", "docs": [], "error": type(e).__name__ + ": " + str(e)[:160],
                "ms": int((time.time() - t0) * 1000), "link": manual_link(sid, q)}


def make_client() -> httpx.AsyncClient:
    return httpx.AsyncClient(timeout=TIMEOUT, headers={"User-Agent": UA}, follow_redirects=True)


async def test_source(sid: str, key: Optional[str]) -> Dict:
    async with make_client() as c:
        r = await fetch_source(c, sid, "neuromorphic computing" if sid not in RU_SOURCES else "нейроморфные вычисления", 2, key)
    return {"id": sid, "status": r["status"], "n": len(r["docs"]), "error": r["error"], "ms": r["ms"]}
