# -*- coding: utf-8 -*-
"""
FastAPI backend «Справочник слабых сигналов».
Документация API (Swagger): /docs   ·   ReDoc: /redoc
"""
import asyncio
import datetime as dt
import logging
import os
import re
import shutil
import tempfile
from typing import Dict, List, Optional

from fastapi import BackgroundTasks, Depends, FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import auth, db
from .connectors import sources as S
from .ml import features as F
from .ml.dataset import DEFAULT_DATASET, read_table, to_records
from .ml.model import CONFIDENT, get_model, reset_model
from .services import llm, pipeline

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("api")

VERSION = "3.1.0"
app = FastAPI(title="Справочник слабых сигналов — API", version=VERSION,
              description="Сервис автоматизированного сбора и анализа зарождающихся трендов (слабых сигналов) "
                          "в научно-технологических отраслях. (С) РуНео 2026")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

ENV_KEYS = {"openalex": "OPENALEX_API_KEY", "semantic": "SEMANTIC_SCHOLAR_API_KEY", "newsapi": "NEWSAPI_KEY",
            "core": "CORE_API_KEY", "ads": "NASA_ADS_TOKEN", "lens": "LENS_API_TOKEN", "epo": "EPO_OPS_KEY",
            "uspto": "PATENTSVIEW_API_KEY", "repec": "REPEC_API_CODE", "zenodo": "ZENODO_TOKEN"}


# ---------------------------------------------------------------------------
# Схемы
# ---------------------------------------------------------------------------
class PasswordIn(BaseModel):
    password: str


class ChangePasswordIn(BaseModel):
    current: str
    new: str = Field(min_length=4)


class RequireIn(BaseModel):
    require_password: bool
    current: str


class KeyIn(BaseModel):
    source_id: str
    key: str


class LLMIn(BaseModel):
    provider: str = ""
    model: str = ""
    api_key: str = ""
    folder_id: str = ""
    base_url: str = ""


class SearchIn(BaseModel):
    query: str = Field(min_length=2, max_length=300)
    mode: str = Field("hybrid", pattern="^(hybrid|methodology|library)$")
    sources: Optional[List[str]] = None


class ScoreIn(BaseModel):
    name: str
    why: str = ""
    stage: str = ""
    trend: str = ""
    companies: str = ""
    sources: str = ""
    mode: str = "hybrid"


# ---------------------------------------------------------------------------
# Утилиты
# ---------------------------------------------------------------------------
_RUNTIME_KEYS = {}
_LLM_CONFIG = {}

def keys() -> Dict[str, str]:
    k = dict(_RUNTIME_KEYS)
    for sid, env in ENV_KEYS.items():
        if os.getenv(env) and not k.get(sid):
            k[sid] = os.getenv(env)
    return k


def _mask(v: str) -> str:
    return (v[:3] + "…" + v[-2:]) if v and len(v) > 6 else ("•••" if v else "")


def persist(kind: str, payload: Dict):
    job = payload["job"]
    with db.session() as s:
        run = s.get(db.SearchRun, job["id"])
        if run is None:
            run = db.SearchRun(id=job["id"], query=job["query"], mode=job["mode"], sources=job["sources"], status=job["status"])
            s.add(run)
            s.flush()
        if kind == "documents":
            run.query_en = job.get("query_en")
            for d in payload["docs"]:
                s.add(db.RawDocument(run_id=job["id"], source_id=d.get("source_id"), source_type=d.get("source_type"),
                                     title=d.get("title"), abstract=d.get("abstract"), url=d.get("url"), pub_date=d.get("date"),
                                     year=d.get("year"), language=d.get("language"), trust=d.get("trust"),
                                     authors=d.get("authors"), venue=d.get("venue")))
        elif kind == "result":
            r = job.get("result") or {}
            run.status = job["status"]
            if not r:
                run.result = {"error": job.get("error"), "log": job.get("log", [])}
                run.finished_at = dt.datetime.utcnow()
                return
            s.query(db.Candidate).filter(db.Candidate.run_id == job["id"]).delete(synchronize_session=False)
            run.finished_at = dt.datetime.utcnow()
            run.stats = r.get("stats")
            run.result = r
            for it in r.get("items", []):
                s.add(db.Candidate(run_id=job["id"], rank=it["rank"], name=it["name"], name_original=it["name_original"],
                                   probability=it["probability"], is_weak_signal=it["is_weak_signal"], excluded=False,
                                   payload={k: it[k] for k in ("stage", "trend", "strength", "impact", "horizon")}))
            for e in r.get("excluded", []):
                s.add(db.Candidate(run_id=job["id"], rank=None, name=e.get("name_ru") or e["name"], name_original=e["name"],
                                   probability=e["probability"], is_weak_signal=False, excluded=True, payload={"reasons": e["reasons"]}))


_MD_LINK = re.compile(r"\[([^\]]+)\]\((https?://[^)\s]+)\)")
_CATALOG: List[Dict] = []


def build_catalog() -> List[Dict]:
    """Базовые карточки справочника — 100 размеченных слабых сигналов из датасета (с моделью и ссылками)."""
    model = get_model()
    recs = to_records(read_table(DEFAULT_DATASET), default_label=1, origin="dataset")
    out = []
    for r in recs:
        sc = model.score_record(r, mode="hybrid")
        lvl = int(sc["features"]["stage_level"])
        links = [{"label": m.group(1), "url": m.group(2)} for m in _MD_LINK.finditer(r["sources"] or "")]
        out.append({
            "id": "ds-%d" % r["row"], "origin": "Датасет «100 слабых сигналов (сентябрь 2026)»", "name": r["name"], "industry": r["area"],
            "description": r["why"], "companies": r["companies"], "stage": r["stage"], "trend": r["trend"],
            "strength": "Слабый" if lvl <= 2 else ("Средний" if lvl <= 4 else "Сильный"),
            "impact": "Очень высокий" if sc["features"]["micro_effects"] + sc["features"]["principle_shift"] >= 0.8 else ("Высокий" if sc["probability"] >= 0.75 else "Средний"),
            "horizon": {1: "10–15 лет", 2: "5–10 лет", 3: "3–7 лет", 4: "2–5 лет"}.get(lvl, "0–2 года"),
            "probability": sc["probability"], "p_model": sc["p_model"], "p_methodology": sc["p_methodology"],
            "confident": sc["probability"] >= CONFIDENT, "predictors": sc["predictors"][:5], "triz_evidence": sc["triz_evidence"],
            "exclusion_reasons": sc["exclusion_reasons"], "links": links, "keywords": [w for w in re.findall(r"[A-Za-zА-Яа-яЁё\-]{4,}", r["name"])][:4],
            "date": "2026-09",
        })
    return out


@app.on_event("startup")
def _startup():
    db.init_db()
    # Delete legacy plaintext secrets on upgrade; operator re-enters them.
    with db.session() as session:
        session.query(db.Setting).filter(db.Setting.key.in_(["api_keys", "llm_config"])).delete(synchronize_session=False)
        for run in session.query(db.SearchRun).filter(db.SearchRun.status == "running").all():
            run.status = "error"
            run.finished_at = dt.datetime.utcnow()
            run.result = {"error": "Поиск прерван перезапуском сервера", "log": [], "items": [], "excluded": []}
    global _CATALOG
    _CATALOG = build_catalog()
    log.info("БД: %s; модель загружена; карточек в справочнике: %d", db.db_kind(), len(_CATALOG))


# ---------------------------------------------------------------------------
# Служебные
# ---------------------------------------------------------------------------
@app.get("/api/health", tags=["Служебные"], summary="Состояние сервиса, БД и модели")
def health():
    m = get_model()
    try:
        db_ok = db.ping()
    except Exception:
        db_ok = False
    return {"status": "ok", "version": VERSION, "database": db.db_kind(), "database_ok": db_ok,
            "model": m.meta, "llm": llm.model_name() if llm.available() else None, "time": dt.datetime.now().isoformat(timespec="seconds")}


# ---------------------------------------------------------------------------
# Вход
# ---------------------------------------------------------------------------
@app.get("/api/auth/status", tags=["Вход"], summary="Задан ли пароль и требуется ли он при входе")
def auth_status():
    return {"password_set": auth.password_set(), "require_password": auth.require_password()}


@app.post("/api/auth/setup", tags=["Вход"], summary="Первичная установка пароля")
def auth_setup(body: PasswordIn):
    if auth.password_set():
        raise HTTPException(409, "Пароль уже задан")
    auth.set_password(body.password)
    return {"token": auth.issue_token(), "require_password": auth.require_password()}


@app.post("/api/auth/login", tags=["Вход"], summary="Вход по паролю (выдаёт токен)")
def auth_login(body: PasswordIn):
    if not auth.check_password(body.password):
        db.audit("login_failed")
        raise HTTPException(401, "Неверный пароль")
    db.audit("login")
    return {"token": auth.issue_token()}


@app.post("/api/auth/open", tags=["Вход"], summary="Вход без пароля (если запрос пароля отключён)")
def auth_open():
    """Вход без пароля — разрешён, только если оператор отключил запрос пароля."""
    if not auth.password_set() or auth.require_password():
        raise HTTPException(401, "Требуется пароль")
    return {"token": auth.issue_token()}


@app.post("/api/auth/change", tags=["Вход"], summary="Смена пароля", dependencies=[Depends(auth.guard)])
def auth_change(body: ChangePasswordIn):
    if not auth.check_password(body.current):
        raise HTTPException(400, "Текущий пароль указан неверно")
    auth.set_password(body.new)
    return {"ok": True}


@app.post("/api/auth/require", tags=["Вход"], summary="Включить/выключить запрос пароля при входе", dependencies=[Depends(auth.guard)])
def auth_require(body: RequireIn):
    if not auth.check_password(body.current):
        raise HTTPException(400, "Текущий пароль указан неверно")
    db.set_setting("require_password", "1" if body.require_password else "0")
    db.audit("require_password", {"value": body.require_password})
    return {"require_password": body.require_password}


# ---------------------------------------------------------------------------
# Источники и ключи
# ---------------------------------------------------------------------------
@app.get("/api/sources", tags=["Источники"], summary="Список источников и статус ключей", dependencies=[Depends(auth.guard)])
def sources_list():
    k = keys()
    reg = S.registry(k)
    for r in reg:
        r["key_masked"] = _mask(k.get(r["id"], ""))
        r["key_from_env"] = bool(os.getenv(ENV_KEYS.get(r["id"], "_none_")))
    return reg


@app.post("/api/sources/test", tags=["Источники"], summary="Проверка подключения к источникам", dependencies=[Depends(auth.guard)])
async def sources_test(ids: Optional[List[str]] = None):
    k = keys()
    ids = ids or [s[0] for s in S.SOURCES]
    sem = asyncio.Semaphore(8)

    async def one(i):
        async with sem:
            return await S.test_source(i, k.get(i))
    return await asyncio.gather(*[one(i) for i in ids if i in S.SOURCE_INDEX])


@app.put("/api/keys", tags=["Источники"], summary="Сохранить API-ключ источника и проверить его", dependencies=[Depends(auth.guard)])
async def key_set(body: KeyIn):
    if body.source_id not in S.SOURCE_INDEX:
        raise HTTPException(404, "Неизвестный источник")
    k = dict(_RUNTIME_KEYS)
    k[body.source_id] = body.key.strip()
    _RUNTIME_KEYS.clear()
    _RUNTIME_KEYS.update(k)
    db.audit("api_key_set", {"source": body.source_id})
    test = await S.test_source(body.source_id, body.key.strip())
    return {"ok": True, "test": test}


@app.delete("/api/keys/{source_id}", tags=["Источники"], summary="Удалить сохранённый ключ", dependencies=[Depends(auth.guard)])
def key_delete(source_id: str):
    k = dict(_RUNTIME_KEYS)
    k.pop(source_id, None)
    _RUNTIME_KEYS.clear()
    _RUNTIME_KEYS.update(k)
    return {"ok": True}


@app.get("/api/llm", tags=["Источники"], summary="Настройки генеративной модели", dependencies=[Depends(auth.guard)])
def llm_get():
    cfg = dict(_LLM_CONFIG)
    return {"available": llm.available(), "model": llm.model_name() if llm.available() else None,
            "provider": cfg.get("provider", os.getenv("LLM_PROVIDER", "")), "model_name": cfg.get("model", os.getenv("LLM_MODEL", "")),
            "key_masked": _mask(cfg.get("api_key", "")), "allowed_models": llm.ALLOWED_MODELS, "calls": llm.calls()}


@app.put("/api/llm", tags=["Источники"], summary="Настройки генеративной модели", dependencies=[Depends(auth.guard)])
def llm_set(body: LLMIn):
    if body.model and body.model not in llm.ALLOWED_MODELS:
        raise HTTPException(400, "Модель не входит в список, разрешённый ТЗ: " + ", ".join(llm.ALLOWED_MODELS))
    cfg = body.model_dump()
    old = dict(_LLM_CONFIG)
    if not cfg.get("api_key") and old.get("api_key") and cfg.get("provider") == old.get("provider"):
        cfg["api_key"] = old["api_key"]  # ключ не возвращается в браузер — при пустом поле сохраняем прежний
    try:
        llm.validate_config(cfg)
    except ValueError as e:
        raise HTTPException(400, str(e))
    llm.configure(**cfg)
    _LLM_CONFIG.clear()
    _LLM_CONFIG.update(cfg)
    db.audit("llm_config", {"provider": body.provider, "model": body.model})
    return {"available": llm.available(), "model": llm.model_name()}


# ---------------------------------------------------------------------------
# Открытый поиск
# ---------------------------------------------------------------------------
@app.post("/api/search", tags=["Поиск"], summary="Запустить открытый поиск (фоновая задача)", dependencies=[Depends(auth.guard)])
async def search_start(body: SearchIn):
    srcs = body.sources or list(S.DEFAULT_SOURCES)
    job = pipeline.new_job(body.query.strip(), body.mode, srcs)
    persist("documents", {"job": job, "docs": []})
    job["_task"] = asyncio.get_event_loop().create_task(pipeline.run(job, keys(), persist=persist))
    return {"id": job["id"], "status": job["status"]}


@app.get("/api/search/{job_id}", tags=["Поиск"], summary="Прогресс и результат поиска (ТОП-15)", dependencies=[Depends(auth.guard)])
def search_status(job_id: str, full: bool = True):
    job = pipeline.JOBS.get(job_id)
    if job is None:
        with db.session() as s:
            run = s.get(db.SearchRun, job_id)
            if run is None:
                raise HTTPException(404, "Поиск не найден")
            return {"id": run.id, "query": run.query, "mode": run.mode, "status": run.status or "done", "progress": 100,
                    "stage": "Готово" if run.status == "done" else "Поиск завершён с ошибкой",
                    "error": (run.result or {}).get("error"), "log": (run.result or {}).get("log", []),
                    "result": run.result if (run.result or {}).get("stats") is not None else None}
    out = {k: v for k, v in job.items() if not k.startswith("_")}
    if not full and out.get("status") == "running":
        out.pop("result", None)
    return out


@app.post("/api/search/{job_id}/cancel", tags=["Поиск"], summary="Остановить выполняющийся поиск", dependencies=[Depends(auth.guard)])
def search_cancel(job_id: str):
    job = pipeline.JOBS.get(job_id)
    if job is None or job.get("status") != "running":
        raise HTTPException(409, "Поиск не выполняется")
    t = job.get("_task")
    if t is not None:
        t.cancel()
    return {"ok": True}


@app.delete("/api/runs/{run_id}", tags=["Поиск"], summary="Удалить запуск из истории", dependencies=[Depends(auth.guard)])
def run_delete(run_id: str):
    with db.session() as s:
        s.query(db.RawDocument).filter(db.RawDocument.run_id == run_id).delete()
        s.query(db.Candidate).filter(db.Candidate.run_id == run_id).delete()
        n = s.query(db.SearchRun).filter(db.SearchRun.id == run_id).delete()
    pipeline.JOBS.pop(run_id, None)
    if not n:
        raise HTTPException(404, "Запуск не найден")
    return {"ok": True}


@app.get("/api/runs", tags=["Поиск"], summary="История запусков", dependencies=[Depends(auth.guard)])
def runs(limit: int = 30):
    with db.session() as s:
        rows = s.query(db.SearchRun).order_by(db.SearchRun.started_at.desc()).limit(limit).all()
        return [{"id": r.id, "query": r.query, "mode": r.mode, "status": r.status, "stats": r.stats,
                 "started_at": r.started_at.isoformat(timespec="seconds") if r.started_at else None} for r in rows]


@app.get("/api/runs/{run_id}/documents", tags=["Поиск"], summary="Сырые документы запуска", dependencies=[Depends(auth.guard)])
def run_documents(run_id: str, limit: int = 500):
    with db.session() as s:
        rows = s.query(db.RawDocument).filter(db.RawDocument.run_id == run_id).limit(limit).all()
        return [{"source_id": r.source_id, "type": r.source_type, "title": r.title, "url": r.url, "date": r.pub_date,
                 "language": r.language, "trust": r.trust} for r in rows]


# ---------------------------------------------------------------------------
# Справочник (карточки)
# ---------------------------------------------------------------------------
@app.get("/api/catalog", tags=["Справочник"], summary="Карточки справочника", dependencies=[Depends(auth.guard)])
def catalog():
    items = list(_CATALOG)
    with db.session() as s:
        runs_ = s.query(db.SearchRun).filter(db.SearchRun.status == "done").order_by(db.SearchRun.started_at.desc()).limit(20).all()
        seen = set(i["name"].lower() for i in items)
        for r in runs_:
            for it in ((r.result or {}).get("items") or []):
                if it["name"].lower() in seen:
                    continue
                seen.add(it["name"].lower())
                items.append({
                    "id": it["id"], "origin": "Открытый поиск: «%s»" % r.query, "name": it["name"], "name_original": it.get("name_original"),
                    "industry": r.query, "description": it.get("description"), "stage": it.get("stage"), "trend": it.get("trend"),
                    "strength": it.get("strength"), "impact": it.get("impact"), "horizon": it.get("horizon"),
                    "probability": it.get("probability"), "p_model": it.get("p_model"), "p_methodology": it.get("p_methodology"),
                    "confident": it.get("confident"), "predictors": it.get("predictors", [])[:5], "triz_evidence": it.get("triz_evidence"),
                    "exclusion_reasons": it.get("exclusion_reasons"), "links": [{"label": (x.get("source") or "Источник"), "url": x.get("url")} for x in it.get("sources", [])[:6]],
                    "keywords": it.get("keywords", []), "date": (r.started_at.strftime("%Y-%m") if r.started_at else ""), "run_id": r.id,
                    "full": it, "companies": it.get("companies", ""),
                })
    return items


# ---------------------------------------------------------------------------
# Модель и проверка методологии
# ---------------------------------------------------------------------------
@app.get("/api/model/info", tags=["Модель"], summary="Метрики, коэффициенты и отчёт о валидации", dependencies=[Depends(auth.guard)])
def model_info():
    import json
    m = get_model()
    rep_path = os.path.join(db.BACKEND_DIR, "reports", "validation_report.json")
    rep = json.load(open(rep_path, encoding="utf-8")) if os.path.exists(rep_path) else {}
    return {"meta": m.meta, "coefficients": m.coefficients(), "features": [{"name": k, "title": v[0], "meaning": v[1]} for k, v in F.FEATURE_INFO.items()],
            "blocks": F.FEATURE_BLOCKS, "report": {k: rep.get(k) for k in ("generated_at", "n_total", "n_weak_signals", "n_background",
                                                                             "main_model_repeated_cv", "main_model_oof", "leave_one_area_out",
                                                                             "methodology_index_no_training", "baseline_random_forest",
                                                                             "baseline_tfidf_text", "baseline_stage_only", "ablation_triz_only",
                                                                             "stress_test_hard_background", "target_met", "errors")}}


@app.get("/api/model/predictions", tags=["Модель"], summary="Предсказания по каждой строке датасета (out-of-fold)", dependencies=[Depends(auth.guard)])
def model_predictions():
    import csv
    p = os.path.join(db.BACKEND_DIR, "reports", "predictions.csv")
    if not os.path.exists(p):
        raise HTTPException(404, "Отчёт не сформирован: выполните обучение")
    with open(p, encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


@app.post("/api/model/score", tags=["Модель"], summary="Оценить одну технологию", dependencies=[Depends(auth.guard)])
def model_score(body: ScoreIn):
    return get_model().score_record(body.model_dump(), mode=body.mode)


def _save_upload(file: UploadFile) -> str:
    ext = os.path.splitext(file.filename or "")[1].lower()
    if ext not in (".xlsx", ".xls", ".csv", ".json"):
        raise HTTPException(400, "Поддерживаются файлы .xlsx, .csv, .json")
    fd, path = tempfile.mkstemp(suffix=ext)
    with os.fdopen(fd, "wb") as out:
        shutil.copyfileobj(file.file, out)
    return path


@app.post("/api/model/validate", tags=["Модель"], summary="Проверить методологию на загруженном файле", dependencies=[Depends(auth.guard)])
def model_validate(file: UploadFile = File(...)):
    """Проверка методологии на загруженном датасете. Если есть столбец label/Метка — считаются Precision/Recall/F1."""
    from .ml.train import evaluate_file
    path = _save_upload(file)
    try:
        return evaluate_file(path)
    except ValueError as e:
        raise HTTPException(400, str(e))
    finally:
        os.remove(path)


@app.post("/api/model/retrain", tags=["Модель"], summary="Переобучить модель", dependencies=[Depends(auth.guard)])
def model_retrain(file: Optional[UploadFile] = File(default=None)):
    """Переобучение: на встроенном датасете или на загруженном файле с положительными примерами (слабыми сигналами)."""
    from .ml import train
    path = _save_upload(file) if file is not None else DEFAULT_DATASET
    try:
        rep = train.run(dataset_path=path, write_docs=file is None)
    finally:
        if file is not None:
            os.remove(path)
    reset_model(None)
    global _CATALOG
    _CATALOG = build_catalog()
    db.audit("retrain", {"accuracy": rep["main_model_repeated_cv"]["accuracy"]})
    return {"accuracy": rep["main_model_repeated_cv"], "target_met": rep["target_met"], "stress_test": rep.get("stress_test_hard_background")}


@app.get("/api/model/report.md", tags=["Модель"], summary="Отчёт о валидации (Markdown)")
def model_report_md():
    p = os.path.join(os.path.dirname(db.BACKEND_DIR), "docs", "dataset-validation-report.md")
    if not os.path.exists(p):
        p = os.path.join(db.BACKEND_DIR, "reports", "dataset-validation-report.md")
    if not os.path.exists(p):
        raise HTTPException(404, "Отчёт не найден")
    return FileResponse(p, media_type="text/markdown; charset=utf-8", filename="dataset-validation-report.md")


# ---------------------------------------------------------------------------
# Web-интерфейс (собранный React)
# ---------------------------------------------------------------------------
STATIC_DIR = os.getenv("STATIC_DIR", os.path.join(db.BACKEND_DIR, "static"))
if os.path.isdir(STATIC_DIR) and os.path.exists(os.path.join(STATIC_DIR, "index.html")):
    app.mount("/assets", StaticFiles(directory=os.path.join(STATIC_DIR, "assets")), name="assets")

    @app.get("/", include_in_schema=False)
    def index():
        return FileResponse(os.path.join(STATIC_DIR, "index.html"))

    @app.get("/{path:path}", include_in_schema=False)
    def spa(path: str):
        if path.startswith("api/"):
            raise HTTPException(404)
        fp = os.path.join(STATIC_DIR, path)
        if os.path.isfile(fp):
            return FileResponse(fp)
        return FileResponse(os.path.join(STATIC_DIR, "index.html"))

else:
    # Интерфейс не собран — вместо «404» показываем понятную страницу
    from fastapi.responses import HTMLResponse

    @app.get("/", include_in_schema=False, response_class=HTMLResponse)
    def index_missing():
        return HTMLResponse("""<!doctype html><html lang="ru"><meta charset="utf-8"><title>Справочник слабых сигналов</title>
<body style="font-family:system-ui,sans-serif;max-width:720px;margin:60px auto;line-height:1.6">
<h1>🔭 Справочник слабых сигналов</h1><p><b>Backend работает</b>, но собранный интерфейс не найден в папке <code>backend/static</code>.</p>
<p>Соберите его: <code>cd frontend &amp;&amp; npm install &amp;&amp; npm run build</code>, затем скопируйте папку <code>frontend/dist</code> в <code>backend/static</code> и перезапустите сервер.</p>
<p>Документация API: <a href="/docs">/docs</a></p><p style="position:fixed;right:16px;bottom:10px">(С) РуНео 2026</p></body></html>""")
