# -*- coding: utf-8 -*-
"""
Вход в справочник.

* При первом запуске оператор задаёт пароль (хранится как bcrypt-хеш в БД).
* В настройках можно: сменить пароль; выбрать «запрашивать пароль при входе» или «не запрашивать».
* Если пароль не запрашивается — API открыт без токена (удобно для демо-стенда жюри);
  изменение настроек безопасности всё равно требует текущий пароль.
"""
import datetime as dt
import os
import secrets
from typing import Optional

import bcrypt
import jwt
from fastapi import Header, HTTPException

from . import db

ALG = "HS256"


def _secret() -> str:
    s = os.getenv("JWT_SECRET") or db.get_setting("jwt_secret")
    if not s:
        s = secrets.token_hex(32)
        db.set_setting("jwt_secret", s)
    return s


def password_set() -> bool:
    return bool(db.get_setting("password_hash"))


def require_password() -> bool:
    return db.get_setting("require_password", "1") == "1"


def set_password(pw: str):
    if len(pw or "") < 4:
        raise HTTPException(400, "Пароль должен содержать минимум 4 символа")
    h = bcrypt.hashpw(pw.encode("utf-8"), bcrypt.gensalt()).decode("ascii")
    db.set_setting("password_hash", h)
    db.audit("password_set")


def check_password(pw: str) -> bool:
    h = db.get_setting("password_hash")
    if not h:
        return False
    try:
        return bcrypt.checkpw((pw or "").encode("utf-8"), h.encode("ascii"))
    except Exception:
        return False


def issue_token(hours: int = 12) -> str:
    payload = {"sub": "operator", "exp": dt.datetime.utcnow() + dt.timedelta(hours=hours)}
    return jwt.encode(payload, _secret(), algorithm=ALG)


def valid_token(tok: Optional[str]) -> bool:
    if not tok:
        return False
    try:
        jwt.decode(tok, _secret(), algorithms=[ALG])
        return True
    except Exception:
        return False


def guard(authorization: Optional[str] = Header(default=None)):
    """Зависимость FastAPI: пропускает, если пароль не требуется или токен корректен."""
    if not password_set():
        raise HTTPException(401, "Пароль ещё не задан — выполните первичную настройку")
    if not require_password():
        return True
    tok = (authorization or "").replace("Bearer ", "").strip()
    if not valid_token(tok):
        raise HTTPException(401, "Требуется вход")
    return True
