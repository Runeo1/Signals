# -*- coding: utf-8 -*-
"""
Поисково-аналитический пайплайн открытого запроса.

  запрос (RU/EN) → перевод → сбор из источников (параллельно) → очистка и дедупликация
  → выделение кандидатов → доказательства по 4 слоям → признаки методологии
  → скоринг (модель + ТРИЗ-индекс) → исключение зрелых/хайпа/шума → ТОП-15
  → русскоязычные отчёты по каждому инсайту.

Режимы оператора:
  methodology — авторская методология (ТРИЗ-индекс) через API источников;
  library     — простое получение сведений о зарождающихся трендах из библиотек
                (ранжирование по частоте, свежести и разнообразию источников);
  hybrid      — модель, обученная на датасете + ТРИЗ-индекс (по умолчанию).
"""
import asyncio
import datetime as dt
import logging
import math
import re
import time
import uuid
from typing import Callable, Dict, List, Optional

from ..connectors import sources as S
from ..ml import features as F
from ..ml.model import CONFIDENT, THRESHOLD, get_model
from . import evidence as E
from . import llm
from .quality import evidence_gate, case_example, report_issues
from .candidates import extract_candidates
from .translate import has_cyrillic, query_to_english, translate, translate_many

log = logging.getLogger("pipeline")

GROUP_OF = {s[0]: s[2] for s in S.SOURCES}
LIMITS = {"arxiv": 40, "openalex": 50, "crossref": 30, "pubmed": 30, "biorxiv": 25, "doaj": 25, "zenodo": 20, "osti": 25,
          "hal": 25, "ssrn": 20, "clinicaltrials": 20, "gdelt": 60, "isfdb": 15, "patents": 40, "cyberleninka": 15,
          "datacite": 15, "semantic": 40, "newsapi": 50, "core": 25, "ads": 25, "lens": 25, "uspto": 25, "epo": 25, "repec": 20}

JOBS: Dict[str, Dict] = {}


async def to_thread(fn, *args):
    """Совместимо с Python 3.8 (asyncio.to_thread появился в 3.9)."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, fn, *args)


def new_job(query: str, mode: str, source_ids: List[str]) -> Dict:
    jid = uuid.uuid4().hex[:12]
    job = {"id": jid, "query": query, "mode": mode, "sources": source_ids, "status": "running", "progress": 0,
           "stage": "Подготовка", "log": [], "result": None, "error": None, "started_at": dt.datetime.now().isoformat(timespec="seconds"),
           "finished_at": None, "eta_sec": None}
    JOBS[jid] = job
    return job


def _p(job, pct, stage, msg=None):
    job["progress"] = int(pct)
    job["stage"] = stage
    el = time.time() - job.setdefault("_t0", time.time())
    if pct > 3:
        job["eta_sec"] = int(el / (pct / 100.0) - el)
    if msg:
        job["log"].append("%s · %s" % (time.strftime("%H:%M:%S"), msg))


def _norm_title(t: str) -> str:
    return re.sub(r"[^a-zа-я0-9]", "", (t or "").lower())[:90]


def dedupe(docs: List[Dict]) -> List[Dict]:
    seen, out = set(), []
    for d in docs:
        k = (d.get("url") or "").lower().replace("http://", "https://")
        nt = _norm_title(d.get("title"))
        if not nt or len(nt) < 8:
            continue
        if nt in seen or (k and k in seen):
            continue
        seen.add(nt)
        if k:
            seen.add(k)
        out.append(d)
    return out


def _stage_to_strength(level: int) -> str:
    return "Слабый" if level <= 2 else ("Средний" if level <= 4 else "Сильный")


def _horizon(level: int) -> str:
    return {1: "10–15 лет", 2: "5–10 лет", 3: "3–7 лет", 4: "2–5 лет"}.get(level, "0–2 года (уже на рынке)")


def _impact(f: Dict, growth: Optional[float]) -> str:
    s = f.get("micro_effects", 0) + f.get("principle_shift", 0) + f.get("supersystem", 0) + (0.5 if (growth or 0) >= 2 else 0)
    return "Очень высокий" if s >= 1.2 else ("Высокий" if s >= 0.5 else "Средний")


def _first_sentences(text: str, n: int = 2, maxlen: int = 420) -> str:
    ss = re.split(r"(?<=[.!?])\s+", (text or "").strip())
    out = " ".join(ss[:n]).strip()
    return out[:maxlen] + ("…" if len(out) > maxlen else "")


def _benefit_sentence(docs: List[Dict]) -> str:
    pat = re.compile(r"(reduc|lower|improv|increase|enable|faster|cheaper|efficien|without|outperform|save|less|higher|allows?)", re.I)
    for d in docs:
        for s in re.split(r"(?<=[.!?])\s+", d.get("abstract") or ""):
            if pat.search(s) and 40 < len(s) < 350:
                return s.strip()
    return ""


def _source_view(d: Dict, tr: Dict) -> Dict:
    """tr: {'title': (перевод, способ), 'summary': (перевод, способ)} — заранее переведённые поля."""
    lang = (d.get("language") or "en")[:2]
    if lang == "ru":
        ru_title, how = "", ""
        summary, s_how = _first_sentences(d.get("abstract"), 2, 350), "оригинал на русском"
    else:
        ru_title, how = tr.get("title", ("", ""))
        summary, s_how = tr.get("summary", ("", ""))
    return {
        "name": d.get("title"), "name_ru": ru_title if ru_title != d.get("title") else "", "translation_method": how,
        "url": d.get("url"), "date": d.get("date") or (str(d.get("year")) if d.get("year") else ""),
        "type": S.TYPE_RU.get(d.get("source_type"), d.get("source_type")), "source": d.get("source_name"),
        "language": {"en": "английский", "ru": "русский", "fr": "французский", "de": "немецкий", "zh": "китайский",
                     "es": "испанский", "ja": "японский", "ko": "корейский", "pt": "португальский", "it": "итальянский"}.get(lang, lang),
        "trust": d.get("trust") or F.trust_level(d.get("url", ""), d.get("source_type")),
        "summary_ru": summary, "summary_method": s_how, "venue": d.get("venue"), "authors": d.get("authors"),
    }


async def run(job: Dict, keys: Dict[str, str], persist: Optional[Callable] = None, allow_online_translation: bool = True):
    job["_t0"] = time.time()
    try:
        await asyncio.wait_for(_run(job, keys, persist, allow_online_translation), timeout=240)
    except asyncio.CancelledError:
        job["status"] = "cancelled"
        job["error"] = "Поиск остановлен оператором"
        job["log"].append("%s · Поиск остановлен оператором" % time.strftime("%H:%M:%S"))
    except asyncio.TimeoutError:
        job["status"] = "error"
        job["error"] = "Превышен лимит поиска (240 секунд). Проверьте доступность источников."
    except Exception as e:  # never crash the server
        log.exception("search failed")
        job["status"] = "error"
        job["error"] = "%s: %s" % (type(e).__name__, e)
        job["log"].append("Ошибка: %s" % job["error"])
    finally:
        job["finished_at"] = dt.datetime.now().isoformat(timespec="seconds")
        job.pop("_t0", None)
        job["eta_sec"] = 0
        if persist:
            try:
                await to_thread(persist, "result", {"job": job})
            except Exception:
                log.exception("Final state could not be saved")
                job["persistence_error"] = "Не удалось сохранить результат в БД"


async def _run(job, keys, persist, allow_online):
    query, mode = job["query"], job["mode"]
    _p(job, 2, "Перевод запроса", "Запрос: «%s», режим: %s" % (query, mode))
    q_en, how = await to_thread(query_to_english, query, allow_online)
    job["query_en"] = q_en
    _p(job, 5, "Сбор данных из источников", "Англоязычный поисковый запрос: «%s» (%s)" % (q_en, how))

    src_ids = [s for s in job["sources"] if s in S.SOURCE_INDEX]
    statuses = []
    docs: List[Dict] = []
    sem = asyncio.Semaphore(8)
    done = [0]

    async with S.make_client() as client:
        async def one(sid):
            async with sem:
                q = query if (sid in S.RU_SOURCES and has_cyrillic(query)) else q_en
                if sid in S.RU_SOURCES and not has_cyrillic(query):
                    q = (await to_thread(translate, q_en, "en", "ru", allow_online))[0] or q_en
                r = await S.fetch_source(client, sid, q, LIMITS.get(sid, 25), keys.get(sid))
                done[0] += 1
                _p(job, 5 + 35 * done[0] / max(1, len(src_ids)), "Сбор данных из источников",
                   "%s: %s%s" % (S.SOURCE_INDEX[sid][1], {"ok": "получено %d документов" % len(r["docs"]), "need_key": "нужен API-ключ — пропущен",
                                                           "link": "нет открытого API — сформирована ссылка", "error": "недоступен"}[r["status"]],
                                 (" (%s)" % r["error"]) if r["status"] == "error" else ""))
                return r

        results = await asyncio.gather(*[one(s) for s in src_ids])
        for r in results:
            statuses.append(dict({k: r[k] for k in ("id", "status", "error", "ms", "link")}, n=len(r["docs"]), name=S.SOURCE_INDEX[r["id"]][1]))
            docs.extend(r["docs"])
        raw_n = len(docs)
        docs = dedupe(docs)
        _p(job, 42, "Очистка и дедупликация", "Собрано %d документов, после дедупликации %d" % (raw_n, len(docs)))
        if persist:
            try:
                await to_thread(persist, "documents", {"job": job, "docs": docs})
            except Exception as e:
                log.warning("persist docs failed: %s", e)

        if not docs:
            job["result"] = _result(job, q_en, statuses, docs, [], [], [])
            job["status"] = "done"
            _p(job, 100, "Готово", "Источники не вернули документов — проверьте подключение и ключи.")
            return

        cands = extract_candidates(docs, q_en, top_n=60)
        _p(job, 46, "Выделение кандидатов", "Выделено %d технологий-кандидатов из текстов источников" % len(cands))

        news_docs = [d for d in docs if d.get("source_type") == "news"]
        ru_docs = [d for d in docs if (d.get("language") or "")[:2] == "ru"]
        model = get_model()
        scored = []
        n_ev = min(len(cands), 45)
        sem2 = asyncio.Semaphore(6)
        cnt = [0]

        async def ev_one(c):
            async with sem2:
                try:
                    ev = await asyncio.wait_for(E.gather_evidence(client, c["phrase"], keys,
                        use_patents="patents" in src_ids, use_fiction="isfdb" in src_ids), timeout=18)
                except asyncio.TimeoutError:
                    ev = {"growth": E.growth_metrics(None), "coverage": {"publications": "timeout"}}
                cnt[0] += 1
                _p(job, 46 + 34 * cnt[0] / float(n_ev), "Проверка доказательств (публикации, патенты, СМИ, фантастика)",
                   "«%s»: публикаций %s, рост ×%s, патентов %s" % (c["phrase"], ev["growth"].get("total"), ev["growth"].get("growth"),
                                                               (ev.get("patents") or {}).get("total", "—")))
                return ev

        evs = await asyncio.gather(*[ev_one(c) for c in cands[:n_ev]])
        for c, ev in zip(cands[:n_ev], evs):
            cdocs = [docs[i] for i in c["doc_ids"]]
            words = [w for w in c["phrase"].split() if len(w) > 3]
            ev["news_mentions"] = sum(1 for d in news_docs if all(w in (d.get("title") or "").lower() for w in words[:2])) if any(x["status"] == "ok" and x["id"] in {"gdelt", "newsapi"} for x in statuses) else None
            ev.setdefault("coverage", {})["news"] = "ok" if ev["news_mentions"] is not None else "unavailable_or_not_requested"
            t = E.textualize(c, ev, cdocs)
            src_urls = [d["url"] for d in cdocs if d.get("url")]
            if (ev.get("patents") or {}).get("url"):
                src_urls.append(ev["patents"]["url"])
            rec = {"name": c["phrase"], "why": t["why"], "stage": t["stage"], "trend": t["trend"], "companies": t["companies"], "sources": src_urls}
            sc = model.score_record(rec, mode="methodology" if mode == "methodology" else "hybrid")
            # Правило ТЗ: низкодоверенные источники не могут быть единственным основанием
            if all(F.trust_level(u) == "пониженный" for u in src_urls):
                sc["exclusion_reasons"].append("Все источники — с пониженной доверенностью; нет независимого подтверждения.")
                sc["probability"] = min(sc["probability"], 0.4)
            gate = evidence_gate(c["phrase"], cdocs, q_en)
            sc["exclusion_reasons"].extend(gate["reasons"])
            scored.append({"cand": c, "docs": cdocs, "ev": ev, "rec": rec, "score": sc, "quality": gate})
        scored.sort(key=lambda x: -x["score"]["probability"])

        # ---- разделение: ТОП-15 / исключённые ----
        top, excluded = [], []
        for s in scored:
            lvl = int(s["score"]["features"].get("stage_level", 3))
            hard_excl = lvl >= 5 or s["score"]["probability"] < THRESHOLD or not s["quality"]["eligible"]
            if hard_excl:
                excluded.append(s)
            else:
                top.append(s)

        _p(job, 82, "Подготовка русскоязычных отчётов", "Прошли проверку доказательств: %d, исключено: %d" % (len(top), len(excluded)))
        sem3 = asyncio.Semaphore(4)
        ndone = [0]

        async def ins(k, s):
            async with sem3:
                it = await to_thread(_insight, k, s, job, ru_docs, allow_online, mode)
                ndone[0] += 1
                _p(job, 82 + 16 * ndone[0] / float(max(1, len(top))), "Подготовка русскоязычных отчётов", None)
                return it

        items, incomplete = [], []
        # Проверяем следующих кандидатов, если отчёт предыдущего неполон.
        for start in range(0, len(top), 4):
            batch = top[start:start + 4]
            reports = await asyncio.gather(*[ins(start + k, s) for k, s in enumerate(batch, 1)])
            for item in reports:
                issues = report_issues(item)
                item["report_complete"] = not issues
                item["report_issues"] = issues
                if issues:
                    item["is_weak_signal"] = False
                    item["confident"] = False
                    incomplete.append(item)
                elif len(items) < 15:
                    item["rank"] = len(items) + 1
                    items.append(item)
            if len(items) >= 15:
                break
        job["incomplete"] = incomplete
        excl_names = await to_thread(translate_many, [s["cand"]["phrase"] for s in excluded], "en", "ru", allow_online)
        excl_view = []
        for s, (name_ru, _h) in zip(excluded, excl_names):
            excl_view.append({"name": s["cand"]["phrase"], "name_ru": name_ru, "probability": s["score"]["probability"],
                              "stage": s["rec"].get("stage"), "reasons": s["score"]["exclusion_reasons"] or ["Вероятность ниже порога %.0f%%" % (THRESHOLD * 100)],
                              "publications_total": s["ev"].get("growth", {}).get("total")})
    job["result"] = _result(job, q_en, statuses, docs, items, excl_view, scored)
    job["status"] = "done"
    _p(job, 100, "Готово", "Сформирован ТОП-%d; обработано источников: %d, документов: %d" % (len(items), sum(1 for s in statuses if s["status"] == "ok"), len(docs)))


def _insight(rank: int, s: Dict, job: Dict, ru_docs: List[Dict], allow_online: bool, mode: str) -> Dict:
    c, docs, ev, sc = s["cand"], s["docs"], s["ev"], s["score"]
    f = sc["features"]
    lvl = int(f.get("stage_level", 3))
    docs_sorted = sorted(docs, key=lambda d: (d.get("source_type") != "patent", -(d.get("year") or 0)))
    main = next((d for d in docs_sorted if d.get("abstract")), docs_sorted[0])
    desc_en = _first_sentences(main.get("abstract") or main.get("title"), 2, 450)
    ben_en = _benefit_sentence(docs)
    case = case_example(docs_sorted, c["phrase"]) or {"kind": "Кейс не подтверждён", "title": "", "description_original": ""}
    # источники (до 8, не более 3 одного типа)
    picked, seen_types = [], {}
    for d in sorted(docs, key=lambda d: -(d.get("year") or 0)):
        t = d.get("source_type")
        if seen_types.get(t, 0) < 3:
            picked.append(d)
            seen_types[t] = seen_types.get(t, 0) + 1
        if len(picked) >= 8:
            break
    # --- пакетный перевод всех текстов инсайта одним запросом ---
    texts = [c["phrase"], desc_en, ben_en, case.get("description_original", "")]
    for d in picked:
        texts.append(d.get("title", "") if (d.get("language") or "en")[:2] != "ru" else "")
        texts.append(_first_sentences(d.get("abstract"), 2, 350) if (d.get("language") or "en")[:2] != "ru" else "")
    tr = translate_many(texts, "en", "ru", allow_online)
    name_ru, how = tr[0]
    desc_ru, desc_method = tr[1]
    ben_ru = tr[2][0]
    case["description_ru"] = tr[3][0]
    case["title_ru"] = tr[3][0]
    case["translation_method"] = tr[3][1]
    src_tr = [{"title": tr[4 + 2 * j], "summary": tr[5 + 2 * j]} for j in range(len(picked))]
    if not desc_ru:
        desc_ru, desc_method = "", "Перевод недоступен: отчёт неполон"
    ru_words = [w[:6] for w in re.findall(r"[а-яё]{5,}", (name_ru or "").lower())]
    extra_ru = []
    for d in ru_docs:
        t = (d.get("title") or "").lower()
        if ru_words and sum(1 for w in ru_words if w in t) >= min(2, len(ru_words)) and d not in picked:
            extra_ru.append(d)
    sources = [_source_view(d, src_tr[j]) for j, d in enumerate(picked)] + [_source_view(d, {}) for d in extra_ru[:3]]
    g = ev.get("growth") or {}
    fic = ev.get("fiction") or {}
    analytics = []
    if ev.get("pub"):
        analytics.append({"label": "Публикации в мировом научном графе (%s)" % ev["pub"]["source"], "value": g.get("total"), "url": ev["pub"].get("url")})
        if g.get("growth") is not None:
            analytics.append({"label": "Рост публикаций за 2 года (последние 2 года к предыдущим 2)", "value": "×%.1f" % g["growth"]})
        if ev["pub"].get("years") and not ev["pub"].get("periods"):
            analytics.append({"label": "Динамика по годам", "value": ", ".join("%d: %d" % (k, v) for k, v in sorted(ev["pub"]["years"].items())[-6:])})
    if ev.get("patents"):
        analytics.append({"label": "Патентные документы (Google Patents)", "value": ev["patents"].get("total"), "url": ev["patents"].get("url")})
    if fic:
        analytics.append({"label": "Книги научной фантастики по теме «%s» (Open Library)" % fic.get("query", ""), "value": fic.get("total"), "url": fic.get("url")})
        if fic.get("first_year"):
            analytics.append({"label": "Первое появление идеи в фантастике", "value": fic["first_year"]})
    if ev.get("news_mentions") is not None:
        analytics.append({"label": "Упоминания в мировых СМИ (выборка GDELT/NewsAPI)", "value": ev["news_mentions"]})
    if s.get("library_rank"):
        lr = s["library_rank"]
        analytics.append({"label": "Документов в выборке", "value": lr["docs"]})
        analytics.append({"label": "Независимых библиотек", "value": len(lr["sources"])})
        analytics.append({"label": "Доля работ за последние 2 года", "value": "%.0f%%" % (100 * lr["recent_share"])})
    p = sc["probability"]
    status_expl = _status_explanation(p, sc, s["rec"], mode)
    return {
        "rank": rank, "id": "%s-%d" % (job["id"], rank), "name": name_ru, "name_original": c["phrase"],
        "name_translation_method": how, "query": job["query"], "industry": job["query"],
        "description": desc_ru, "description_original": desc_en, "description_method": desc_method,
        "advantage": ben_ru,
        "advantage_original": ben_en, "case": case,
        "probability": p, "p_model": sc.get("p_model"), "p_methodology": sc.get("p_methodology"),
        "confident": p > CONFIDENT, "is_weak_signal": p >= THRESHOLD,
        "strength": _stage_to_strength(lvl), "stage": s["rec"].get("stage") or "—", "trend": s["rec"].get("trend") or "—",
        "impact": _impact(f, g.get("growth")), "horizon": _horizon(lvl),
        "predictors": sc.get("predictors", []), "methodology_predictors": sc.get("methodology_predictors", []),
        "triz_evidence": sc.get("triz_evidence", {}), "exclusion_reasons": sc.get("exclusion_reasons", []),
        "status_explanation": status_expl, "analytics": analytics, "sources": sources,
        "keywords": c["phrase"].split()[:4], "n_documents": len(docs), "source_ids": c["sources"],
        "companies": s["rec"].get("companies", ""),
        "evidence_coverage": ev.get("coverage", {}), "quality": s.get("quality", {}),
    }


def _status_explanation(p: float, sc: Dict, rec: Dict, mode: str) -> str:
    pos = [x["title"] for x in sc.get("predictors", []) if x["contribution"] > 0][:3]
    neg = [x["title"] for x in sc.get("predictors", []) if x["contribution"] < 0][:2]
    lvl = "высокая (>75%)" if p >= CONFIDENT else ("средняя" if p >= THRESHOLD else "низкая")
    s = "Уверенность %s — %.0f%% (модель: %.0f%%, ТРИЗ-индекс: %.0f%%). " % (lvl, 100 * p, 100 * (sc.get("p_model") or 0), 100 * (sc.get("p_methodology") or 0))
    if pos:
        s += "Повышают: %s. " % ", ".join(pos)
    if neg:
        s += "Понижают: %s. " % ", ".join(neg)
    s += "Стадия: %s. %s" % (rec.get("stage", "—"), rec.get("trend", ""))
    return s


def _result(job, q_en, statuses, docs, items, excluded, scored) -> Dict:
    return {
        "query": job["query"], "query_en": q_en, "mode": job["mode"], "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
        "stats": {
            "sources_requested": len(statuses), "sources_ok": sum(1 for s in statuses if s["status"] == "ok"),
            "documents": len(docs), "candidates": len(scored), "top": len(items),
            "weak_signals": sum(1 for i in items if i["is_weak_signal"]), "confident_75": sum(1 for i in items if i["confident"]),
            "excluded": len(excluded),
        },
        "sources_status": statuses, "items": items, "excluded": excluded,
        "llm_configured": llm.model_name() if llm.available() else None,
        "incomplete": job.get("incomplete", []),
        "report_status": "complete" if len(items) == 15 else "partial",
        "notice": "" if len(items) == 15 else "Доказательств и полных русскоязычных отчётов недостаточно для ТОП-15. Непроверенные позиции не добавляются.",
        "all_candidates": [{"name": s["cand"]["phrase"], "probability": s["score"]["probability"], "docs": s["cand"]["df"], "quality": s.get("quality"), "evidence_coverage": s["ev"].get("coverage", {})} for s in scored],
    }
