"""Conservative, source-grounded gates shared by all search modes.
These rules are screening heuristics, not independent expert verification.
"""
import re
from urllib.parse import urlsplit
from ..ml import features as F
from .candidates import relevant_document

EARLY = re.compile(r'\b(prototype|proof.of.concept|pilot|laboratory|lab.scale|preclinical|experimental demonstrat|first demonstrat)\w*|прототип|пилотн|доказательство концепции|лабораторн|доклиническ', re.I)
MATURE = re.compile(r'\b(mass.market|mass adoption|widely (deployed|adopted|used)|industry standard|commercially available|market leader|established market|millions of (users|customers))\b|массов.{0,20}внедрен|стандарт отрасли|сформированн.{0,12}рынок|лидер.{0,10}рынка', re.I)
CASE = re.compile(r'\b(prototype|experiment|demonstrat|pilot|tested|evaluat|trial|benchmark)\w*|прототип|эксперимент|испытан|пилот|продемонстрир', re.I)


def sentences(text):
    return [s.strip() for s in re.split(r'(?<=[.!?])\s+', text or '') if len(s.strip()) > 30]


def attached_sentences(doc, phrase):
    """Only assertions mentioning the technology (or its document title)."""
    title = doc.get('title', '').lower()
    if phrase.lower() in title:
        return sentences(doc.get('abstract', ''))
    return [s for s in sentences(doc.get('abstract', '')) if phrase.lower() in s.lower()]


def evidence_gate(phrase, docs, query):
    reasons, early, mature = [], [], []
    verified = []
    for d in docs:
        text = d.get('title', '') + ' ' + d.get('abstract', '')
        if not relevant_document(text, query):
            continue
        if not d.get('url') or not (d.get('date') or d.get('year')):
            continue
        if not d.get('source_type') or not d.get('language') or not d.get('title'):
            continue
        verified.append(d)
        for s in attached_sentences(d, phrase):
            record = {'text': s, 'url': d['url'], 'title': d['title']}
            if EARLY.search(s):
                early.append(record)
            if MATURE.search(s) and not re.search(r'not (yet )?(widely|commercially)|не (внедрен|является)', s, re.I):
                mature.append(record)
    if not verified:
        reasons.append('Нет релевантного первоисточника с названием, ссылкой, датой, типом и языком.')
    trusted = [d for d in verified if (d.get('trust') or F.trust_level(d['url'], d.get('source_type'))) != 'пониженный']
    if not trusted:
        reasons.append('Нет подтверждения из источника достаточной доверенности.')
    if not early:
        reasons.append('В текстах нет явного подтверждения прототипа, пилота или лабораторного исследования этой технологии.')
    if mature:
        reasons.append('Найдены признаки рыночной зрелости или массового внедрения: требуется экспертная проверка.')
    return {'eligible': not reasons, 'reasons': reasons, 'early_evidence': early[:4],
            'market_evidence': mature[:4], 'verified_sources': len(verified),
            'independent_domains': sorted({urlsplit(d['url']).hostname for d in verified if urlsplit(d['url']).hostname})}


def case_example(docs, phrase):
    for d in docs:
        for s in attached_sentences(d, phrase):
            if CASE.search(s):
                return {'kind': 'Пример из исследования (не подтверждение внедрения)', 'title': d['title'],
                        'description_original': s, 'url': d.get('url'), 'date': d.get('date') or str(d.get('year') or ''),
                        'org': d.get('authors') or d.get('venue')}
    return None


def russian_text(text, min_chars=10):
    letters = re.findall(r'[a-zа-яё]', text or '', re.I)
    ru = re.findall(r'[а-яё]', text or '', re.I)
    return len(ru) >= min_chars and len(ru) / max(1, len(letters)) >= .55


def report_issues(item):
    issues = []
    for field, label, size in [('name', 'название', 3), ('description', 'описание', 35), ('advantage', 'преимущество', 20)]:
        if not russian_text(item.get(field), size):
            issues.append('Не подготовлено содержательное русскоязычное поле: ' + label)
    if not russian_text((item.get('case') or {}).get('description_ru'), 25):
        issues.append('Нет русскоязычного описания конкретного кейса из источника.')
    if not item.get('sources') or any(not russian_text(s.get('summary_ru'), 20) for s in item['sources']):
        issues.append('Не для всех источников подготовлено русскоязычное резюме.')
    return issues
