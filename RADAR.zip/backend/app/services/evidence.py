# -*- coding: utf-8 -*-
"""
Сбор доказательств по кандидату (четыре слоя методологии) и «текстуализация»
доказательств в формат, понятный модели (стадия, тренд, обоснование).

Слои:
  1. Научные публикации — динамика по годам (OpenAlex group_by, запасной вариант HAL),
     объём корпуса (признак зрелости), доля препринтов.
  2. Патенты — наличие и свежесть патентной активности (Google Patents, EPO/Lens при ключе).
  3. Рынок и СМИ — упоминания в мировых СМИ (GDELT / NewsAPI) — индикатор хайпа.
  4. Научная фантастика — «идея опережала технику» (Open Library / ISFDB): год первого появления.
"""
import asyncio
import datetime as dt
import math
import re
import time
from typing import Dict, List, Optional

import httpx

from ..connectors.sources import _get

THIS_YEAR = dt.date.today().year


_OA_SEM = {}


async def openalex_years(client, phrase: str, key: Optional[str] = None) -> Optional[Dict]:
    loop = asyncio.get_event_loop()
    sem = _OA_SEM.get(id(loop))
    if sem is None:
        sem = _OA_SEM[id(loop)] = asyncio.Semaphore(2)  # бережём анонимный лимит OpenAlex
    async with sem:
        res = await _openalex_years(client, phrase, key)
        await asyncio.sleep(0.25)
        return res


async def _openalex_years(client, phrase: str, key: Optional[str] = None) -> Optional[Dict]:
    params = {"filter": 'title_and_abstract.search:"%s",publication_year:%d-%d' % (phrase, THIS_YEAR - 11, THIS_YEAR),
              "group_by": "publication_year", "mailto": "radar@example.org"}
    if key:
        params["api_key"] = key
    try:
        r = await _get(client, "https://api.openalex.org/works", params=params, retries=1)
        js = r.json()
        years = {int(g["key"]): int(g["count"]) for g in js.get("group_by", []) if str(g.get("key", "")).isdigit()}
        return {"source": "OpenAlex", "total": int(js.get("meta", {}).get("count", sum(years.values()))), "years": years,
                "url": "https://openalex.org/works?filter=title_and_abstract.search:%s" % phrase.replace(" ", "%20")}
    except Exception:
        return None


async def hal_years(client, phrase: str) -> Optional[Dict]:
    try:
        r = await _get(client, "https://api.archives-ouvertes.fr/search/",
                       params={"q": '"%s"' % phrase, "rows": 0, "wt": "json", "facet": "true",
                               "facet.field": "producedDateY_i", "facet.limit": 60}, retries=1)
        js = r.json()
        ff = js.get("facet_counts", {}).get("facet_fields", {}).get("producedDateY_i", [])
        years = {int(ff[i]): int(ff[i + 1]) for i in range(0, len(ff) - 1, 2) if str(ff[i]).isdigit()}
        return {"source": "HAL", "total": int(js.get("response", {}).get("numFound", 0)), "years": years,
                "url": "https://hal.science/search/index/?q=%22" + phrase.replace(" ", "+") + "%22"}
    except Exception:
        return None


async def europepmc_years(client, phrase: str) -> Optional[Dict]:
    """Запасной вариант: 3 запроса по периодам (Europe PMC, в т.ч. препринты)."""
    try:
        years = {}
        total = 0
        for y0, y1, label in ((THIS_YEAR - 6, THIS_YEAR - 4, THIS_YEAR - 5), (THIS_YEAR - 3, THIS_YEAR - 2, THIS_YEAR - 2), (THIS_YEAR - 1, THIS_YEAR, THIS_YEAR)):
            r = await _get(client, "https://www.ebi.ac.uk/europepmc/webservices/rest/search",
                           params={"query": '"%s" AND PUB_YEAR:[%d TO %d]' % (phrase, y0, y1), "format": "json", "pageSize": 1}, retries=1)
            c = int(r.json().get("hitCount", 0))
            years[label] = c
            total += c
        return {"source": "Europe PMC", "total": total, "years": years, "periods": True,
                "url": "https://europepmc.org/search?query=%22" + phrase.replace(" ", "%20") + "%22"}
    except Exception:
        return None


_BREAKER = {"patents": [0, 0.0], "fiction": [0, 0.0]}


def _open(name: str) -> bool:
    n, t = _BREAKER[name]
    return n >= 3 and (time.time() - t) < 300


def _fail(name: str):
    _BREAKER[name][0] += 1
    _BREAKER[name][1] = time.time()


def _ok(name: str):
    _BREAKER[name] = [0, 0.0]


async def patents_count(client, phrase: str) -> Optional[Dict]:
    if _open("patents"):
        return None
    try:
        res = await _patents_count(client, phrase)
        _ok("patents")
        return res
    except Exception:
        _fail("patents")
        return None


async def _patents_count(client, phrase: str) -> Optional[Dict]:
    if True:
        r = await _get(client, "https://patents.google.com/xhr/query",
                       params={"url": 'q=("%s")&num=10&sort=new' % phrase, "exp": ""}, retries=0)
        js = r.json().get("results", {})
        items = []
        for cl in js.get("cluster", []):
            for it in cl.get("result", []):
                p = it.get("patent", {})
                items.append({"title": re.sub("<[^>]+>", "", p.get("title", "")).strip(), "date": p.get("filing_date") or p.get("publication_date", ""),
                              "assignee": p.get("assignee", ""), "url": "https://patents.google.com/" + it.get("id", "").replace("/en", ""),
                              "snippet": re.sub("<[^>]+>", "", p.get("snippet", ""))})
        return {"total": int(js.get("total_num_results", 0)), "recent": items[:5],
                "url": "https://patents.google.com/?q=(%22" + phrase.replace(" ", "+") + "%22)"}


async def fiction_count(client, phrase: str) -> Optional[Dict]:
    # для фантастики ищем по ключевому слову термина (фантастика редко использует точный техн. термин)
    words = [w for w in phrase.split() if len(w) > 3]
    q = " ".join(words[-2:]) if len(words) >= 2 else phrase
    try:
        r = await _get(client, "https://openlibrary.org/search.json",
                       params={"q": q, "subject": "science fiction", "limit": 5, "fields": "title,first_publish_year,author_name,key"}, retries=0)
        js = r.json()
        docs = js.get("docs", [])
        years = [d.get("first_publish_year") for d in docs if d.get("first_publish_year")]
        return {"total": int(js.get("numFound", 0)), "first_year": min(years) if years else None, "query": q,
                "examples": [{"title": d.get("title"), "year": d.get("first_publish_year"), "author": ", ".join((d.get("author_name") or [])[:2]),
                              "url": "https://openlibrary.org" + d.get("key", "")} for d in docs[:3]],
                "url": "https://openlibrary.org/search?q=%s&subject=science+fiction" % q.replace(" ", "+")}
    except Exception:
        return None


# Коэффициенты приведения объёма к масштабу OpenAlex (оценены по контрольным терминам:
# HAL покрывает ~2% мирового графа, Europe PMC — ~15% для междисциплинарных тем).
SCALE = {"OpenAlex": 1.0, "HAL": 50.0, "Europe PMC": 7.0}


def growth_metrics(pub: Optional[Dict]) -> Dict:
    if not pub or not pub.get("years"):
        return {"growth": None, "recent": None, "prior": None, "first_year": None, "total": (pub or {}).get("total"), "total_est": (pub or {}).get("total")}
    y = pub["years"]
    if pub.get("periods"):
        recent = y.get(THIS_YEAR, 0) + y.get(THIS_YEAR - 2, 0) * 0.0
        prior = y.get(THIS_YEAR - 5, 0)
        mid = y.get(THIS_YEAR - 2, 0)
        growth = (recent + 1.0) / (max(mid, prior) * 0.67 + 1.0)
        return {"growth": round(growth, 2), "recent": y.get(THIS_YEAR, 0), "prior": prior, "first_year": None, "total": pub.get("total", 0),
                "total_est": int(pub.get("total", 0) * SCALE.get(pub.get("source"), 1.0))}
    # текущий год неполный — экстраполируем на 12 месяцев
    factor = 12.0 / max(1, dt.date.today().month)
    recent = y.get(THIS_YEAR - 1, 0) + y.get(THIS_YEAR, 0) * factor       # последние 2 года
    prior = sum(v for k, v in y.items() if THIS_YEAR - 3 <= k <= THIS_YEAR - 2)  # 2 года до этого
    growth = (recent + 1.0) / (prior + 1.0)
    recent = int(round(recent))
    first = None
    for k in sorted(y):
        if y[k] >= 3:
            first = k
            break
    total = pub.get("total", sum(y.values()))
    return {"growth": round(growth, 2), "recent": recent, "prior": prior, "first_year": first, "total": total,
            "total_est": int(total * SCALE.get(pub.get("source"), 1.0))}


def textualize(cand: Dict, ev: Dict, docs: List[Dict]) -> Dict:
    """Превращает количественные доказательства в стадию/тренд/обоснование на языке методологии."""
    g = ev["growth"]
    total = g.get("total_est") if g.get("total_est") is not None else g.get("total")
    known_total = total is not None
    total = total if known_total else 0
    pat = ev.get("patents") or {}
    fic = ev.get("fiction") or {}
    news_n = ev.get("news_mentions")
    types = set(d.get("source_type") for d in docs)
    n_trials = sum(1 for d in docs if d.get("source_type") == "clinical_trial")
    late_trial = any(re.search(r"PHASE3|PHASE4", d.get("abstract", "")) for d in docs if d.get("source_type") == "clinical_trial")
    preprint_share = sum(1 for d in docs if d.get("source_type") == "preprint") / float(max(1, len(docs)))

    # ---- стадия (по оценке объёма мирового корпуса, патентам и испытаниям) ----
    npat = pat.get("total", 0) or 0
    emerged = g.get("emerged_year")
    age = (THIS_YEAR - emerged) if emerged else None
    growth_v = g.get("growth") or 0
    from .quality import attached_sentences, EARLY, MATURE
    assertions = [s for d in docs for s in attached_sentences(d, cand["phrase"])]
    if any(MATURE.search(s) and not re.search(r"not (yet )?(widely|commercially)|не (внедрен|является)", s, re.I) for s in assertions):
        stage = "Массовое внедрение / рыночная зрелость: признаки в источниках"
    elif any(EARLY.search(s) for s in assertions):
        stage = "Прототип/PoC (по текстам источников)"
    else:
        stage = "Не определена: нет прямых доказательств стадии"

    # ---- тренд ----
    gr = g.get("growth")
    yrs = ev.get("pub", {}) or {}
    ytxt = ""
    if yrs.get("years") and not yrs.get("periods"):
        ks = [k for k in sorted(yrs["years"]) if k >= THIS_YEAR - 4]
        ytxt = ", ".join("%d — %d" % (k, yrs["years"][k]) for k in ks)
    src = (yrs or {}).get("source", "")
    if gr is None:
        trend = "Динамика не определена (источник статистики недоступен); %d документов в выборке %d–%d гг." % (
            len(docs), min([d["year"] for d in docs if d.get("year")] or [THIS_YEAR]), THIS_YEAR)
    elif gr >= 2.0:
        trend = "Растёт быстро: %s публикаций (%s), рост ×%.1f за 2 года" % (ytxt or "кратный рост", src, gr)
    elif gr >= 1.25:
        trend = "Растёт: %s публикаций (%s), ×%.1f" % (ytxt or "устойчивый рост", src, gr)
    elif gr >= 0.8:
        trend = "Стабильный уровень / насыщение: %s (%s)" % (ytxt or "без роста", src)
    else:
        trend = "Спад интереса: %s (%s)" % (ytxt or "падение", src)

    # ---- обоснование (why) из текста источников + автоматические утверждения ----
    parts = []
    sents = []
    for d in docs[:12]:
        for s in re.split(r"(?<=[.!?])\s+", d.get("abstract") or ""):
            sl = s.lower()
            if re.search(r"however|trade-?off|limitation|bottleneck|challenge|instead of|novel|first|new class|platform|"
                         r"integrat|reduc|lower cost|efficien|adaptive|autonomous|quantum|photonic|neuromorphic|in-memory|"
                         r"without|limit|wall|scalab|energy", sl) and 40 < len(s) < 400:
                sents.append(s.strip())
        if len(sents) >= 3:
            break
    # Обоснование по длине сопоставимо с датасетом (≈2–4 предложения), чтобы плотность
    # лексических признаков совпадала с той, на которой обучалась модель.
    parts.extend(s[:260] for s in sents[:2])
    if news_n is not None and news_n <= 2:
        parts.append("В доступной выборке СМИ найдено %d упоминаний. Покрытие ограничено поисковым запросом." % news_n)
    elif news_n is not None and news_n >= 25:
        parts.append("Широко обсуждается в СМИ (%d упоминаний) — возможен хайп или массовое внедрение." % news_n)
    if preprint_share >= 0.3:
        parts.append("Значительная доля препринтов (%.0f%%) — результаты ещё не прошли рецензирование. Это не подтверждает раннюю стадию технологии." % (100 * preprint_share))
    if age is not None and age >= 12:
        parts.append("Устоявшееся направление: первые работы появились в %d году, возраст направления сам по себе не доказывает массовое применение." % emerged)
    elif age is not None and age <= 4:
        parts.append("Молодое направление: устойчивые упоминания появились только в %d году — требуется проверка истории термина и синонимов." % emerged)
    if total and total < 1500:
        parts.append("Объём доступного научного корпуса: оценка %d работ; малый объём не доказывает новизну." % total)
    if total > 10000:
        parts.append("Научный корпус: более %d публикаций, большой научный корпус; рыночную зрелость проверяем отдельно." % total)
    if pat.get("total"):
        parts.append("Патентная активность: %d документов, свежие заявки %s." % (pat["total"], ", ".join(sorted(set(str(p["date"])[:4] for p in pat.get("recent", []) if p.get("date")))[-3:])))
    if fic.get("first_year") and fic["first_year"] < THIS_YEAR - 10:
        parts.append("Идея присутствует в научной фантастике с %d г. — функция давно востребована обществом, техника её догоняет." % fic["first_year"])
    orgs = sorted(set(p.get("assignee") for p in pat.get("recent", []) if p.get("assignee")))[:5]
    return {"stage": stage, "trend": trend, "why": " ".join(parts), "companies": ", ".join(orgs)}


async def gather_evidence(client: httpx.AsyncClient, phrase: str, keys: Dict[str, str], use_patents=True, use_fiction=True) -> Dict:
    tasks = [openalex_years(client, phrase, keys.get("openalex")), hal_years(client, phrase)]
    tasks.append(patents_count(client, phrase) if use_patents else asyncio.sleep(0, result=None))
    tasks.append(fiction_count(client, phrase) if use_fiction else asyncio.sleep(0, result=None))
    pub, hal, pat, fic = await asyncio.gather(*tasks)
    if pub is None:
        pub = hal
        if pub is None or pub.get("total", 0) == 0:
            alt = await europepmc_years(client, phrase)
            pub = alt or pub
    g = growth_metrics(pub)
    # «Возраст» направления: год, с которого термин устойчиво встречается в научных архивах
    # (по полной годовой истории OpenAlex или HAL). Слабые сигналы — молодые S-кривые.
    first = None
    for src in (pub, hal):
        ys = (src or {}).get("years") or {}
        if ys and not (src or {}).get("periods"):
            thr = 3 if (src or {}).get("source") == "OpenAlex" else 2
            cand = [k for k in sorted(ys) if ys[k] >= thr and 1950 < k <= THIS_YEAR]
            if cand:
                first = cand[0] if first is None else min(first, cand[0])
    g["emerged_year"] = first
    return {"pub": pub, "hal": hal, "patents": pat, "fiction": fic, "growth": g,
            "coverage": {"publications": "ok" if pub is not None else "unavailable",
                         "patents": ("ok" if pat is not None else "unavailable") if use_patents else "not_requested",
                         "fiction": ("ok" if fic is not None else "unavailable") if use_fiction else "not_requested"}}
