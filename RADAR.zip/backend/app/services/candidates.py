# -*- coding: utf-8 -*-
"""
Выделение технологий-кандидатов из собранного корпуса документов.

Не зависит от стартового датасета и заранее заданного списка технологий:
кандидаты — это устойчивые многословные термины (2–4 слова), которые
повторяются в нескольких независимых документах и источниках.
"""
import math
import re
from collections import defaultdict
from typing import Dict, List

STOP = set("""a an the and or of for in on to with by from at as is are was were be been being this that these those
it its into via using use used based towards toward than then their there here we our us they them can could may might
will would should must not no nor but also such other both each more most less least many much very over under between
among about after before during through within without new novel approach approaches method methods methodology paper
study studies result results show shows shown propose proposed proposes present presents presented provide provides
toward first second third one two three four five several various different high low large small recent recently
analysis review survey overview framework frameworks system systems model models application applications case towards
performance efficient efficiency effective improved improving improve enhanced enhancing enhancement evaluation
evaluate evaluating design designing develop developed development implementation research technique techniques
problem problems task tasks data dataset datasets work works paper's article chapter introduction conclusion
state art current future potential challenges challenge opportunities perspective perspectives issues role impact
effect effects key important significant significantly well however while which what when where who whom whose how
why all any some only same own so too just like including include includes et al vs toward upon across due per
year years time times process processes level levels type types part parts way ways number set general specific
real world real-world end end-to-end open source across multi multiple single overall related particular
findings finding indicate indicates indicated evidence empirical literature systematic associated become becomes became
highlight highlights highlighted demonstrate demonstrates demonstrated suggest suggests suggested contribute contributes
aim aims aimed investigate investigates investigated explore explores explored examine examines examined discuss
discusses discussed paper's authors author inc ltd llc corp corporation co gmbh company university institute department
addition additionally furthermore moreover therefore thus hence respectively particularly especially mainly typically
given considering regarding compared comparison respect terms order able ability allows allow allowing enables enable
enabling provides providing achieve achieves achieved achieving obtain obtained significant growing increasing increased
rapid rapidly widely widespread critical crucial essential major main primary basic advanced modern traditional conventional
existing emerging novel innovative promising comprehensive practical theoretical empirical experimental various numerous
above below consistently outperform outperforms outperformed interview interviews semi-structured participant participants
respondent respondents questionnaire sample samples accuracy accuracies precision recall baseline baselines state-of-the-art
record records recruiting recruitment pretest posttest retrospectively retrospective prospectively analyzed analysed
yet still already ranging range ranges de novo cetera versus
""".split())

try:
    from wordfreq import zipf_frequency as _zipf
except Exception:  # пакет необязателен: без него специфичность не учитывается
    _zipf = None


def specificity(phrase: str) -> float:
    """Минимальная частотность слова по Zipf (чем меньше — тем специфичнее термин)."""
    if _zipf is None:
        return 3.5
    ws = [w for w in phrase.split() if w]
    return min(_zipf(w, "en") for w in ws) if ws else 7.0

GENERIC = set("""machine learning|deep learning|artificial intelligence|neural network|neural networks|large language model|
large language models|language model|language models|internet of things|computer vision|natural language processing|
reinforcement learning|big data|cloud computing|data science|convolutional neural network|convolutional neural networks|
generative ai|generative artificial intelligence|ai models|ai model|ai systems|ai system|learning models|learning model|
support vector machine|random forest|decision making|training data|test set|experimental results|simulation results|
proposed approach|proposed method|proposed framework|proposed model|proposed system|case study|literature review|
systematic review|united states|european union|covid pandemic|social media|supply chain|smart city|smart cities|
digital transformation|financial technology|blockchain technology|information technology|artificial neural network|
deep neural network|deep neural networks|learning algorithms|learning algorithm|learning techniques|ai technologies|
emerging technologies|new technologies|technology adoption|business models|business model|digital connectivity|replay attacks|anomaly detection|threat detection|fault detection|adversarial machine learning|ai agents|llm agents|autonomous agents|smart grid|quantum computing|renewable energy|abstract india|validated against|operational benefits|skills gaps""".replace("\n", "").split("|"))

# Головные слова, которые описывают не технологию, а контекст (угрозы, риски, политику, метрики)
NON_TECH_HEADS = set("""threat risk governance literacy education policy management practice awareness oversight
researcher student industry sector organization stakeholder perception adoption challenge regulation law ethic ethics
society country market accuracy rate score dataset benchmark survey review concern implication issue factor barrier
driver trend landscape strategy strategie outcome effectiveness readiness maturity culture behavior behaviour attitude
skill workforce employee user consumer customer business firm enterprise company economy growth investment decision
perspective insight lesson question answer need requirement expert leader government agency
analysis analyse analyses evaluation assessment investigation comparison study trial
recommendation incident scenario posture guideline guidance vulnerability consideration opportunity problem solution
application implementation deployment usage use case example overview introduction
innovation advancement ecosystem inclusion resilience acceptance intention usefulness ease validity check statistic
predictor note literacy provider developer startup transformation transaction exclusion endogeneity findex perception satisfaction trust loyalty willingness determinant antecedent""".split())
BAD_WORDS = set("ieee xplore springer elsevier mdpi wiley copyright rights reserved arxiv preprint doi http https www com org "
                "journal conference proceedings chapter volume issue press ltd inc llc university scopus wos nist csf iso gdpr "
                "database databases repository repositories".split())

NOUN_ING = set("learning computing sensing processing engineering manufacturing printing encoding decoding routing mining "
               "caching tracking imaging scheduling programming modeling modelling planning networking "
               "fingerprinting watermarking unlearning sharding pruning".split())
NOUN_AL = set("signal potential material terminal interval portal capital tutorial rental journal fuel crystal metal".split())


TECH_HEADS = set("""learning network model computing computer encryption cryptography protocol sensor chip detection blockchain
tokenization token ledger agent robot robotic battery quantum twin proof contract payment wallet stablecoin cbdc
architecture processor accelerator memory storage fabric interconnect photonic laser material membrane catalyst
vaccine therapy antibody editing crispr sequencing imaging microscopy lidar radar drone satellite vehicle engine
reactor fusion fission grid inverter cell electrolyzer hydrogen ammonia polymer semiconductor transistor qubit
compiler framework language llm transformer diffusion embedding retrieval generation inference training fine-tuning
simulation digital automation orchestration container kernel firmware hardware software malware ransomware phishing
injection attack watermark fingerprint biometric authentication identity signature custody settlement clearing
lending underwriting scoring credit insurance insurtech regtech api sdk platform exchange oracle bridge rollup""".split())


def _noun_like(w):
    """Грубая проверка, что термин оканчивается существительным (технология, а не свойство)."""
    if w in NOUN_ING or w in NOUN_AL:
        return True
    for suf in ("ly", "ing", "able", "ible", "ed", "ive", "al", "ic", "ous", "ful", "less", "ary"):
        if w.endswith(suf) and len(w) > len(suf) + 2:
            return False
    return True


_WORD = re.compile(r"[a-z][a-z0-9\-]*[a-z0-9]|[a-z]")  # после фильтра франкоязычных записей


def _norm_token(t: str) -> str:
    if len(t) > 4 and t.endswith("ies"):
        return t[:-3] + "y"
    if len(t) > 4 and t.endswith("s") and not t.endswith(("ss", "us", "is")):
        return t[:-1]
    return t


def _chunks(text: str) -> List[List[str]]:
    text = text.lower()
    parts = re.split(r"[.,;:!?()\[\]{}\"“”'`/|<>=+*%$#@&^~]|\s-\s|\s–\s|\s—\s", text)
    out = []
    for p in parts:
        cur = []
        for w in _WORD.findall(p):
            if w in STOP or w.isdigit() or len(w) < 2:
                if len(cur) >= 2:
                    out.append(cur)
                cur = []
            else:
                cur.append(w)
        if len(cur) >= 2:
            out.append(cur)
    return out


def _ngrams(tokens: List[str], nmin=2, nmax=4):
    for n in range(nmin, nmax + 1):
        for i in range(len(tokens) - n + 1):
            yield tokens[i:i + n]


def extract_candidates(docs: List[Dict], query_en: str, top_n: int = 40) -> List[Dict]:
    qwords = set(_norm_token(w) for w in _WORD.findall(query_en.lower()))
    stats = defaultdict(lambda: {"docs": set(), "sources": set(), "types": set(), "title_hits": 0, "surface": defaultdict(int), "years": []})
    for i, d in enumerate(docs):
        if (d.get("language") or "en")[:2] not in ("en", ""):
            continue  # термины извлекаются из англоязычных текстов (русские — отдельно, для сопоставления)
        txt = (d.get("title") or "") + " " + (d.get("abstract") or "")
        if not relevant_document(txt, query_en):
            continue
        if not relevant_document(txt, query_en):
            continue
        if re.search(r"[à-ÿœ]", txt) and re.search(r"\b(le|la|les|des|du|et|pour|une)\b", txt):
            continue  # франкоязычные записи HAL без метки языка
        seen = set()
        for field, w in (("title", 3), ("abstract", 1)):
            for ch in _chunks(d.get(field) or ""):
                for g in _ngrams(ch):
                    key = " ".join(_norm_token(t) for t in g)
                    surface = " ".join(g)
                    if key in GENERIC or surface in GENERIC:
                        continue
                    if all(_norm_token(t) in qwords for t in g):
                        continue  # сам запрос не является кандидатом
                    if len(key) < 6:
                        continue
                    s = stats[key]
                    s["surface"][surface] += 1
                    if field == "title":
                        s["title_hits"] += 1
                    if key not in seen:
                        seen.add(key)
                        s["docs"].add(i)
                        s["sources"].add(d.get("source_id"))
                        s["types"].add(d.get("source_type"))
                        if d.get("year"):
                            s["years"].append(d["year"])
    n_docs = max(1, len(docs))
    scored = []
    for key, s in stats.items():
        df = len(s["docs"])
        if df < 2 and not s["title_hits"]:
            continue
        if df > 0.5 * n_docs and n_docs > 20:
            continue  # слишком общий для данного корпуса термин
        n_words = len(key.split())
        surface0 = max(s["surface"].items(), key=lambda x: x[1])[0]
        spec = specificity(surface0)
        ws = surface0.split()
        # A specific title term may start with a single primary paper.
        # Source quality and stage are checked downstream, never inferred from frequency.
        if any(_norm_token(w) in NON_TECH_HEADS for w in ws[:-1]):
            continue
        if not any(_norm_token(w) in TECH_HEADS for w in ws):
            continue
        if any(_norm_token(w) in NON_TECH_HEADS for w in ws[:-1]):
            continue
        if not any(_norm_token(w) in TECH_HEADS for w in ws):
            continue
        if not _noun_like(ws[-1]):
            continue
        if _norm_token(ws[-1]) in NON_TECH_HEADS or any(w in BAD_WORDS for w in ws):
            continue
        if spec >= 4.25:
            continue  # все слова общеупотребительные — не технологический термин
        # доля слов запроса: кандидат «запрос + общее слово» малоинформативен
        non_q = [w for w in surface0.split() if _norm_token(w) not in qwords]
        if non_q and specificity(" ".join(non_q)) >= 4.4:
            continue
        score = (math.log1p(df) * (1 + 0.5 * math.log1p(len(s["sources"]))) * (1 + 0.15 * min(s["title_hits"], 6))
                 * (1.0 + 0.2 * (n_words - 2)))
        recent = sum(1 for y in s["years"] if y and y >= 2024)
        score *= 1 + 0.3 * (recent / max(1, len(s["years"])))
        score *= 1 + 0.6 * max(0.0, 4.25 - spec)
        if any(_norm_token(w) in TECH_HEADS for w in ws):
            score *= 1.6  # в термине есть технологическое ядро
        if len(non_q) < len(ws):
            score *= 0.6  # слабые сигналы — это чаще подтехнологии, а не «запрос + уточнение»
        surface = max(s["surface"].items(), key=lambda x: x[1])[0]
        scored.append({"key": key, "phrase": surface, "specificity": round(spec, 2), "df": df, "sources": sorted(x for x in s["sources"] if x),
                       "types": sorted(x for x in s["types"] if x), "title_hits": s["title_hits"],
                       "doc_ids": sorted(s["docs"]), "score": round(score, 4)})
    scored.sort(key=lambda x: -x["score"])
    # Подавление вложенных/пересекающихся терминов
    chosen = []
    for c in scored:
        k = c["key"]
        dup = False
        for o in chosen:
            ok = o["key"]
            if k in ok or ok in k:
                overlap = len(set(c["doc_ids"]) & set(o["doc_ids"])) / float(min(len(c["doc_ids"]), len(o["doc_ids"])))
                if overlap >= 0.6:
                    dup = True
                    if len(k) > len(ok) and c["df"] >= 0.7 * o["df"]:
                        o.update(c)  # берём более специфичный термин
                    break
            else:
                wa, wb = set(k.split()), set(ok.split())
                if len(wa & wb) >= min(len(wa), len(wb)) and len(wa & wb) >= 2:
                    dup = True
                    break
        if not dup:
            chosen.append(dict(c))
        if len(chosen) >= top_n:
            break
    return chosen


DOMAIN_TERMS = {
    "cybersecurity": {"security", "cyber", "malware", "cryptograph", "authentication", "privacy", "intrusion", "phishing", "encryption"},
    "fintech": {"financial", "bank", "payment", "lending", "settlement", "credit", "fraud", "tokenization"},
    "artificial intelligence": {"neural", "learning", "inference", "language model", "intelligence", "transformer"},
}

def relevant_document(text, query):
    """Explicit topic anchors; no relevance inferred merely from search-engine rank."""
    q = query.lower()
    terms = {w for w in _WORD.findall(q) if w not in STOP and w not in {"technology", "technologies", "signal", "signals", "weak"}}
    for domain, synonyms in DOMAIN_TERMS.items():
        if domain in q:
            terms.update(synonyms)
    return bool(terms) and any(re.search(r"(?<![a-z])" + re.escape(w) + r"[a-z-]*", text.lower()) for w in terms)


DOMAIN_TERMS = {
    "cybersecurity": {"security", "cyber", "malware", "cryptograph", "authentication", "privacy", "intrusion", "phishing", "encryption"},
    "fintech": {"financial", "bank", "payment", "lending", "settlement", "credit", "fraud", "tokenization"},
    "artificial intelligence": {"neural", "learning", "inference", "language model", "intelligence", "transformer"},
}

def relevant_document(text, query):
    """Explicit topic anchors; no relevance inferred merely from search-engine rank."""
    q = query.lower()
    terms = {w for w in _WORD.findall(q) if w not in STOP and w not in {"technology", "technologies", "signal", "signals", "weak"}}
    for domain, synonyms in DOMAIN_TERMS.items():
        if domain in q:
            terms.update(synonyms)
    return bool(terms) and any(re.search(r"(?<![a-z])" + re.escape(w) + r"[a-z-]*", text.lower()) for w in terms)
