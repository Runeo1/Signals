# -*- coding: utf-8 -*-
"""
Необязательная облачная LLM (только модели из списка ТЗ).

Используется ТОЛЬКО для перевода и русскоязычных резюме уже найденных
источников. Решение «слабый сигнал / нет» LLM не принимает — его принимает
модель на признаках методологии (требование ТЗ: итоговая выдача не может
опираться только на знания языковой модели). Каждое обращение логируется
с указанием модели (таблица llm_log и журнал сервера).

Настройка (переменные окружения или «Настройки API-ключей» в интерфейсе):
  LLM_PROVIDER = openai | yandexgpt | gigachat
  LLM_MODEL    = gpt-4.1 | yandexgpt-lite | yandexgpt | GigaChat-2 | GigaChat-2-Pro | GigaChat-2-Max ...
  LLM_API_KEY  = ключ;  для YandexGPT дополнительно LLM_FOLDER_ID
  LLM_BASE_URL = (необязательно) OpenAI-совместимый endpoint, напр. для Qwen3
"""
import logging
import os
import re
import time
import uuid
from typing import Optional

import httpx

log = logging.getLogger("llm")

PROVIDER_MODELS = {
    "openai": {"gpt-4.1", "gpt-5.6-luna"},
    "yandexgpt": {"yandexgpt-5-lite", "yandexgpt-5-pro", "yandexgpt-5.1"},
    "gigachat": {"GigaChat-2", "GigaChat-2-Pro", "GigaChat-2-Max"},
}
ENDPOINTS = {"openai": "https://api.openai.com/v1",
             "yandexgpt": "https://llm.api.cloud.yandex.net/foundationModels/v1",
             "gigachat": "https://api.giga.chat/v1"}
ALLOWED_MODELS = sorted(m for values in PROVIDER_MODELS.values() for m in values)


def validate_config(cfg):
    provider, model = cfg.get("provider", ""), cfg.get("model", "")
    if not provider and not model:
        return
    if model not in PROVIDER_MODELS.get(provider, set()):
        raise ValueError("Модель или провайдер не разрешены. Выберите явную версию из списка ТЗ.")
    if cfg.get("base_url", "").rstrip("/") not in {"", ENDPOINTS[provider]}:
        raise ValueError("Произвольные API и посредники запрещены. Допустим только официальный endpoint провайдера.")
    if provider == "yandexgpt" and not re.fullmatch(r"[a-zA-Z0-9_-]+", cfg.get("folder_id", "")):
        raise ValueError("Укажите корректный Folder ID Yandex Cloud.")

_RUNTIME = {}  # значения, заданные через интерфейс (перекрывают окружение)
_CALLS = []    # последние обращения (для журнала)


def configure(provider: str = "", model: str = "", api_key: str = "", folder_id: str = "", base_url: str = ""):
    validate_config(dict(provider=provider, model=model, base_url=base_url, folder_id=folder_id))
    _RUNTIME.update({k: v for k, v in dict(provider=provider, model=model, api_key=api_key, folder_id=folder_id, base_url=base_url).items() if v is not None})


def _cfg(k: str) -> str:
    return _RUNTIME[k] if k in _RUNTIME else os.getenv("LLM_" + k.upper(), "")


def available() -> bool:
    return bool(_cfg("api_key") and _cfg("provider") and _cfg("model"))


def model_name() -> str:
    return "%s:%s" % (_cfg("provider"), _cfg("model"))


def calls():
    return list(_CALLS[-50:])


def _record(purpose: str, ok: bool, ms: int):
    _CALLS.append({"ts": time.strftime("%Y-%m-%d %H:%M:%S"), "model": model_name(), "purpose": purpose, "ok": ok, "ms": ms})
    from .. import db
    db.audit("llm_call", dict(_CALLS[-1], provider=_cfg("provider"), endpoint=ENDPOINTS.get(_cfg("provider"))), strict=True)
    del _CALLS[:-50]
    log.info("LLM call model=%s purpose=%s ok=%s ms=%d", model_name(), purpose, ok, ms)


def chat(system: str, user: str, purpose: str = "summary", max_tokens: int = 400) -> Optional[str]:
    if not available():
        return None
    try:
        validate_config({k: _cfg(k) for k in ("provider", "model", "base_url", "folder_id")})
    except ValueError:
        _record(purpose + ":blocked", False, 0)
        return None
    # A durable start record is required before contacting an external model.
    from .. import db
    try:
        db.audit("llm_call_started", {"model": model_name(), "purpose": purpose,
            "endpoint": ENDPOINTS[_cfg("provider")]}, strict=True)
    except Exception:
        log.error("LLM request blocked: audit storage unavailable")
        return None
    prov, model, key = _cfg("provider").lower(), _cfg("model"), _cfg("api_key")
    t0 = time.time()
    try:
        if prov == "yandexgpt":
            body = {"modelUri": "gpt://%s/%s" % (_cfg("folder_id"), model),
                    "completionOptions": {"temperature": 0.2, "maxTokens": str(max_tokens)},
                    "messages": [{"role": "system", "text": system}, {"role": "user", "text": user}]}
            r = httpx.post("https://llm.api.cloud.yandex.net/foundationModels/v1/completion", json=body,
                           headers={"Authorization": "Api-Key " + key}, timeout=15)
            r.raise_for_status()
            out = r.json()["result"]["alternatives"][0]["message"]["text"]
        elif prov == "gigachat":
            tok = httpx.post("https://ngw.devices.sberbank.ru:9443/api/v2/oauth", data={"scope": "GIGACHAT_API_PERS"},
                             headers={"Authorization": "Basic " + key, "RqUID": str(uuid.uuid4())}, timeout=10, verify=True)
            tok.raise_for_status()
            at = tok.json()["access_token"]
            r = httpx.post("https://api.giga.chat/v1/chat/completions",
                           json={"model": model, "temperature": 0.2, "max_tokens": max_tokens,
                                 "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]},
                           headers={"Authorization": "Bearer " + at}, timeout=15, verify=True)
            r.raise_for_status()
            out = r.json()["choices"][0]["message"]["content"]
        else:  # openai-совместимый (gpt-4.1, Qwen3 через совместимый endpoint)
            base = _cfg("base_url") or "https://api.openai.com/v1"
            r = httpx.post(base.rstrip("/") + "/chat/completions",
                           json={"model": model, "temperature": 0.2, "max_tokens": max_tokens,
                                 "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]},
                           headers={"Authorization": "Bearer " + key}, timeout=15)
            r.raise_for_status()
            out = r.json()["choices"][0]["message"]["content"]
        _record(purpose, True, int((time.time() - t0) * 1000))
        return (out or "").strip()
    except Exception as e:
        log.warning("LLM error: %s", type(e).__name__)
        _record(purpose, False, int((time.time() - t0) * 1000))
        return None


def translate(text: str, tl: str = "ru") -> Optional[str]:
    lang = "русский" if tl == "ru" else "английский"
    return chat("Ты профессиональный научно-технический переводчик. Переводи точно, без пояснений.",
                "Переведи на %s язык:\n%s" % (lang, text), purpose="translate", max_tokens=300)


def summarize_ru(title: str, abstract: str) -> Optional[str]:
    return chat("Ты аналитик технологических трендов. Пиши по-русски, 2–3 предложения, только по тексту источника, без домыслов.",
                "Кратко перескажи суть источника: какую проблему/противоречие решает, какой принцип предлагает, какое преимущество.\n"
                "Название: %s\nАннотация: %s" % (title, abstract[:2500]), purpose="summary", max_tokens=250)
