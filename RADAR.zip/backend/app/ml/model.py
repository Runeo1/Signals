# -*- coding: utf-8 -*-
"""
Интерпретируемый классификатор слабых сигналов.

* Основная модель — логистическая регрессия на признаках методологии
  (стандартизированных). Вклад каждого признака = коэффициент × z-значение.
* Для сравнения в отчёте: Random Forest на тех же признаках, базовая линия
  TF-IDF + LR по «сырому» тексту и базовая линия «только стадия».
"""
import json
import math
import os
import sklearn
from typing import Dict, List, Optional

import joblib
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from . import features as F

MODEL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "models")
MODEL_PATH = os.path.join(MODEL_DIR, "weak_signal_model.joblib")
META_PATH = os.path.join(MODEL_DIR, "model_meta.json")
THRESHOLD = 0.5
CONFIDENT = 0.75


def build_model(C: float = 0.5) -> Pipeline:
    return Pipeline([
        ("scale", StandardScaler()),
        ("clf", LogisticRegression(C=C, max_iter=2000, class_weight="balanced", random_state=42)),
    ])


class WeakSignalModel:
    def __init__(self, pipeline: Optional[Pipeline] = None, meta: Optional[Dict] = None):
        self.pipeline = pipeline
        self.meta = meta or {}

    # ------------------------------------------------------------------
    @classmethod
    def load(cls, path: str = MODEL_PATH) -> "WeakSignalModel":
        if os.path.exists(META_PATH):
            with open(META_PATH, encoding="utf-8") as stream:
                version = json.load(stream).get("sklearn_version")
            if version and version != sklearn.__version__:
                raise RuntimeError("Model/runtime scikit-learn versions differ; run python -m app.ml.train")
        pipe = joblib.load(path)
        meta = {}
        if os.path.exists(META_PATH):
            with open(META_PATH, "r", encoding="utf-8") as f:
                meta = json.load(f)
        return cls(pipe, meta)

    def save(self, path: str = MODEL_PATH):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.meta["sklearn_version"] = sklearn.__version__
        joblib.dump(self.pipeline, path)
        with open(META_PATH, "w", encoding="utf-8") as f:
            json.dump(self.meta, f, ensure_ascii=False, indent=2)

    def fit(self, records: List[Dict], C: float = 0.5):
        X, _ = F.vectorize(records)
        y = [int(r["label"]) for r in records]
        self.pipeline = build_model(C)
        self.pipeline.fit(np.array(X), np.array(y))
        return self

    # ------------------------------------------------------------------
    def predict_proba_feats(self, feats: List[Dict[str, float]]) -> np.ndarray:
        X = np.array([[f[k] for k in F.FEATURE_NAMES] for f in feats])
        return self.pipeline.predict_proba(X)[:, 1]

    def explain_feats(self, f: Dict[str, float], top: int = 7) -> List[Dict]:
        scaler = self.pipeline.named_steps["scale"]
        clf = self.pipeline.named_steps["clf"]
        x = np.array([f[k] for k in F.FEATURE_NAMES])
        z = (x - scaler.mean_) / np.where(scaler.scale_ == 0, 1, scaler.scale_)
        contrib = clf.coef_[0] * z
        order = np.argsort(-np.abs(contrib))
        out = []
        for i in order[:top]:
            k = F.FEATURE_NAMES[i]
            out.append({
                "feature": k,
                "title": F.FEATURE_INFO[k][0],
                "meaning": F.FEATURE_INFO[k][1],
                "value": round(float(x[i]), 3),
                "contribution": round(float(contrib[i]), 3),
                "direction": "за слабый сигнал" if contrib[i] > 0 else "против (зрелость/хайп/шум)",
            })
        return out

    def coefficients(self) -> List[Dict]:
        clf = self.pipeline.named_steps["clf"]
        items = [{"feature": k, "title": F.FEATURE_INFO[k][0], "coef": round(float(c), 4)}
                 for k, c in zip(F.FEATURE_NAMES, clf.coef_[0])]
        return sorted(items, key=lambda d: -abs(d["coef"]))

    # ------------------------------------------------------------------
    def score_record(self, record: Dict, mode: str = "hybrid") -> Dict:
        """mode: model | methodology | hybrid"""
        f = F.extract(record)
        p_model = float(self.predict_proba_feats([f])[0])
        p_method = float(F.methodology_index(f))
        if mode == "methodology":
            p = p_method
        elif mode == "model":
            p = p_model
        else:
            p = 0.6 * p_model + 0.4 * p_method
        text = " ".join([record.get("name", ""), record.get("why", ""), record.get("trend", "")])
        return {
            "probability": round(p, 4),
            "p_model": round(p_model, 4),
            "p_methodology": round(p_method, 4),
            "is_weak_signal": p >= THRESHOLD,
            "confident": p >= CONFIDENT,
            "features": {k: round(v, 3) for k, v in f.items()},
            "predictors": self.explain_feats(f),
            "methodology_predictors": F.methodology_explain(f),
            "exclusion_reasons": exclusion_reasons(f, text),
            "triz_evidence": triz_evidence(text),
        }


def exclusion_reasons(f: Dict[str, float], text: str) -> List[str]:
    r = []
    if f.get("stage_level", 0) >= 5:
        r.append("Стадия массового внедрения/стандарта — технология уже зрелая.")
    if f.get("maturity", 0) >= 0.6:
        r.append("Признаки сформированного рынка: " + ", ".join(F.matched_terms("maturity", text.lower(), 4)) + ".")
    if f.get("hype", 0) >= 0.4:
        r.append("Маркетинговые формулировки без механизма: " + ", ".join(F.matched_terms("hype", text.lower(), 4)) + ".")
    if f.get("noise", 0) >= 0.4:
        r.append("Источники с пониженной доверенностью/шум: " + ", ".join(F.matched_terms("noise", text.lower(), 4)) + ".")
    if f.get("trend_peak_drop", 0) >= 1:
        r.append("Профиль «пик и спад» — типичный хайп-цикл.")
    if f.get("trend_flat", 0) >= 1:
        r.append("Плато упоминаний — верхний участок S-кривой.")
    if f.get("low_trust_share", 0) >= 0.5:
        r.append("Большинство источников — соцсети, блоги или пресс-релизы; требуется независимое подтверждение.")
    return r


def triz_evidence(text: str) -> Dict[str, List[str]]:
    out = {}
    for k in ["contradiction", "principle_shift", "supersystem", "ideality", "dynamization", "micro_effects", "scurve_limit", "niche"]:
        m = F.matched_contexts(k, text or "", 3)
        if m:
            out[F.FEATURE_INFO[k][0]] = m
    return out


_MODEL: Optional[WeakSignalModel] = None


def get_model() -> WeakSignalModel:
    """Ленивая загрузка; если модель ещё не обучена — обучает на встроенных данных."""
    global _MODEL
    if _MODEL is None:
        if os.path.exists(MODEL_PATH):
            try:
                _MODEL = WeakSignalModel.load()
                _MODEL.pipeline.predict_proba(np.zeros((1, len(F.FEATURE_NAMES))))
            except Exception:  # файл от другой версии scikit-learn/numpy — переобучаем
                _MODEL = None
        if _MODEL is None:
            from .dataset import load_training_set
            _MODEL = WeakSignalModel().fit(load_training_set())
            _MODEL.meta = {"note": "обучена автоматически при первом запуске"}
            _MODEL.save()
    return _MODEL


def reset_model(m: Optional[WeakSignalModel] = None):
    global _MODEL
    _MODEL = m
