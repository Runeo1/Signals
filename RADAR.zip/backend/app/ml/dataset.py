# -*- coding: utf-8 -*-
"""Загрузка и очистка датасетов (Excel/CSV) в единый формат записей."""
import os
import re
from typing import Dict, List, Optional

import pandas as pd

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "data")
DEFAULT_DATASET = os.path.join(DATA_DIR, "dataset_weak_signals_sep2026.xlsx")
DEFAULT_BACKGROUND = os.path.join(DATA_DIR, "background_control_set.csv")

# Синонимы названий столбцов -> внутреннее имя
COLUMN_MAP = {
    "name": ["технология (слабый сигнал)", "технология", "название", "technology", "name", "title"],
    "area": ["область", "отрасль", "area", "domain", "industry"],
    "companies": ["компании", "игроки", "companies", "players", "organizations"],
    "why": ["почему это слабый сигнал", "обоснование", "описание", "description", "why", "rationale", "text"],
    "stage": ["стадия развития", "стадия", "stage", "trl"],
    "trend": ["тренд упоминаний", "динамика", "trend", "mentions trend"],
    "score": ["балл (стадия+тренд)", "балл", "score"],
    "sources": ["источники", "sources", "links", "ссылки"],
    "label": ["label", "метка", "класс", "слабый сигнал", "ground truth", "is_weak_signal", "target", "разметка"],
    "bg_type": ["тип фона"],
}


def _norm(s: str) -> str:
    if s is None:
        return ""
    return re.sub(r"\s+", " ", str(s)).strip().lower()


def _find_header_row(raw: pd.DataFrame) -> int:
    for i in range(min(15, len(raw))):
        vals = [_norm(v) for v in raw.iloc[i].tolist()]
        if any(v.startswith("технология") or v in ("technology", "name", "название") for v in vals):
            return i
    return 0


def read_table(path: str) -> pd.DataFrame:
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xlsm", ".xls"):
        raw = pd.read_excel(path, header=None)
        h = _find_header_row(raw)
        df = pd.read_excel(path, header=h)
    elif ext == ".json":
        df = pd.read_json(path)
    else:
        df = pd.read_csv(path)
    df = df.loc[:, [c for c in df.columns if not str(c).startswith("Unnamed")]]
    return df


def map_columns(df: pd.DataFrame) -> Dict[str, str]:
    mapping = {}
    cols = {_norm(c): c for c in df.columns}
    for key, variants in COLUMN_MAP.items():
        for v in variants:
            if v in cols:
                mapping[key] = cols[v]
                break
        if key not in mapping:
            for nc, orig in cols.items():
                if any(nc.startswith(v) for v in variants):
                    mapping[key] = orig
                    break
    return mapping


def _to_label(v) -> Optional[int]:
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return None
    s = _norm(v)
    if s in ("1", "1.0", "да", "yes", "true", "слабый сигнал", "weak", "weak signal", "сигнал", "+"):
        return 1
    if s in ("0", "0.0", "нет", "no", "false", "хайп", "шум", "фон", "зрелая", "hype", "noise", "mature", "-"):
        return 0
    try:
        return 1 if float(s) >= 0.5 else 0
    except ValueError:
        return None


def to_records(df: pd.DataFrame, default_label: Optional[int] = None, origin: str = "") -> List[Dict]:
    m = map_columns(df)
    if "name" not in m:
        raise ValueError("Не найден столбец с названием технологии (ожидается «Технология …» / «name»).")
    recs = []
    for idx, row in df.iterrows():
        name = str(row.get(m["name"], "") or "").strip()
        if not name or name.lower() == "nan":
            continue
        get = lambda k: ("" if k not in m or pd.isna(row.get(m[k])) else str(row.get(m[k])))
        lab = _to_label(row.get(m["label"])) if "label" in m else None
        if lab is None:
            lab = default_label
        recs.append({
            "row": int(idx) + 1,
            "name": name,
            "area": get("area"),
            "companies": get("companies"),
            "why": get("why"),
            "stage": get("stage"),
            "trend": get("trend"),
            "sources": get("sources"),
            "score": get("score"),
            "bg_type": get("bg_type"),
            "label": lab,
            "origin": origin,
            "has_explicit_label": "label" in m,
        })
    return recs


def clean_text(s: str) -> str:
    s = re.sub(r"\s+", " ", str(s or ""))
    return s.strip()


def load_training_set(dataset_path: str = DEFAULT_DATASET, background_path: str = DEFAULT_BACKGROUND):
    """
    Положительный класс — строки исходного датасета (методологи разметили их как слабые сигналы).
    Отрицательный класс — контрольный набор «фона» (зрелые технологии, стандарты, хайп, шум).
    Если в датасете есть явный столбец разметки — он имеет приоритет.
    """
    pos = to_records(read_table(dataset_path), default_label=1, origin="dataset")
    neg = to_records(read_table(background_path), default_label=0, origin="background") if background_path and os.path.exists(background_path) else []
    for r in pos + neg:
        for k in ("name", "why", "stage", "trend", "companies"):
            r[k] = clean_text(r[k])
    return pos + neg
