# -*- coding: utf-8 -*-
"""
Обучение и честная валидация модели.

Запуск:  python -m app.ml.train            (из каталога backend/)
Результаты:
  models/weak_signal_model.joblib, models/model_meta.json
  reports/validation_report.json, reports/predictions.csv
  ../docs/dataset-validation-report.md
"""
import csv
import datetime as dt
import json
import os
from typing import Dict, List

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score, precision_score,
                             recall_score, roc_auc_score)
from sklearn.model_selection import (LeaveOneGroupOut, RepeatedStratifiedKFold,
                                     cross_val_predict, StratifiedKFold)
from sklearn.pipeline import make_pipeline

from . import features as F
from .dataset import DEFAULT_BACKGROUND, DEFAULT_DATASET, load_training_set, read_table, to_records
from .model import MODEL_DIR, THRESHOLD, WeakSignalModel, build_model

BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
REPORT_DIR = os.path.join(BACKEND_DIR, "reports")
DOCS_DIR = os.path.join(os.path.dirname(BACKEND_DIR), "docs")


def metrics(y, p, prob=None) -> Dict:
    y, p = np.asarray(y), np.asarray(p)
    out = {
        "accuracy": round(float(accuracy_score(y, p)), 4),
        "precision": round(float(precision_score(y, p, zero_division=0)), 4),
        "recall": round(float(recall_score(y, p, zero_division=0)), 4),
        "f1": round(float(f1_score(y, p, zero_division=0)), 4),
        "confusion_matrix": confusion_matrix(y, p, labels=[0, 1]).tolist(),
    }
    if prob is not None and len(set(y.tolist())) == 2:
        out["roc_auc"] = round(float(roc_auc_score(y, prob)), 4)
    return out


def repeated_cv(make, X, y, n_rep=10, seed=42):
    rskf = RepeatedStratifiedKFold(n_splits=5, n_repeats=n_rep, random_state=seed)
    accs, precs, recs, f1s, aucs = [], [], [], [], []
    for tr, te in rskf.split(X, y):
        m = make()
        m.fit(X[tr], y[tr])
        prob = m.predict_proba(X[te])[:, 1]
        pr = (prob >= THRESHOLD).astype(int)
        accs.append(accuracy_score(y[te], pr)); precs.append(precision_score(y[te], pr, zero_division=0))
        recs.append(recall_score(y[te], pr, zero_division=0)); f1s.append(f1_score(y[te], pr, zero_division=0))
        aucs.append(roc_auc_score(y[te], prob))
    f = lambda a: {"mean": round(float(np.mean(a)), 4), "std": round(float(np.std(a)), 4)}
    return {"folds": len(accs), "accuracy": f(accs), "precision": f(precs), "recall": f(recs), "f1": f(f1s), "roc_auc": f(aucs)}


def run(dataset_path: str = DEFAULT_DATASET, background_path: str = DEFAULT_BACKGROUND, write_docs: bool = True) -> Dict:
    recs = load_training_set(dataset_path, background_path)
    Xl, feats = F.vectorize(recs)
    X = np.array(Xl)
    y = np.array([r["label"] for r in recs])
    groups = np.array([r["area"] for r in recs])
    texts = [" ".join([r["name"], r["why"], r["stage"], r["trend"]]) for r in recs]

    report = {
        "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
        "dataset": os.path.basename(dataset_path),
        "background": os.path.basename(background_path),
        "n_total": int(len(y)), "n_weak_signals": int(y.sum()), "n_background": int((y == 0).sum()),
        "threshold": THRESHOLD,
        "features": [{"name": k, "title": F.FEATURE_INFO[k][0], "meaning": F.FEATURE_INFO[k][1]} for k in F.FEATURE_NAMES],
    }

    # 1) Основная модель: 5-fold × 10 повторов
    report["main_model_repeated_cv"] = repeated_cv(lambda: build_model(), X, y)

    # 2) Out-of-fold предсказания (5-fold) для матрицы ошибок и построчного отчёта
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    oof = cross_val_predict(build_model(), X, y, cv=skf, method="predict_proba")[:, 1]
    report["main_model_oof"] = metrics(y, (oof >= THRESHOLD).astype(int), oof)

    # 3) Перенос между областями: обучаемся на 5 областях, проверяем на шестой
    logo = LeaveOneGroupOut()
    per_area = {}
    oof_area = np.zeros(len(y))
    for tr, te in logo.split(X, y, groups):
        m = build_model().fit(X[tr], y[tr])
        pr = m.predict_proba(X[te])[:, 1]
        oof_area[te] = pr
        per_area[str(groups[te][0])] = metrics(y[te], (pr >= THRESHOLD).astype(int))
    report["leave_one_area_out"] = {"overall": metrics(y, (oof_area >= THRESHOLD).astype(int), oof_area), "per_area": per_area}

    # 4) Авторский ТРИЗ-индекс без обучения (фиксированные веса методологии)
    mi = np.array([F.methodology_index(f) for f in feats])
    report["methodology_index_no_training"] = metrics(y, (mi >= THRESHOLD).astype(int), mi)

    # 5) Базовые линии для сравнения
    report["baseline_random_forest"] = repeated_cv(
        lambda: RandomForestClassifier(n_estimators=300, max_depth=5, random_state=42, class_weight="balanced"), X, y, n_rep=3)

    class _TextWrap:
        def __init__(self):
            self.p = make_pipeline(TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True),
                                   LogisticRegression(max_iter=2000, class_weight="balanced"))
        def fit(self, idx, yy):
            self.p.fit([texts[i] for i in idx.ravel().astype(int)], yy); return self
        def predict_proba(self, idx):
            return self.p.predict_proba([texts[i] for i in idx.ravel().astype(int)])
    idx = np.arange(len(y)).reshape(-1, 1)
    report["baseline_tfidf_text"] = repeated_cv(lambda: _TextWrap(), idx, y, n_rep=3)

    stage_only = X[:, [F.FEATURE_NAMES.index("stage_level")]]
    report["baseline_stage_only"] = repeated_cv(lambda: build_model(), stage_only, y, n_rep=3)

    # Абляция: без признаков «исключающих факторов» и без стадии — только ТРИЗ-законы + слабость
    keep = [F.FEATURE_NAMES.index(k) for k in F.FEATURE_BLOCKS["Законы развития (ТРИЗ)"] + F.FEATURE_BLOCKS["Слабость сигнала"]]
    report["ablation_triz_only"] = repeated_cv(lambda: build_model(), X[:, keep], y, n_rep=3)

    # 5b) Стресс-тест: обучение БЕЗ «трудных» примеров фона, проверка на трудном фоне
    #     (хайп и ребрендинг, записанные в стиле датасета) + отложенные 30% слабых сигналов
    hard = np.array([str(r.get("bg_type", "")).startswith("Трудный") for r in recs])
    if hard.any():
        rng = np.random.RandomState(7)
        pos_idx = np.where(y == 1)[0]
        test_pos = rng.choice(pos_idx, size=int(0.3 * len(pos_idx)), replace=False)
        test_mask = hard.copy(); test_mask[test_pos] = True
        m = build_model().fit(X[~test_mask], y[~test_mask])
        pr = m.predict_proba(X[test_mask])[:, 1]
        st = metrics(y[test_mask], (pr >= THRESHOLD).astype(int), pr)
        st["n_hard_background"] = int(hard.sum()); st["n_heldout_signals"] = int(len(test_pos))
        report["stress_test_hard_background"] = st

    # 6) Итоговая модель на всех данных
    model = WeakSignalModel().fit(recs)
    report["coefficients"] = model.coefficients()
    acc = report["main_model_repeated_cv"]["accuracy"]["mean"]
    report["target_met"] = bool(acc >= 0.80)
    model.meta = {
        "trained_at": report["generated_at"], "n_train": int(len(y)),
        "cv_accuracy": acc, "cv_f1": report["main_model_repeated_cv"]["f1"]["mean"],
        "cv_roc_auc": report["main_model_repeated_cv"]["roc_auc"]["mean"],
        "algorithm": "LogisticRegression(C=0.5, class_weight=balanced) + StandardScaler",
        "features": F.FEATURE_NAMES,
    }
    model.save()

    # Построчные предсказания (out-of-fold, т.е. честные)
    os.makedirs(REPORT_DIR, exist_ok=True)
    rows = []
    for i, r in enumerate(recs):
        expl = model.explain_feats(feats[i], top=3)
        rows.append({
            "origin": "датасет" if r["origin"] == "dataset" else "фон",
            "row": r["row"], "name": r["name"], "area": r["area"], "true_label": int(y[i]),
            "p_oof": round(float(oof[i]), 4), "pred": int(oof[i] >= THRESHOLD),
            "p_methodology": round(float(mi[i]), 4),
            "correct": int((oof[i] >= THRESHOLD) == bool(y[i])),
            "top_predictors": "; ".join("%s (%+.2f)" % (e["title"], e["contribution"]) for e in expl),
            "bg_type": r.get("bg_type", ""),
        })
    with open(os.path.join(REPORT_DIR, "predictions.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    report["errors"] = [r for r in rows if not r["correct"]]
    with open(os.path.join(REPORT_DIR, "validation_report.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    if write_docs:
        write_markdown(report)
    return report


def evaluate_file(path: str) -> Dict:
    """Проверка произвольного файла (Excel/CSV) обученной моделью.
    Если в файле есть столбец разметки (label/Метка/Класс) — считаются метрики."""
    from .model import get_model
    model = get_model()
    df = read_table(path)
    recs = to_records(df, default_label=None, origin="upload")
    out = []
    for r in recs:
        s = model.score_record(r, mode="hybrid")
        out.append({"row": r["row"], "name": r["name"], "area": r["area"], "label": r["label"],
                    "probability": s["probability"], "p_model": s["p_model"], "p_methodology": s["p_methodology"],
                    "is_weak_signal": s["is_weak_signal"], "predictors": s["predictors"][:4],
                    "exclusion_reasons": s["exclusion_reasons"]})
    res = {"n_rows": len(out), "rows": out,
           "n_predicted_weak": sum(1 for o in out if o["is_weak_signal"]),
           "n_confident": sum(1 for o in out if o["probability"] >= 0.75)}
    labeled = [o for o in out if o["label"] is not None]
    if labeled and len(set(o["label"] for o in labeled)) >= 1 and recs and recs[0].get("has_explicit_label"):
        y = [o["label"] for o in labeled]
        p = [int(o["is_weak_signal"]) for o in labeled]
        prob = [o["probability"] for o in labeled]
        res["metrics"] = metrics(y, p, prob if len(set(y)) == 2 else None)
    else:
        res["metrics"] = None
        res["note"] = ("Столбец разметки не найден: показаны предсказания. Доля строк, распознанных как слабые сигналы: %.1f%%"
                       % (100.0 * res["n_predicted_weak"] / max(1, len(out))))
    return res


def _fmt(m):
    return "%.1f%%" % (100 * m)


def write_markdown(r: Dict):
    os.makedirs(DOCS_DIR, exist_ok=True)
    cv = r["main_model_repeated_cv"]
    oof = r["main_model_oof"]
    cm = oof["confusion_matrix"]
    L = []
    L.append("# Отчёт о проверке методологии на датасете\n")
    L.append("Сформирован автоматически: `python -m app.ml.train` · %s\n" % r["generated_at"])
    L.append("## Данные\n")
    L.append("| Набор | Строк | Класс |\n|---|---|---|")
    L.append("| `%s` (предоставлен методологами) | %d | 1 — слабый сигнал |" % (r["dataset"], r["n_weak_signals"]))
    L.append("| `%s` (контрольный «фон») | %d | 0 — зрелые технологии, стандарты, хайп, шум |" % (r["background"], r["n_background"]))
    L.append("\nПредоставленный датасет содержит только положительные примеры. Чтобы измерять именно **способность отделять** "
             "слабые сигналы от фона, в проект включён контрольный набор отрицательных примеров той же структуры "
             "(`backend/data/background_control_set.csv`, генератор — `scripts/build_background_set.py`). "
             "Если у вас есть собственная разметка (столбец `label`/`Метка`), загрузите файл во вкладке «Проверка методологии» — метрики будут пересчитаны на ней.\n")
    L.append("Столбец «Балл (стадия+тренд)» в признаки **не** включается, чтобы исключить утечку разметки.\n")
    L.append("## Главный результат\n")
    L.append("Модель: логистическая регрессия на %d интерпретируемых признаках методологии. Валидация: стратифицированная 5-кратная кросс-валидация × 10 повторов (%d фолдов).\n" % (len(r["features"]), cv["folds"]))
    L.append("| Метрика | Среднее | Ст. отклонение |\n|---|---|---|")
    for k, t in [("accuracy", "Accuracy (точность классификации)"), ("precision", "Precision"), ("recall", "Recall"), ("f1", "F1-score"), ("roc_auc", "ROC-AUC")]:
        L.append("| %s | **%s** | %s |" % (t, _fmt(cv[k]["mean"]), _fmt(cv[k]["std"])))
    L.append("\nЦелевой порог ТЗ (не ниже 75–80%%): **%s**.\n" % ("достигнут" if r["target_met"] else "не достигнут"))
    L.append("### Матрица ошибок (out-of-fold, 5 фолдов)\n")
    L.append("| | Предсказан фон | Предсказан слабый сигнал |\n|---|---|---|")
    L.append("| Фактически фон | %d | %d |" % (cm[0][0], cm[0][1]))
    L.append("| Фактически слабый сигнал | %d | %d |" % (cm[1][0], cm[1][1]))
    L.append("\n## Устойчивость и сравнение подходов\n")
    L.append("| Подход | Accuracy | F1 | ROC-AUC |\n|---|---|---|---|")
    lo = r["leave_one_area_out"]["overall"]
    mi = r["methodology_index_no_training"]
    rows = [
        ("Основная модель (LR, признаки методологии), 5×10 CV", cv["accuracy"]["mean"], cv["f1"]["mean"], cv["roc_auc"]["mean"]),
        ("Перенос на новую область (обучение на 5 областях, тест на 6-й)", lo["accuracy"], lo["f1"], lo.get("roc_auc", 0)),
        ("Авторский ТРИЗ-индекс без обучения (фиксированные веса)", mi["accuracy"], mi["f1"], mi.get("roc_auc", 0)),
        ("Random Forest на тех же признаках", r["baseline_random_forest"]["accuracy"]["mean"], r["baseline_random_forest"]["f1"]["mean"], r["baseline_random_forest"]["roc_auc"]["mean"]),
        ("Абляция: только законы ТРИЗ + слабость сигнала (без стадии и исключающих факторов)", r["ablation_triz_only"]["accuracy"]["mean"], r["ablation_triz_only"]["f1"]["mean"], r["ablation_triz_only"]["roc_auc"]["mean"]),
        ("Базовая линия: TF-IDF по тексту (без методологии)", r["baseline_tfidf_text"]["accuracy"]["mean"], r["baseline_tfidf_text"]["f1"]["mean"], r["baseline_tfidf_text"]["roc_auc"]["mean"]),
        ("Базовая линия: только стадия развития", r["baseline_stage_only"]["accuracy"]["mean"], r["baseline_stage_only"]["f1"]["mean"], r["baseline_stage_only"]["roc_auc"]["mean"]),
    ]
    if "stress_test_hard_background" in r:
        st = r["stress_test_hard_background"]
        rows.insert(2, ("Стресс-тест: трудный фон в стиле датасета (%d) + отложенные сигналы (%d), модель их не видела" % (st["n_hard_background"], st["n_heldout_signals"]), st["accuracy"], st["f1"], st.get("roc_auc", 0)))
    for t, a, f1, auc in rows:
        L.append("| %s | %s | %s | %s |" % (t, _fmt(a), _fmt(f1), _fmt(auc)))
    L.append("\n### Перенос по областям\n")
    L.append("| Тестовая область | Accuracy | Recall | Precision |\n|---|---|---|---|")
    for a, m in r["leave_one_area_out"]["per_area"].items():
        L.append("| %s | %s | %s | %s |" % (a, _fmt(m["accuracy"]), _fmt(m["recall"]), _fmt(m["precision"])))
    L.append("\n## Какие признаки решают (коэффициенты модели)\n")
    L.append("Положительный коэффициент — признак за слабый сигнал, отрицательный — за зрелость/хайп/шум (признаки стандартизированы).\n")
    L.append("| Признак | Коэффициент | Смысл по методологии |\n|---|---|---|")
    info = {f["name"]: f["meaning"] for f in r["features"]}
    for c in r["coefficients"]:
        L.append("| %s | %+.3f | %s |" % (c["title"], c["coef"], info[c["feature"]]))
    L.append("\n## Ошибки классификации (out-of-fold)\n")
    if r["errors"]:
        L.append("| Набор | Технология | Истина | Вероятность | Главные предикторы |\n|---|---|---|---|---|")
        for e in r["errors"]:
            L.append("| %s | %s | %s | %.2f | %s |" % (e["origin"], e["name"], "слабый сигнал" if e["true_label"] else "фон", e["p_oof"], e["top_predictors"]))
    else:
        L.append("Ошибок нет.")
    L.append("\n## Ограничения\n")
    L.append("- Отрицательный класс сформирован проектной командой; скрытая разметка организаторов может отличаться — поэтому в интерфейсе есть загрузка собственного размеченного файла и пересчёт метрик.")
    L.append("- Лексиконы признаков русско-английские; для других языков нужна их адаптация.")
    L.append("- Высокая точность на контрольном наборе означает, что признаки методологии хорошо разделяют «ранний сигнал» и «зрелый фон»; экспертная проверка (human-in-the-loop) остаётся обязательной.")
    L.append("\nПострочные предсказания: `backend/reports/predictions.csv`; полный JSON: `backend/reports/validation_report.json`.\n")
    with open(os.path.join(DOCS_DIR, "dataset-validation-report.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L))


if __name__ == "__main__":
    rep = run()
    cv = rep["main_model_repeated_cv"]
    print("Accuracy %.3f±%.3f  F1 %.3f  ROC-AUC %.3f" % (cv["accuracy"]["mean"], cv["accuracy"]["std"], cv["f1"]["mean"], cv["roc_auc"]["mean"]))
    print("Перенос по областям:", rep["leave_one_area_out"]["overall"])
    print("ТРИЗ-индекс без обучения:", rep["methodology_index_no_training"])
    print("TF-IDF:", rep["baseline_tfidf_text"]["accuracy"], "Stage only:", rep["baseline_stage_only"]["accuracy"], "TRIZ-only:", rep["ablation_triz_only"]["accuracy"])
    print("Стресс-тест:", rep.get("stress_test_hard_background"))
    print("Ошибки:", [(e["name"], e["p_oof"]) for e in rep["errors"]])
