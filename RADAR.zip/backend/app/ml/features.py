# -*- coding: utf-8 -*-
"""
Признаки авторской методологии (ТРИЗ / законы развития технических систем).

Один и тот же набор признаков вычисляется:
  * для строк обучающего датасета (Excel);
  * для кандидатов, найденных при открытом поиске по источникам
    (после «текстуализации» собранных доказательств, см. services/evidence.py).

Каждый признак интерпретируем: для него хранится русское название и
описание смысла по методологии. Никаких «чёрных ящиков» — модель поверх
этих признаков — логистическая регрессия с объяснимыми вкладами.
"""
import re
from typing import Dict, Iterable, List, Optional
from urllib.parse import urlparse

# ---------------------------------------------------------------------------
# Лексиконы (RU + EN). Используются основы слов, поиск без учёта регистра.
# ---------------------------------------------------------------------------
LEX = {
    # 1. Техническое / физическое противоречие
    "contradiction": [
        r"\bно\b", "однако", "компромисс", "противореч", "ценой", "в ущерб", "не влезает",
        "нельзя", "невозможн", "ограничен", "узкое место", "bottleneck", "trade-off", "tradeoff",
        "без потери", "без ухудшения", "при этом", "конфликт", "дефицит", "не хватает",
        "проблем", "барьер", "мешает", "without sacrificing", "limitation", "challenge",
    ],
    # 2. Смена принципа действия
    "principle_shift": [
        "вместо", "переход от", "поворот", "разворот", "новый принцип", "иной принцип",
        "другой принцип", "впервые", "смена", "альтернатив", "замен", "→", "от «", "a new approach",
        "novel", "paradigm", "instead of", "first demonstration", "first-ever", "breakthrough in principle",
        "новый класс", "новая категория", "новая ниша", "отдельный слой", "самостоятельн",
    ],
    # 3. Переход в надсистему
    "supersystem": [
        "платформ", "экосистем", "интеграц", "встраива", "встроен", "слой стека", "control plane",
        "оркестрац", "стек", "надсистем", "модуль", "инфраструктур", "network of", "platform",
        "ecosystem", "integration", "marketplace", "протокол", "api", "sdk",
    ],
    # 4. Рост идеальности (польза / затраты)
    "ideality": [
        "дешевле", "снижа", "сокраща", "экономи", "меньше", "в \\d+ раз", "×", "эффективн",
        "без дополнительн", "без облака", "без сервер", "автоматически", "cheaper", "lower cost",
        "reduc", "efficien", "energy-efficient", "low-power", "энергоэффектив", "малым энергопотреблен",
        "не требует", "без участия", "самообслуж",
    ],
    # 5. Динамизация и управляемость
    "dynamization": [
        "адаптив", "автоном", "программно", "реконфигур", "динамическ", "модульн", "гибк",
        "в реальном времени", "самонастр", "adaptive", "autonomous", "reconfigur", "real-time",
        "self-", "агент", "agentic", "управля",
    ],
    # 6. Переход на микроуровень и новые эффекты
    "micro_effects": [
        "квант", "фотон", "оптическ", "нейроморф", "аналогов", "in-memory", "в памяти",
        "молекул", "материал", "нано", "спин", "сверхпровод", "биолог", "днк", "rna", "рнк",
        "химическ", "физическ", "эффект", "quantum", "photonic", "neuromorphic", "analog",
        "memristor", "мемристор", "spiking", "пиксел", "сенсор", "chiplet", "чиплет", "3d",
        "перовскит", "graphene", "графен", "field", "поле", "plasma", "плазм",
    ],
    # 7. Предел старой S-кривой
    "scurve_limit": [
        "предел", "упира", "исчерпа", "стена", "wall", "limit", "замедл", "насыщен старой",
        "не масштабир", "дорогой костыль", "компенсац", "сложност", "перегрев", "энергопотреблен",
        "тепловыделен", "дефицит мощност", "power wall", "memory wall", "памят[ьи] не хватает",
    ],
    # 8. Раннее, нишевое освещение (слабость сигнала)
    "niche": [
        "почти не", "практически нет", "нишев", "узк", "мало", "единичн", "первые", "первый",
        "stealth", "препринт", "preprint", "arxiv", "не освещ", "не обсужда", "без устоявшегося",
        "нет продукт", "нет коммерческ", "без продуктов", "только в", "исключительно в",
        "в основном в", "почти неосвещ", "свежая", "новая ветвь", "ещё нет", "пока нет",
        "ранн", "зарожда", "emerging", "early-stage", "nascent", "pilot", "пилот", "poc",
        "прототип", "лаборатор",
    ],
    # 9. Ранний тип финансирования (не зрелый рынок)
    "early_funding": [
        "pre-seed", "seed", "series a", "series b", "посевн", "грант", "grant", "раунд",
        r"\$\d+(?:[.,]\d+)?\s?m\b", r"€\d+(?:[.,]\d+)?\s?(?:млн|m)", r"\$\d+(?:[.,]\d+)?\s?млн",
        "darpa", "horizon europe", "nsf", "венчур",
    ],
    # 10. Признаки зрелости (исключающий фактор)
    "maturity": [
        "массов", "повсеместн", "лидер", "доля рынка", "долей", "стандарт", "сформирован",
        "консолидир", "десятилет", "миллион", "миллиард пользовател", "коммодит",
        "устойчив", "зрел", "established", "mainstream", "market leader", "widely adopted",
        "de facto", "де-факто", "gartner", "традиционн", "классическ",
    ],
    # 11. Маркетинговый хайп (исключающий фактор)
    "hype": [
        "революц", "изменит всё", "заменит", "гарантир", "будущее", "хайп", "маркетинг",
        "обещан", "лозунг", "рекламн", "реклам", "вирусн", "громк", "в каждом доме",
        "уже в этом году", "в следующем квартале", "в 100 раз", "modные", "модных терминов",
        "game changer", "revolution", "hype", "buzz",
    ],
    # 12. Информационный шум / низкая доверенность (исключающий фактор)
    "noise": [
        "соцсет", "социальн сет", "блог", "telegram", "телеграм", "агрегатор", "анонимн",
        "без первоисточник", "без технических", "таблоид", "инфлюенсер", "перепечат",
        "без данных", "шум",
    ],
    # 13. Инерция старой системы (упоминание зрелой альтернативы как фона)
    "inertia": [
        "инерци", "уходящ", "устаревш", "legacy", "считалась «мёртвой»", "считалась мёртвой",
        "вместо традиционн", "по сравнению с традиционн", "старой систем", "прежн",
    ],
}

STAGE_LEVELS = [
    # (шаблон, уровень зрелости 1..6)
    (r"массов|зрел|отраслев.*стандарт|стандарт|mass|mature", 6),
    (r"раннее массов", 5),
    (r"раннее внедрение|ранние внедрения|раннее внедр|первые внедр|ранняя серия|ранние поставки|early adoption", 4),
    (r"пилот|pilot", 3),
    (r"прототип|poc|prototype", 2),
    (r"концепци|исследован|research|concept", 1),
]

TRUSTED_DOMAINS = [
    "arxiv.org", "nature.com", "science.org", "sciencedirect.com", "springer", "ieee.org", "acm.org",
    "openalex.org", "crossref.org", "doi.org", "ncbi.nlm.nih.gov", "europepmc.org", "biorxiv.org",
    "medrxiv.org", "clinicaltrials.gov", "who.int", "patents.google.com", "wipo.int", "epo.org",
    "espacenet", "uspto.gov", "lens.org", "osti.gov", "nasa.gov", "zenodo.org", "hal.science",
    "archives-ouvertes.fr", "doaj.org", "datacite.org", "ssrn.com", "repec.org", "github.com",
    ".gov", ".edu", ".ac.", "gov.ru", "cbr.ru", "bis.org", "imf.org", "oecd.org", "europa.eu",
    "owasp.org", "nist.gov", "iso.org", "ietf.org", "mit.edu", "stanford.edu", "reuters.com",
    "ft.com", "bloomberg.com", "siliconangle.com", "techcrunch.com", "securityweek.com",
    "theregister.com", "spectrum.ieee.org", "eetimes.com", "semianalysis.com", "wsj.com",
]
LOW_TRUST_DOMAINS = [
    "medium.com", "telegram", "t.me", "youtube.com", "facebook.com", "twitter.com", "x.com",
    "vk.com", "reddit.com", "prnewswire.com", "businesswire.com", "globenewswire.com",
    "blogspot", "wordpress", "substack.com", "tiktok.com", "instagram.com", "dzen.ru",
]

FEATURE_INFO = {
    "stage_level":      ("Уровень зрелости (стадия)", "1 — концепция/исследование … 6 — массовое внедрение/стандарт. Чем выше — тем меньше шансов, что это слабый сигнал."),
    "stage_early":      ("Ранняя стадия", "Стадия от концепции до раннего внедрения: система ещё не вышла на массовое применение."),
    "trend_fast":       ("Быстрый рост упоминаний", "Скачкообразный рост от единичных упоминаний — ранний участок новой S-кривой."),
    "trend_growth":     ("Рост упоминаний", "Устойчивый рост активности (публикации, патенты, раунды, пилоты)."),
    "trend_flat":       ("Стабильность / насыщение", "Плато упоминаний — признак зрелой системы на верхнем участке S-кривой."),
    "trend_peak_drop":  ("Пик и спад (хайп-цикл)", "Резкий пик и затем падение интереса — типичный профиль хайпа."),
    "recency":          ("Свежесть датировок", "Датировки 2024–2026 в описании динамики: первые события произошли недавно."),
    "contradiction":    ("Техническое противоречие", "Описан конфликт «улучшаем A — ухудшается B», который снимает технология."),
    "principle_shift":  ("Смена принципа действия", "Не «ещё более мощная версия», а иной принцип, архитектура или класс решений."),
    "supersystem":      ("Переход в надсистему", "Функция встраивается в платформу/экосистему/стек как модуль."),
    "ideality":         ("Рост идеальности", "Та же полезная функция при меньших затратах, энергии, сложности."),
    "dynamization":     ("Динамизация и управляемость", "Переход к адаптивным, программно управляемым, автономным системам."),
    "micro_effects":    ("Микроуровень и новые эффекты", "Использование новых физических, химических, биологических или информационных эффектов."),
    "scurve_limit":     ("Предел старой S-кривой", "Прежний принцип упирается в предел: тепло, энергия, память, стоимость."),
    "niche":            ("Нишевое / раннее освещение", "Тема живёт в препринтах, патентах, нишевых медиа; мейнстрим её ещё не заметил."),
    "early_funding":    ("Раннее финансирование", "Гранты, pre-seed/seed/Series A — рынок ещё не сформирован."),
    "maturity":         ("Признаки зрелого рынка", "Массовое внедрение, лидеры, стандарты, консолидация — исключающий фактор."),
    "hype":             ("Маркетинговый хайп", "Рекламные обещания без механизма и проверки — исключающий фактор."),
    "noise":            ("Информационный шум", "Соцсети, блоги, агрегаторы, анонимные ресурсы без первоисточников."),
    "inertia":          ("Инерция старой системы", "Упоминается уходящая/устаревшая система, которую поддерживает инерция."),
    "n_sources":        ("Число источников", "Количество ссылок на первоисточники (логарифм)."),
    "trusted_share":    ("Доля доверенных источников", "Научные, патентные, государственные, профильные отраслевые источники."),
    "low_trust_share":  ("Доля источников с пониженной доверенностью", "Соцсети, блоги, пресс-релизы, агрегаторы."),
    "n_domains":        ("Независимые домены", "Число независимых доменов-источников (логарифм)."),
    "n_actors":         ("Число независимых игроков", "Компании/лаборатории, работающие над темой: несколько независимых игроков — признак зарождения направления."),
}

ALL_FEATURES = list(FEATURE_INFO.keys())
# В обучаемую модель НЕ включаются счётчики ссылок/доменов/компаний: в контрольном наборе
# «фона» их количество задано составителем и могло бы стать артефактом стиля, а не
# признаком методологии. Эти величины вычисляются и показываются в UI как справочные.
DISPLAY_ONLY = ["n_sources", "n_domains", "n_actors"]
FEATURE_NAMES = [k for k in ALL_FEATURES if k not in DISPLAY_ONLY]

# Группировка признаков по блокам методологии (для отчётов и UI)
FEATURE_BLOCKS = {
    "Законы развития (ТРИЗ)": ["contradiction", "principle_shift", "supersystem", "ideality", "dynamization", "micro_effects", "scurve_limit", "inertia"],
    "Стадия и S-кривая": ["stage_level", "stage_early", "trend_fast", "trend_growth", "trend_flat", "trend_peak_drop", "recency"],
    "Слабость сигнала": ["niche", "early_funding"],
    "Исключающие факторы": ["maturity", "hype", "noise"],
    "Качество источников": ["trusted_share", "low_trust_share"],
}

_COMPILED = {k: [re.compile(p, re.I) for p in v] for k, v in LEX.items()}
_URL_RE = re.compile(r"https?://[^\s\)\]\"'<>,]+", re.I)


def _count(key: str, text: str) -> int:
    return sum(len(p.findall(text)) for p in _COMPILED[key])


def _sat(n: float, k: float = 2.0) -> float:
    """Насыщающая функция: 0 → 0, k → ~0.63, много → 1."""
    import math
    return 1.0 - math.exp(-float(n) / k)


def matched_terms(key: str, text: str, limit: int = 6) -> List[str]:
    out = []
    for p in _COMPILED[key]:
        for m in p.finditer(text):
            s = m.group(0).strip()
            if s and s.lower() not in [o.lower() for o in out]:
                out.append(s)
            if len(out) >= limit:
                return out
    return out


def matched_contexts(key: str, text: str, limit: int = 3, words: int = 4) -> List[str]:
    """Фрагменты исходного текста вокруг найденных маркеров (для показа доказательств оператору)."""
    out, spans = [], []
    low = text.lower()
    for p in _COMPILED[key]:
        for m in p.finditer(low):
            a, b = m.start(), m.end()
            if any(a < e and b > st for st, e in spans):
                continue
            # расширяем до границ слов и ±N слов
            left = text[:a].split()
            right = text[b:].split()
            lw = left[-words:] if left else []
            core_left = "" if (a == 0 or text[a - 1].isspace()) else (lw.pop() if lw else "")
            core_right = "" if (b >= len(text) or text[b].isspace()) else (right.pop(0) if right else "")
            frag = " ".join(lw + [core_left + text[a:b] + core_right] + right[:words]).strip(" ,.;:")
            spans.append((a, b))
            if frag and frag not in out:
                out.append("…" + frag + "…")
            if len(out) >= limit:
                return out
    return out


def stage_level(stage: str) -> int:
    s = (stage or "").lower()
    if not s.strip():
        return 3
    # Смешанные стадии «Прототип → Раннее внедрение» — берём минимальную
    # (по методологии важна стадия, на которой находится большинство игроков).
    levels = []
    for part in re.split(r"→|/|\+|;|\(|\)", s):
        part = part.strip()
        if not part:
            continue
        for pat, lvl in STAGE_LEVELS[::-1]:  # от ранних к зрелым
            if re.search(pat, part):
                levels.append(lvl)
                break
    if not levels:
        return 3
    # «раннее массовое» и «массовое» перекрывают ранние уровни
    if any(l >= 5 for l in levels):
        return max(levels)
    return min(levels)


def parse_urls(sources) -> List[str]:
    if sources is None:
        return []
    if isinstance(sources, (list, tuple)):
        urls = []
        for s in sources:
            if isinstance(s, dict):
                u = s.get("url") or ""
                if u:
                    urls.append(u)
            elif isinstance(s, str):
                urls.extend(_URL_RE.findall(s) or ([s] if s.startswith("http") else []))
        return urls
    return _URL_RE.findall(str(sources))


def domain_of(url: str) -> str:
    try:
        d = urlparse(url).netloc.lower()
        return d[4:] if d.startswith("www.") else d
    except Exception:
        return ""


def trust_level(url: str, source_type: Optional[str] = None) -> str:
    """Уровень доверенности: высокий / средний / пониженный."""
    d = domain_of(url)
    st = (source_type or "").lower()
    if any(t in d for t in LOW_TRUST_DOMAINS) or st in ("social", "blog", "press_release", "aggregator"):
        return "пониженный"
    if any(t in d for t in TRUSTED_DOMAINS) or st in ("preprint", "article", "patent", "clinical_trial", "dataset", "government", "report"):
        return "высокий"
    return "средний"


def extract(record: Dict) -> Dict[str, float]:
    """
    record: {name, text/why, stage, trend, companies, sources}
    Возвращает словарь признаков FEATURE_NAMES.
    """
    name = str(record.get("name") or "")
    why = str(record.get("why") or record.get("text") or "")
    stage = str(record.get("stage") or "")
    trend = str(record.get("trend") or "")
    companies = str(record.get("companies") or "")
    text = " ".join([name, why, trend]).lower()
    trend_l = trend.lower()

    f = {}
    lvl = stage_level(stage)
    f["stage_level"] = float(lvl)
    f["stage_early"] = 1.0 if lvl <= 4 else 0.0

    f["trend_fast"] = 1.0 if re.search(r"растёт быстро|растет быстро|быстр|скачкообраз|кратн|резк(ий|о) рост|rapid", trend_l) else 0.0
    f["trend_growth"] = 1.0 if re.search(r"раст|рост|grow|увелич", trend_l) else 0.0
    f["trend_flat"] = 1.0 if re.search(r"стабил|насыщ|плато|flat|stable", trend_l) and not f["trend_fast"] else 0.0
    f["trend_peak_drop"] = 1.0 if re.search(r"пик.*(спад|паден|обвал)|спад|паден|снижа|обвал|decline", trend_l) else 0.0
    years = re.findall(r"20(2[3-9])", trend + " " + why)
    f["recency"] = _sat(len(years), 2.0)

    for key in ["contradiction", "principle_shift", "supersystem", "ideality", "dynamization",
                "micro_effects", "scurve_limit", "niche", "early_funding", "maturity", "hype",
                "noise", "inertia"]:
        f[key] = _sat(_count(key, text + " " + stage.lower()), 2.0)

    urls = parse_urls(record.get("sources"))
    import math
    f["n_sources"] = math.log1p(len(urls))
    domains = sorted(set(domain_of(u) for u in urls if u))
    f["n_domains"] = math.log1p(len(domains))
    if urls:
        tl = [trust_level(u) for u in urls]
        f["trusted_share"] = tl.count("высокий") / float(len(tl))
        f["low_trust_share"] = tl.count("пониженный") / float(len(tl))
    else:
        f["trusted_share"] = 0.0
        f["low_trust_share"] = 0.0
    actors = [c for c in re.split(r",|;|\n", companies) if c.strip()]
    f["n_actors"] = math.log1p(len(actors))
    return f


def vectorize(records: Iterable[Dict]):
    rows = [extract(r) for r in records]
    return [[r[k] for k in FEATURE_NAMES] for r in rows], rows


# ---------------------------------------------------------------------------
# Авторский методологический индекс (без обучения) — «ТРИЗ-индекс слабого сигнала»
# ---------------------------------------------------------------------------
METHOD_WEIGHTS = {
    "contradiction": 1.0, "principle_shift": 1.2, "supersystem": 0.6, "ideality": 0.6,
    "dynamization": 0.5, "micro_effects": 0.7, "scurve_limit": 0.6, "inertia": 0.4,
    "niche": 1.2, "early_funding": 0.5, "stage_early": 1.5, "trend_growth": 0.8,
    "trend_fast": 0.6, "recency": 0.8,
    "maturity": -1.8, "hype": -2.0, "noise": -2.0, "trend_flat": -1.0, "trend_peak_drop": -1.0,
    "low_trust_share": -1.5, "trusted_share": 0.3,
}
METHOD_BIAS = -3.2


def methodology_index(f: Dict[str, float]) -> float:
    """Возвращает вероятностную оценку 0..1 по правилам методологии (без обучения)."""
    import math
    z = METHOD_BIAS + sum(w * f.get(k, 0.0) for k, w in METHOD_WEIGHTS.items())
    z -= 0.35 * max(0.0, f.get("stage_level", 3) - 4)
    return 1.0 / (1.0 + math.exp(-z))


def methodology_explain(f: Dict[str, float], top: int = 6):
    items = []
    for k, w in METHOD_WEIGHTS.items():
        c = w * f.get(k, 0.0)
        if abs(c) > 1e-6:
            items.append((k, c))
    items.sort(key=lambda x: -abs(x[1]))
    return [{"feature": k, "title": FEATURE_INFO[k][0], "contribution": round(c, 3),
             "direction": "за слабый сигнал" if c > 0 else "против (зрелость/хайп/шум)"} for k, c in items[:top]]
