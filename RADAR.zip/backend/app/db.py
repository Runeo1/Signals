# -*- coding: utf-8 -*-
"""
Хранилище: PostgreSQL (основной режим, Docker) или SQLite (локальный запуск без Docker).
URL задаётся переменной DATABASE_URL, например:
  postgresql+psycopg2://radar:radar@db:5432/radar
"""
import datetime as dt
import json
import os
from contextlib import contextmanager

from sqlalchemy import (JSON, Boolean, Column, DateTime, Float, ForeignKey, Integer, String, Text,
                        create_engine, text)
from sqlalchemy.orm import declarative_base, sessionmaker

BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_SQLITE = "sqlite:///" + os.path.join(BACKEND_DIR, "data", "radar.sqlite3")
DATABASE_URL = os.getenv("DATABASE_URL", DEFAULT_SQLITE)

engine = create_engine(DATABASE_URL, pool_pre_ping=True, future=True,
                       connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False, future=True)
Base = declarative_base()


def now():
    return dt.datetime.utcnow()


class Setting(Base):
    __tablename__ = "settings"
    key = Column(String(100), primary_key=True)
    value = Column(Text, nullable=True)
    updated_at = Column(DateTime, default=now, onupdate=now)


class SearchRun(Base):
    __tablename__ = "search_runs"
    id = Column(String(32), primary_key=True)
    query = Column(Text, nullable=False)
    query_en = Column(Text)
    mode = Column(String(20))
    sources = Column(JSON)
    status = Column(String(20))
    started_at = Column(DateTime, default=now)
    finished_at = Column(DateTime)
    stats = Column(JSON)
    result = Column(JSON)


class RawDocument(Base):
    """Сырые собранные документы (слой ETL)."""
    __tablename__ = "raw_documents"
    id = Column(Integer, primary_key=True, autoincrement=True)
    run_id = Column(String(32), ForeignKey("search_runs.id", ondelete="CASCADE"), index=True)
    source_id = Column(String(40), index=True)
    source_type = Column(String(40))
    title = Column(Text)
    abstract = Column(Text)
    url = Column(Text)
    pub_date = Column(String(20))
    year = Column(Integer)
    language = Column(String(10))
    trust = Column(String(60))
    authors = Column(Text)
    venue = Column(Text)
    fetched_at = Column(DateTime, default=now)


class Candidate(Base):
    """Результаты анализа: кандидаты в слабые сигналы (в т.ч. исключённые)."""
    __tablename__ = "candidates"
    id = Column(Integer, primary_key=True, autoincrement=True)
    run_id = Column(String(32), ForeignKey("search_runs.id", ondelete="CASCADE"), index=True)
    rank = Column(Integer)
    name = Column(Text)
    name_original = Column(Text)
    probability = Column(Float)
    is_weak_signal = Column(Boolean)
    excluded = Column(Boolean, default=False)
    payload = Column(JSON)
    created_at = Column(DateTime, default=now)


class AuditLog(Base):
    """Журнал: вход, изменение настроек, обращения к LLM, переобучение модели."""
    __tablename__ = "audit_log"
    id = Column(Integer, primary_key=True, autoincrement=True)
    ts = Column(DateTime, default=now)
    event = Column(String(60))
    details = Column(JSON)


def init_db():
    os.makedirs(os.path.join(BACKEND_DIR, "data"), exist_ok=True)
    Base.metadata.create_all(engine)


@contextmanager
def session():
    s = SessionLocal()
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()


def get_setting(key, default=None):
    with session() as s:
        row = s.get(Setting, key)
        return row.value if row and row.value is not None else default


def set_setting(key, value):
    with session() as s:
        row = s.get(Setting, key)
        if row is None:
            s.add(Setting(key=key, value=value))
        else:
            row.value = value


def get_json(key, default=None):
    v = get_setting(key)
    if v is None:
        return default
    try:
        return json.loads(v)
    except Exception:
        return default


def set_json(key, value):
    set_setting(key, json.dumps(value, ensure_ascii=False))


def audit(event, details=None, strict=False):
    try:
        with session() as s:
            s.add(AuditLog(event=event, details=details or {}))
    except Exception:
        if strict:
            raise


def db_kind():
    return "PostgreSQL" if DATABASE_URL.startswith("postgresql") else "SQLite"


def ping():
    with engine.connect() as c:
        c.execute(text("SELECT 1"))
    return True
