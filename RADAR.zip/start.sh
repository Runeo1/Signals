#!/usr/bin/env bash
# Запуск справочника в Linux/macOS: ./start.sh
exec "$(dirname "$0")/scripts/start_local.sh" "$@"
