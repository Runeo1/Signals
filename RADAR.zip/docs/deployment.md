# Развёртывание

## Вариант 1. Docker Compose (рекомендуется)

Требования: Docker Engine 24+ с Compose v2 (Docker Desktop для Windows/macOS), 2 ГБ ОЗУ, доступ в интернет к открытым API.

```bash
unzip weak-signals-radar.zip && cd weak-signals-radar
cp .env.example .env            # ключи необязательны
docker compose up -d --build
docker compose ps               # все три сервиса в состоянии running/healthy
```

| Сервис | Адрес | Назначение |
|---|---|---|
| frontend | http://localhost:8080 | интерфейс справочника |
| backend | http://localhost:8000/docs | REST API и Swagger |
| db | внутренний порт 5432 | PostgreSQL 16, том `pgdata` |

При сборке образа backend модель обучается заново и формирует отчёт о валидации — результат воспроизводим.

Полезные команды:

```bash
docker compose logs -f backend          # журнал поиска и обращений к источникам
docker compose exec backend pytest -q   # тесты внутри контейнера
docker compose exec backend python -m app.ml.train   # переобучение
docker compose down                     # остановка (данные сохраняются)
docker compose down -v                  # остановка с удалением БД
```

Файл `.env` необязателен: Compose читает его автоматически, если он есть.

## Вариант 2. Локально, без Docker

```bash
cd backend
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python run.py        # сам проверит модель, выберет свободный порт и откроет браузер
# (или: uvicorn app.main:app --host 127.0.0.1 --port 8000)
```

По умолчанию используется SQLite (`backend/data/radar.sqlite3`). Для PostgreSQL:

```bash
createuser -P radar && createdb -O radar radar
pip install -r requirements-postgres.txt
export DATABASE_URL=postgresql+psycopg2://radar:radar@localhost:5432/radar   # Windows: set DATABASE_URL=...
```

Frontend:

```bash
cd frontend
npm install
npm run dev          # http://localhost:5173, /api проксируется на :8000
# или сборка и раздача самим FastAPI:
npm run build && cp -r dist ../backend/static     # затем http://localhost:8000
```

## Вариант 3. Раздельное размещение (облако)

* Backend — любой хостинг контейнеров (Yandex Cloud Serverless Containers, VK Cloud, Render, Fly.io и т. п.) с переменной `DATABASE_URL` на управляемый PostgreSQL.
* Frontend — любой статический хостинг; в `config.js` укажите адрес backend: `window.RADAR_API = "https://radar-api.example.org";`.

## Размещение в репозитории

```bash
git init && git add . && git commit -m "Справочник слабых сигналов v3"
git remote add origin https://github.com/<организация>/weak-signals-radar.git
git push -u origin main
```

После этого любой проверяющий запускает проект командами `git clone …` и `docker compose up -d --build`.

## Переменные окружения

| Переменная | Назначение |
|---|---|
| `DATABASE_URL` | строка подключения SQLAlchemy |
| `JWT_SECRET` | секрет токенов (если не задан — генерируется и хранится в БД) |
| `OPENALEX_API_KEY`, `SEMANTIC_SCHOLAR_API_KEY`, `NEWSAPI_KEY`, `CORE_API_KEY`, `NASA_ADS_TOKEN`, `LENS_API_TOKEN`, `EPO_OPS_KEY`, `PATENTSVIEW_API_KEY`, `REPEC_API_CODE` | ключи источников (можно ввести в интерфейсе) |
| `LLM_PROVIDER`, `LLM_MODEL`, `LLM_API_KEY`, `LLM_FOLDER_ID`, `LLM_BASE_URL` | необязательная генеративная модель для перевода и резюме |
| `STATIC_DIR` | папка со сборкой интерфейса (по умолчанию `backend/static`) |

## Проверка работоспособности

1. `curl http://localhost:8000/api/health` → `"status":"ok"`, `"database_ok":true`.
2. Откройте интерфейс, задайте пароль.
3. «🔌 API источники» → «🧪 Тестировать подключение»: зелёные точки у источников без ключа.
4. «🔎 Открытый поиск» → пример «слабые сигналы в области кибербезопасности» → поиск завершится полным либо явно неполным результатом; максимальное время конвейера — 240 секунд.
5. «🧪 Проверка методологии» → метрики, матрицы ошибок, загрузка своего файла.

## Дополнительная проверка PostgreSQL

После `docker compose up -d --build`:

```bash
docker compose cp scripts/verify_postgres.py backend:/tmp/verify_postgres.py
docker compose exec -e PYTHONPATH=/app backend python /tmp/verify_postgres.py
```

Проверка делает запись и чтение JSON, UTF-8, сырых документов и кандидатов в транзакции с откатом. Это проверка подключения и ORM, не нагрузочный тест. Docker и PostgreSQL не доступны в среде подготовки данного архива, поэтому результат этой команды не заявлен как проверенный.

## LLM

Вызовы ограничены сочетаниями провайдер/модель и официальными endpoint. Проверка повторяется перед каждым вызовом, включая настройки из окружения. Версии Yandex закреплены явными URI, без `/latest`. Поддержка Qwen через произвольный endpoint отключена до настройки согласованного сервиса. GigaChat использует `https://api.giga.chat/v1` с проверкой TLS. При необходимости установите доверенный сертификат провайдера в системное хранилище, не отключайте проверку TLS.

Документация использованных API:
- https://aistudio.yandex.ru/en/docs/ai-studio/concepts/generation/models
- https://developers.sber.ru/docs/ru/gigachat/api/reference/rest/gigachat-api

Каждое обращение имеет записи начала и исхода в `audit_log` без ключа и текста запроса. Если журнал недоступен, новый вызов блокируется.
