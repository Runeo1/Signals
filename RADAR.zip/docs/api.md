# REST API

Интерактивная документация (Swagger): `http://localhost:8000/docs`, ReDoc: `/redoc`, схема: `/openapi.json`.

Авторизация: `Authorization: Bearer <token>`. Токен выдают `/api/auth/setup`, `/api/auth/login` или `/api/auth/open` (если оператор отключил запрос пароля). Если запрос пароля отключён, остальные методы доступны без токена.

## Вход

| Метод | Путь | Описание |
|---|---|---|
| GET | `/api/auth/status` | `{password_set, require_password}` |
| POST | `/api/auth/setup` | `{password}` — первичная установка пароля (один раз) |
| POST | `/api/auth/login` | `{password}` → `{token}` |
| POST | `/api/auth/open` | вход без пароля, если он отключён |
| POST | `/api/auth/change` | `{current, new}` — смена пароля |
| POST | `/api/auth/require` | `{require_password: bool, current}` — запрашивать ли пароль при входе |

## Источники

| Метод | Путь | Описание |
|---|---|---|
| GET | `/api/sources` | 26 источников: группа, тип доступа (`free`, `optional`, `key`, `link`), наличие ключа, где его получить |
| POST | `/api/sources/test` | тело — массив id (или пусто — все); ответ: статус, число документов, время |
| PUT | `/api/keys` | `{source_id, key}` — сохранить ключ и сразу проверить |
| DELETE | `/api/keys/{source_id}` | удалить ключ |
| GET/PUT | `/api/llm` | настройки генеративной модели (только модели из списка ТЗ) |

## Поиск

```bash
# запуск
curl -X POST http://localhost:8000/api/search -H "Authorization: Bearer $T" \
     -H "Content-Type: application/json" \
     -d '{"query":"слабые сигналы в области кибербезопасности","mode":"hybrid"}'
# → {"id":"a1b2c3d4e5f6","status":"running"}

# прогресс и результат
curl http://localhost:8000/api/search/a1b2c3d4e5f6 -H "Authorization: Bearer $T"

# остановить выполняющийся поиск
curl -X POST http://localhost:8000/api/search/a1b2c3d4e5f6/cancel -H "Authorization: Bearer $T"

# собранные документы запуска и удаление запуска
curl http://localhost:8000/api/runs/a1b2c3d4e5f6/documents -H "Authorization: Bearer $T"
curl -X DELETE http://localhost:8000/api/runs/a1b2c3d4e5f6 -H "Authorization: Bearer $T"
```

`mode`: `hybrid` | `methodology` | `library`; `sources` — необязательный список id источников.

Ответ во время работы: `status=running`, `progress` (0–100), `stage`, `eta_sec`, `log`. После завершения — `result`:

```json
{
  "query": "...", "query_en": "...", "mode": "hybrid",
  "stats": {"sources_requested": 17, "sources_ok": 13, "documents": 258, "candidates": 30,
            "top": 15, "weak_signals": 15, "confident_75": 12, "excluded": 11},
  "sources_status": [{"id": "arxiv", "name": "...", "status": "ok", "n": 40, "ms": 2100, "link": "..."}],
  "items": [{
    "rank": 1, "name": "агентные рабочие процессы", "name_original": "agentic workflows",
    "description": "...", "description_method": "автоматический перевод (Google Translate)",
    "advantage": "...", "case": {"kind": "Патент", "title": "...", "org": "...", "date": "...", "url": "..."},
    "probability": 0.93, "p_model": 0.95, "p_methodology": 0.90, "confident": true,
    "stage": "Прототип/PoC", "trend": "Растёт быстро: ...", "strength": "Слабый", "impact": "Высокий", "horizon": "5–10 лет",
    "predictors": [{"feature": "niche", "title": "Нишевое / раннее освещение", "contribution": 1.2}],
    "triz_evidence": {"Смена принципа действия": ["..."]},
    "status_explanation": "...", "analytics": [{"label": "...", "value": 123, "url": "..."}],
    "sources": [{"name": "...", "url": "...", "date": "2026-05-02", "type": "Препринт", "language": "английский",
                 "trust": "высокий (научный)", "summary_ru": "...", "summary_method": "автоматический перевод (Google Translate)"}]
  }],
  "excluded": [{"name": "intrusion detection", "name_ru": "обнаружение вторжений", "probability": 0.29, "reasons": ["..."]}]
}
```

| Метод | Путь | Описание |
|---|---|---|
| GET | `/api/runs` | история запусков |
| GET | `/api/runs/{id}/documents` | сырые документы запуска |
| GET | `/api/catalog` | карточки справочника (датасет + результаты поисков) |

## Модель

| Метод | Путь | Описание |
|---|---|---|
| GET | `/api/model/info` | метаданные, коэффициенты, признаки, отчёт о валидации |
| GET | `/api/model/predictions` | out-of-fold предсказания по 232 строкам |
| POST | `/api/model/score` | `{name, why, stage, trend, mode}` — оценка одной технологии с объяснением |
| POST | `/api/model/validate` | multipart `file` (.xlsx/.csv/.json) — проверка на своём файле; при столбце `label`/`Метка` — метрики |
| POST | `/api/model/retrain` | переобучение (на встроенном датасете или загруженном файле) |
| GET | `/api/model/report.md` | отчёт о валидации |
| GET | `/api/health` | состояние сервиса, БД, модели |
