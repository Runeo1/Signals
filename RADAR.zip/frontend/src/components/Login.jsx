import React, { useState } from 'react'
import { api, token } from '../api.js'

export default function Login({ status, onDone }) {
  const [pw, setPw] = useState('')
  const [pw2, setPw2] = useState('')
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const first = !status.password_set

  const submit = async (e) => {
    e.preventDefault(); setErr('')
    if (first && pw !== pw2) { setErr('Пароли не совпадают'); return }
    setBusy(true)
    try {
      const r = first ? await api.setup(pw) : await api.login(pw)
      token.set(r.token); onDone()
    } catch (e2) { setErr(e2.message) } finally { setBusy(false) }
  }

  return (
    <div className="login">
      <h1>🔐 Справочник слабых сигналов</h1>
      <p>{first ? 'При первом запуске задайте пароль для этой копии справочника.' : 'Введите пароль для входа в справочник.'}</p>
      <form onSubmit={submit}>
        <input type="password" placeholder={first ? 'Новый пароль (минимум 4 символа)' : 'Пароль'} value={pw} onChange={(e) => setPw(e.target.value)} autoFocus />
        {first && <input type="password" placeholder="Повторите пароль" value={pw2} onChange={(e) => setPw2(e.target.value)} />}
        {err && <div className="error">{err}</div>}
        <button disabled={busy || pw.length < 4}>{busy ? <span className="spin" /> : null}Продолжить</button>
      </form>
      {first && <p style={{ fontSize: '.85rem', marginTop: 16 }}>После входа в «⚙️ Настройки пароля» можно сменить пароль и выбрать, запрашивать ли его при входе.</p>}
    </div>
  )
}
