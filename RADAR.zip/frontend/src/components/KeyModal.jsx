import React, { useState } from 'react'
import { api } from '../api.js'

export default function KeyModal({ source, onClose, onSaved }) {
  const [key, setKey] = useState('')
  const [busy, setBusy] = useState(false)
  const [res, setRes] = useState(null)

  const save = async (e) => {
    e.preventDefault(); setBusy(true); setRes(null)
    try { const r = await api.setKey(source.id, key); setRes(r.test); onSaved() } catch (e2) { setRes({ status: 'error', error: e2.message }) } finally { setBusy(false) }
  }
  const remove = async () => { await api.deleteKey(source.id); onSaved(); onClose() }

  return (
    <div className="modal-bg" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <button className="close" onClick={onClose}>×</button>
        <h2>🔑 {source.name}</h2>
        <div className="callout info">
          <b>Справка.</b> {source.access === 'optional' ? 'Источник работает и без ключа, но ключ снимает ограничения по частоте запросов. ' : 'Источник требует API-ключ. '}
          {source.key_hint && <>{source.key_hint} </>}
          {source.key_url && <>Получить ключ: <a href={source.key_url} target="_blank" rel="noreferrer">{source.key_url}</a>.</>}
          <br />Ключ сохраняется на сервере (в БД или переменных окружения .env) и используется только backend.
        </div>
        <form onSubmit={save}>
          <input placeholder={source.id === 'epo' ? 'consumer_key:consumer_secret' : 'Вставьте API-ключ'} value={key} onChange={(e) => setKey(e.target.value)} autoFocus />
          <button disabled={busy || key.trim().length < 4}>{busy && <span className="spin" />}Сохранить и проверить</button>
        </form>
        {res && <p className={res.status === 'ok' ? 'ok' : 'error'}>{res.status === 'ok' ? `Подключено: получено ${res.n} документ(ов) за ${(res.ms / 1000).toFixed(1)} с` : 'Проверка не прошла: ' + (res.error || res.status)}</p>}
        {source.has_key && !source.key_from_env && <button className="red" style={{ marginTop: 10 }} onClick={remove}>Удалить сохранённый ключ</button>}
        {source.key_from_env && <p className="muted">Ключ задан через переменную окружения на сервере.</p>}
      </div>
    </div>
  )
}
