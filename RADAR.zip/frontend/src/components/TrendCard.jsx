import React from 'react'
import { pct } from '../api.js'

const CLS = { 'Слабый': 'weak', 'Средний': 'medium', 'Сильный': 'strong' }

export function Predictors({ list }) {
  if (!list || !list.length) return null
  const max = Math.max(...list.map((p) => Math.abs(p.contribution)), 0.01)
  return (
    <div className="bars">
      {list.map((p) => (
        <div className="bar" key={p.feature} title={p.meaning}>
          <span>{p.title}</span>
          <div className="track"><div className={'fill ' + (p.contribution >= 0 ? 'pos' : 'neg')} style={{ left: 0, width: (100 * Math.abs(p.contribution) / max) + '%' }} /></div>
          <b style={{ color: p.contribution >= 0 ? 'var(--green)' : 'var(--rose)' }}>{p.contribution >= 0 ? '+' : ''}{p.contribution.toFixed(2)}</b>
        </div>
      ))}
    </div>
  )
}

export default function TrendCard({ item, onOpen }) {
  const cls = CLS[item.strength] || 'medium'
  return (
    <article className={'card ' + cls}>
      <h2>{item.name}</h2>
      <div>
        <span className={'pill strength ' + cls}>{item.strength} сигнал</span>
        <span className={'pill prob' + (item.probability < 0.5 ? ' low' : '')}>Вероятность: {pct(item.probability)}</span>
        <span className="pill">Влияние: {item.impact}</span>
      </div>
      {item.name_original && <div className="muted" style={{ fontSize: '.82rem', marginBottom: 6 }}>Оригинальное название: {item.name_original}</div>}
      <p className="desc">{item.description}</p>
      <div className="meta">
        <div><b>Отрасль / запрос</b>{item.industry}</div>
        <div><b>Стадия</b>{item.stage}</div>
        <div><b>Горизонт</b>{item.horizon}</div>
        <div><b>Дата</b>{item.date}</div>
        {item.companies && <div style={{ gridColumn: '1/-1' }}><b>Компании и организации</b>{item.companies}</div>}
        {item.trend && <div style={{ gridColumn: '1/-1' }}><b>Тренд упоминаний</b>{item.trend}</div>}
      </div>
      {item.keywords && item.keywords.length > 0 && <div className="tags">{item.keywords.map((k) => <span className="tag" key={k}>{k}</span>)}</div>}
      <details className="why">
        <summary>Почему это слабый сигнал: предикторы модели</summary>
        <p className="muted" style={{ margin: '8px 0' }}>ML-модель: {pct(item.p_model)} · ТРИЗ-индекс методологии: {pct(item.p_methodology)}</p>
        <Predictors list={item.predictors} />
        {item.triz_evidence && Object.keys(item.triz_evidence).length > 0 && (
          <ul style={{ paddingLeft: 18 }}>{Object.entries(item.triz_evidence).map(([k, v]) => <li key={k}><b>{k}:</b> {v.join(' ')}</li>)}</ul>)}
        {item.exclusion_reasons && item.exclusion_reasons.length > 0 && <p className="error">Факторы против: {item.exclusion_reasons.join(' ')}</p>}
      </details>
      <div className="tags"><span className="pill origin">{item.origin}</span></div>
      {onOpen && <div className="card-actions no-print"><button className="ghost" onClick={onOpen}>Подробнее →</button></div>}
      {item.links && item.links.length > 0 && (
        <div className="source-links">{item.links.map((l, k) => <a className="source-link" key={k} href={l.url} target="_blank" rel="noreferrer">↗ {l.label}</a>)}</div>)}
    </article>
  )
}
