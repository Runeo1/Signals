import React from 'react'

// Прогресс поиска: этап, процент, оставшееся время, журнал ответов источников
export default function ProgressBox({ job, onCancel }) {
  if (!job) return null
  const running = job.status === 'running'
  return (
    <div className="src-group" style={{ margin: '12px 0' }}>
      <div className="progress"><div style={{ width: (job.progress || 0) + '%' }} /></div>
      <div className="progress-row">
        <span><b>{job.stage || 'Инициализация'}</b>{job.query ? <> · «{job.query}»</> : null}</span>
        <span>{job.progress || 0}%{job.eta_sec != null && running ? ` · осталось ≈ ${Math.max(1, Math.round(job.eta_sec))} с` : ''}
          {running && onCancel && <button className="link" style={{ marginLeft: 12, color: 'var(--rose)' }} onClick={onCancel}>■ Остановить</button>}</span>
      </div>
      {job.status === 'error' && <p className="error">Ошибка: {job.error}</p>}
      {job.status === 'cancelled' && <p className="error">Поиск остановлен оператором.</p>}
      {job.status === 'done' && <p className="ok">Готово: {job.result ? `${job.result.stats.top} инсайтов, ${job.result.stats.confident_75} с уверенностью >75%` : ''}</p>}
      <div className="log">{(job.log || []).join('\n') || 'Инициализация…'}</div>
    </div>)
}
