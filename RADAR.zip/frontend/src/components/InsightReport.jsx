import React from 'react'
import { pct } from '../api.js'
import { Predictors } from './TrendCard.jsx'

const autoMark = (m) => m && /автомат|генератив|перевод/i.test(m) && !/оригинал/i.test(m)

export default function InsightReport({ item }) {
  const c = item.case || {}
  return (
    <article className="report">
      <h3><span className="num">{item.rank}</span>{item.name}</h3>
      <p className="orig">Оригинальное название: <b>{item.name_original}</b>{autoMark(item.name_translation_method) && <span className="mark">название переведено автоматически</span>}</p>
      <div>
        <span className={'pill strength ' + ({ 'Слабый': 'weak', 'Средний': 'medium', 'Сильный': 'strong' }[item.strength] || 'medium')}>{item.strength} сигнал</span>
        <span className={'pill prob' + (item.probability < 0.5 ? ' low' : '')}>Скоринг слабого сигнала: {pct(item.probability)}</span>
        <span className="pill">Стадия: {item.stage}</span>
        <span className="pill">Горизонт: {item.horizon}</span>
        <span className="pill">Влияние: {item.impact}</span>
      </div>

      <h4>Краткое описание</h4>
      <p>{item.description}{autoMark(item.description_method) && <span className="mark">{item.description_method}</span>}</p>

      <h4>Ключевое преимущество</h4>
      <p>{item.advantage}</p>

      <h4>Кейс-пример</h4>
      <p><b>{c.kind}:</b> {c.title_ru || c.title}{c.title_ru && c.title_ru !== c.title && <span className="mark">перевод автоматический</span>}
        {c.org ? <> — {c.org}</> : null}{c.date ? <> ({c.date})</> : null}{c.url && <> · <a href={c.url} target="_blank" rel="noreferrer">первоисточник ↗</a></>}</p>
      {c.title_ru && c.title_ru !== c.title && <p className="muted" style={{ fontSize: '.84rem' }}>Оригинал: {c.title}</p>}

      <h4>Аналитика</h4>
      <p>{item.trend}</p>
      {item.analytics && item.analytics.length > 0 && (
        <table className="tbl"><tbody>{item.analytics.map((a, k) => (
          <tr key={k}><td>{a.label}</td><td><b>{a.value == null ? "Нет данных" : String(a.value)}</b>{a.url && <> · <a href={a.url} target="_blank" rel="noreferrer">проверить ↗</a></>}</td></tr>))}</tbody></table>)}

      {item.quality && <><h4>Доказательства ранней стадии</h4>
        {(item.quality.early_evidence || []).map((e,k) => <p key={k}><a href={e.url} target="_blank" rel="noreferrer">Первоисточник</a>: {e.text} <small>(цитата в оригинале, резюме на русском ниже)</small></p>)}
        <p className="muted">Проверка рыночной зрелости выполнена по доступным текстам. Отсутствие признаков зрелости в выборке не доказывает отсутствие рынка.</p></>}
      {item.evidence_coverage && <p className="muted">Покрытие: {Object.entries(item.evidence_coverage).map(([k,v]) => (({publications:'публикации',patents:'патенты',fiction:'фантастика',news:'СМИ'})[k] || k) + ' — ' + (({ok:'доступно',timeout:'тайм-аут',unavailable:'недоступно',not_requested:'не запрашивалось',unavailable_or_not_requested:'нет данных'})[v] || v)).join('; ')}</p>}
      <h4>Статус и объяснение</h4>
      <div className={'status' + (item.is_weak_signal ? '' : ' no')}>{item.is_weak_signal ? '✅ Слабый сигнал. ' : '⚠️ Сигнал ниже порога. '}{item.status_explanation}</div>
      {item.predictors && item.predictors.length > 0 && <><h4>Вклад предикторов (логистическая регрессия)</h4><Predictors list={item.predictors.slice(0, 7)} /></>}
      {item.triz_evidence && Object.keys(item.triz_evidence).length > 0 && (
        <><h4>Признаки по ТРИЗ-методологии</h4><ul>{Object.entries(item.triz_evidence).map(([k, v]) => <li key={k}><b>{k}:</b> {v.join(' ')}</li>)}</ul></>)}

      <h4>Источники ({item.sources.length})</h4>
      <div className="tbl-wrap" style={{ maxHeight: 'none' }}>
        <table className="tbl src-table"><thead><tr><th>Источник</th><th>Дата</th><th>Тип</th><th>Язык</th><th>Доверие</th><th>Резюме на русском</th></tr></thead><tbody>
          {item.sources.map((s, k) => (
            <tr key={k}>
              <td><a href={s.url} target="_blank" rel="noreferrer">{s.name}</a>{s.name_ru && <><br /><small className="muted">{s.name_ru}</small></>}<br /><small className="muted">{s.source}</small></td>
              <td>{s.date}</td><td>{s.type}</td><td>{s.language}</td><td>{s.trust}</td>
              <td>{s.summary_ru}{autoMark(s.summary_method) && <span className="mark">{s.summary_method}</span>}</td>
            </tr>))}
        </tbody></table>
      </div>
    </article>
  )
}
