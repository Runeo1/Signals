import React, { useEffect, useMemo, useState } from 'react'
import { api, pct } from '../api.js'
import { CATALOG_COLUMNS, downloadCsv, downloadJson } from '../utils/export.js'
import TrendCard from './TrendCard.jsx'
import Analytics from './Analytics.jsx'
import DetailModal from './DetailModal.jsx'

const EMPTY = { industry: '', strength: '', impact: '', origin: '', q: '', confident: false }
const SORTS = {
  prob: ['По вероятности (убыв.)', (a, b) => (b.probability || 0) - (a.probability || 0)],
  name: ['По названию (А–Я)', (a, b) => a.name.localeCompare(b.name, 'ru')],
  date: ['Сначала новые', (a, b) => String(b.date).localeCompare(String(a.date))],
  industry: ['По отрасли', (a, b) => String(a.industry).localeCompare(String(b.industry), 'ru')],
  horizon: ['По горизонту (ближе → дальше)', (a, b) => String(a.horizon).localeCompare(String(b.horizon), 'ru')],
}
const PAGE = 30

export default function Catalog({ version }) {
  const [items, setItems] = useState([])
  const [err, setErr] = useState('')
  const [draft, setDraft] = useState(EMPTY)
  const [applied, setApplied] = useState(EMPTY)
  const [loading, setLoading] = useState(true)
  const [sort, setSort] = useState('prob')
  const [view, setView] = useState('cards')
  const [showAnalytics, setShowAnalytics] = useState(false)
  const [limit, setLimit] = useState(PAGE)
  const [detail, setDetail] = useState(null)
  const [updated, setUpdated] = useState(null)

  const load = () => {
    setLoading(true)
    api.catalog().then((d) => { setItems(d); setErr(''); setUpdated(new Date()) }).catch((e) => setErr(e.message)).finally(() => setLoading(false))
  }
  useEffect(load, [version])

  const industries = useMemo(() => Array.from(new Set(items.map((i) => i.industry).filter(Boolean))).sort((a, b) => a.localeCompare(b, 'ru')), [items])
  const shown = useMemo(() => {
    const q = applied.q.trim().toLowerCase()
    return items.filter((i) => (!applied.industry || i.industry === applied.industry)
      && (!applied.strength || i.strength === applied.strength)
      && (!applied.impact || i.impact === applied.impact)
      && (!applied.origin || (applied.origin === 'dataset' ? !i.run_id : !!i.run_id))
      && (!applied.confident || i.confident)
      && (!q || [i.name, i.name_original, i.description, i.companies, i.stage, i.trend, (i.keywords || []).join(' ')].join(' ').toLowerCase().includes(q)))
      .sort(SORTS[sort][1])
  }, [items, applied, sort])
  useEffect(() => setLimit(PAGE), [applied, sort])

  const set = (k) => (e) => setDraft({ ...draft, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value })
  const apply = () => setApplied(draft)
  const reset = () => { setDraft(EMPTY); setApplied(EMPTY) }
  const n = (s) => shown.filter((i) => i.strength === s).length
  const stamp = new Date().toISOString().slice(0, 10)

  return (
    <>
      <div className="controls">
        <div className="filters">
          <div className="field"><label>🏭 Отрасль</label>
            <select value={draft.industry} onChange={set('industry')}><option value="">Все отрасли</option>{industries.map((x) => <option key={x}>{x}</option>)}</select></div>
          <div className="field"><label>📊 Сила сигнала</label>
            <select value={draft.strength} onChange={set('strength')}><option value="">Все уровни</option><option>Слабый</option><option>Средний</option><option>Сильный</option></select></div>
          <div className="field"><label>💡 Потенциальное влияние</label>
            <select value={draft.impact} onChange={set('impact')}><option value="">Все уровни</option><option>Средний</option><option>Высокий</option><option>Очень высокий</option></select></div>
        </div>
        <div className="row" style={{ marginTop: 14, gap: 18 }}>
          <label className="check"><span className="muted">Происхождение:</span>
            <select value={draft.origin} onChange={set('origin')} style={{ width: 'auto', padding: '7px 10px' }}>
              <option value="">Все</option><option value="dataset">Датасет (эталон)</option><option value="search">Открытый поиск</option></select></label>
          <label className="check"><input type="checkbox" checked={draft.confident} onChange={set('confident')} /> Только с уверенностью &gt;75%</label>
        </div>
        <div className="actions">
          <input placeholder="🔍 Поиск по названию, описанию или ключевым словам..." value={draft.q} onChange={set('q')} onKeyDown={(e) => e.key === 'Enter' && apply()} />
          <button onClick={apply}>Применить фильтры</button>
          <button className="gray" onClick={reset}>Сбросить</button>
          <button className="orange" onClick={() => window.print()}>📄 Экспорт в PDF</button>
        </div>
      </div>
      <div className="stats">
        <div className="stat"><strong>{items.length}</strong><span>Всего трендов</span></div>
        <div className="stat"><strong>{shown.length}</strong><span>Показано</span></div>
        <div className="stat"><strong>{n('Слабый')}</strong><span>Слабых сигналов</span></div>
        <div className="stat"><strong>{n('Сильный')}</strong><span>Сильных сигналов</span></div>
        <div className="stat"><strong>{shown.filter((i) => i.confident).length}</strong><span>С уверенностью &gt;75%</span></div>
        <div className="stat"><strong style={{ fontSize: '1.15em' }}>{updated ? updated.toLocaleString('ru-RU', { dateStyle: 'short', timeStyle: 'short' }) : '—'}</strong><span>Последнее обновление</span></div>
      </div>
      <div className="toolbar no-print">
        <div className="view-toggle">
          <select value={sort} onChange={(e) => setSort(e.target.value)}>{Object.entries(SORTS).map(([k, v]) => <option key={k} value={k}>{v[0]}</option>)}</select>
          <button className={view === 'cards' ? '' : 'ghost'} onClick={() => setView('cards')}>▦ Карточки</button>
          <button className={view === 'table' ? '' : 'ghost'} onClick={() => setView('table')}>☰ Таблица</button>
          <button className={showAnalytics ? 'teal' : 'ghost'} onClick={() => setShowAnalytics(!showAnalytics)}>📈 Аналитика</button>
        </div>
        <div className="view-toggle">
          <button className="ghost" onClick={() => downloadCsv('spravochnik-' + stamp + '.csv', CATALOG_COLUMNS, shown)}>⬇ Excel (CSV)</button>
          <button className="ghost" onClick={() => downloadJson('spravochnik-' + stamp + '.json', shown.map(({ full, ...x }) => x))}>⬇ JSON</button>
          <button className="ghost" onClick={load}>↻ Обновить</button>
        </div>
      </div>
      {showAnalytics && <Analytics items={shown} />}
      {err && <div className="section error">{err}</div>}
      {view === 'cards' ? (
        <div className="grid">
          {loading && <div className="empty">Загрузка справочника…</div>}
          {!loading && shown.length === 0 && <div className="empty">По заданным фильтрам ничего не найдено.</div>}
          {shown.slice(0, limit).map((i) => <TrendCard key={i.id} item={i} onOpen={() => setDetail(i)} />)}
        </div>
      ) : (
        <div className="section">
          <div className="tbl-wrap" style={{ maxHeight: 640 }}>
            <table className="tbl"><thead><tr><th>Технология</th><th>Отрасль</th><th>Сила</th><th>Влияние</th><th>Вероятность</th><th>Стадия</th><th>Горизонт</th><th>Источники</th></tr></thead><tbody>
              {shown.slice(0, limit).map((i) => (
                <tr key={i.id} style={{ cursor: 'pointer' }} onClick={() => setDetail(i)}>
                  <td><b>{i.name}</b>{i.name_original && <><br /><small className="muted">{i.name_original}</small></>}</td>
                  <td>{i.industry}</td><td>{i.strength}</td><td>{i.impact}</td><td>{pct(i.probability)}</td><td>{i.stage}</td><td>{i.horizon}</td><td>{(i.links || []).length}</td>
                </tr>))}
            </tbody></table>
          </div>
        </div>)}
      {shown.length > limit && <div className="more no-print"><button className="ghost" onClick={() => setLimit(limit + PAGE)}>Показать ещё ({shown.length - limit})</button></div>}
      {detail && <DetailModal item={detail} onClose={() => setDetail(null)} />}
    </>
  )
}
