import React, { useEffect, useState } from 'react'
import { api } from '../api.js'

const PROVIDERS = [
  ['', 'Не использовать (перевод: Google/MyMemory/глоссарий)'],
  ['yandexgpt', 'YandexGPT (Yandex Cloud)'],
  ['gigachat', 'GigaChat (Сбер)'],
  ['openai', 'OpenAI (официальный API)'],
]

export default function LlmSettings() {
  const [info, setInfo] = useState(null)
  const [cfg, setCfg] = useState({ provider: '', model: '', api_key: '', folder_id: '', base_url: '' })
  const [msg, setMsg] = useState(null)
  const [open, setOpen] = useState(false)

  useEffect(() => { api.llm().then((d) => { setInfo(d); setCfg((c) => ({ ...c, provider: d.provider || '', model: d.model_name || '' })) }).catch(() => {}) }, [])
  const set = (k) => (e) => setCfg({ ...cfg, [k]: e.target.value })
  const save = async (e) => {
    e.preventDefault(); setMsg(null)
    try { const r = await api.setLlm(cfg); setMsg({ ok: r.available ? 'LLM подключена: ' + r.model : 'Сохранено. LLM отключена.' }) } catch (e2) { setMsg({ err: e2.message }) }
  }
  if (!info) return null
  return (
    <div className="src-group" style={{ marginTop: 14 }}>
      <h4>🤖 Генеративная модель (опционально) <button className="link" onClick={() => setOpen(!open)}>{open ? 'Скрыть' : 'Настроить'}</button></h4>
      <small className="muted">Сейчас: {info.available ? info.model : 'не используется'}. LLM применяется только для перевода и русскоязычных резюме; отбор слабых сигналов выполняет ML-модель и методология. Разрешённые ТЗ модели: {info.allowed_models.join(', ')}.</small>
      {open && (
        <form className="form" onSubmit={save} style={{ marginTop: 10 }}>
          <select value={cfg.provider} onChange={e => setCfg({...cfg, provider:e.target.value, model:'', base_url:''})}>{PROVIDERS.map(([v, t]) => <option key={v} value={v}>{t}</option>)}</select>
          {cfg.provider && <select value={cfg.model} onChange={set('model')}><option value="">— модель —</option>{info.allowed_models.map((m) => <option key={m}>{m}</option>)}</select>}
          {cfg.provider && <input type="password" autoComplete="new-password" placeholder="API-ключ" value={cfg.api_key} onChange={set('api_key')} />}
          {cfg.provider === 'yandexgpt' && <input placeholder="Folder ID (Yandex Cloud)" value={cfg.folder_id} onChange={set('folder_id')} />}
          {cfg.provider === 'openai' && <input placeholder="Base URL (например https://api.openai.com/v1)" value={cfg.base_url} onChange={set('base_url')} />}
          {msg && <div className={msg.ok ? 'ok' : 'error'}>{msg.ok || msg.err}</div>}
          <small>Ключ действует до перезапуска сервера. Для постоянной настройки используйте переменные окружения.</small>
          <button>Сохранить</button>
        </form>)}
    </div>
  )
}
