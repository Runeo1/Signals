import React, { useState } from 'react'
import { api } from '../api.js'

export default function PasswordModal({ status, onClose, onChanged }) {
  const [cur, setCur] = useState('')
  const [n1, setN1] = useState('')
  const [n2, setN2] = useState('')
  const [msg, setMsg] = useState(null)
  const [req, setReq] = useState(status.require_password)
  const [cur2, setCur2] = useState('')
  const [msg2, setMsg2] = useState(null)

  const change = async (e) => {
    e.preventDefault(); setMsg(null)
    if (n1 !== n2) { setMsg({ err: 'Новые пароли не совпадают' }); return }
    try { await api.changePassword(cur, n1); setMsg({ ok: 'Пароль изменён' }); setCur(''); setN1(''); setN2('') } catch (e2) { setMsg({ err: e2.message }) }
  }
  const saveReq = async (e) => {
    e.preventDefault(); setMsg2(null)
    try { await api.setRequire(req, cur2); setMsg2({ ok: req ? 'Пароль будет запрашиваться при входе' : 'Вход без пароля включён' }); setCur2(''); onChanged() } catch (e2) { setMsg2({ err: e2.message }) }
  }

  return (
    <div className="modal-bg" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <button className="close" onClick={onClose}>×</button>
        <h2>⚙️ Настройки пароля</h2>
        <p className="muted">Пароль хранится на сервере в виде bcrypt-хеша (в браузере не сохраняется).</p>
        <form onSubmit={change}>
          <input type="password" placeholder="Текущий пароль" value={cur} onChange={(e) => setCur(e.target.value)} />
          <input type="password" placeholder="Новый пароль (минимум 4 символа)" value={n1} onChange={(e) => setN1(e.target.value)} />
          <input type="password" placeholder="Повторите новый пароль" value={n2} onChange={(e) => setN2(e.target.value)} />
          {msg && <div className={msg.ok ? 'ok' : 'error'}>{msg.ok || msg.err}</div>}
          <button className="green" disabled={!cur || n1.length < 4}>💾 Сохранить новый пароль</button>
        </form>
        <hr />
        <h3 style={{ margin: '0 0 10px' }}>🔑 Запрос пароля при входе</h3>
        <form onSubmit={saveReq}>
          <div className="switch">
            <div><b>Запрашивать пароль при входе</b><br /><small className="muted">Если выключено — справочник открывается сразу, без ввода пароля.</small></div>
            <label className="check"><input type="checkbox" checked={req} onChange={(e) => setReq(e.target.checked)} /> {req ? 'Да' : 'Нет'}</label>
          </div>
          <input type="password" placeholder="Текущий пароль для подтверждения" value={cur2} onChange={(e) => setCur2(e.target.value)} />
          {msg2 && <div className={msg2.ok ? 'ok' : 'error'}>{msg2.ok || msg2.err}</div>}
          <button disabled={!cur2}>Применить</button>
        </form>
      </div>
    </div>
  )
}
