import React, { useEffect, useState } from 'react'
import { api } from '../api.js'

// Строка состояния: backend, БД, модель, LLM — обновляется каждые 60 с
export default function SystemStatus() {
  const [h, setH] = useState(null)
  const [err, setErr] = useState(false)
  useEffect(() => {
    let t
    const tick = () => api.health().then((x) => { setH(x); setErr(false) }).catch(() => setErr(true)).finally(() => { t = setTimeout(tick, 60000) })
    tick()
    return () => clearTimeout(t)
  }, [])
  if (err) return <div className="status-line"><span><span className="dot error" /> Backend недоступен</span></div>
  if (!h) return null
  return (
    <div className="status-line">
      <span><span className="dot ok" /> Backend v{h.version}</span>
      <span><span className={'dot ' + (h.database_ok ? 'ok' : 'error')} /> БД: {h.database}</span>
      <span><span className="dot ok" /> Модель: CV-точность {Math.round(h.model.cv_accuracy * 1000) / 10}% (n={h.model.n_train})</span>
      <span><span className={'dot ' + (h.llm ? 'ok' : 'idle')} /> LLM: {h.llm || 'не подключена (шаблонные тексты)'}</span>
    </div>)
}
