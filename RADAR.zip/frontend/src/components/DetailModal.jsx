import React from 'react'
import { pct } from '../api.js'
import InsightReport from './InsightReport.jsx'
import { Predictors } from './TrendCard.jsx'

// Полная карточка технологии: для результатов поиска — отчёт инсайта, для датасета — все сведения и объяснение модели
export default function DetailModal({ item, onClose }) {
  return (
    <div className="modal-bg" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal wide">
        <button className="close" onClick={onClose}>×</button>
        {item.full ? <InsightReport item={item.full} /> : (
          <div className="report" style={{ boxShadow: 'none', border: 0, padding: 0 }}>
            <h3>{item.name}</h3>
            <p className="muted">{item.origin} · отрасль: {item.industry}</p>
            <div>
              <span className="pill">{item.strength} сигнал</span>
              <span className="pill prob">Вероятность: {pct(item.probability)}</span>
              <span className="pill">ML-модель: {pct(item.p_model)}</span>
              <span className="pill">ТРИЗ-индекс: {pct(item.p_methodology)}</span>
              <span className="pill">Влияние: {item.impact}</span>
              <span className="pill">Горизонт: {item.horizon}</span>
            </div>
            <h4>Почему это слабый сигнал (описание из датасета)</h4><p>{item.description}</p>
            <h4>Стадия развития</h4><p>{item.stage}</p>
            <h4>Тренд упоминаний</h4><p>{item.trend}</p>
            {item.companies && <><h4>Компании и организации</h4><p>{item.companies}</p></>}
            <h4>Вклад предикторов модели</h4><Predictors list={item.predictors} />
            {item.triz_evidence && Object.keys(item.triz_evidence).length > 0 && (
              <><h4>Признаки по ТРИЗ-методологии</h4><ul>{Object.entries(item.triz_evidence).map(([k, v]) => <li key={k}><b>{k}:</b> {v.join(' ')}</li>)}</ul></>)}
            {item.exclusion_reasons && item.exclusion_reasons.length > 0 && <><h4>Факторы против</h4><p className="error">{item.exclusion_reasons.join(' ')}</p></>}
            <h4>Первоисточники ({(item.links || []).length})</h4>
            <div className="source-links" style={{ borderTop: 0, paddingTop: 0 }}>{(item.links || []).map((l, k) => <a className="source-link" key={k} href={l.url} target="_blank" rel="noreferrer">↗ {l.label}</a>)}</div>
          </div>)}
        <div className="row no-print" style={{ marginTop: 14 }}><button className="orange" onClick={() => window.print()}>📄 Печать / PDF</button><button className="gray" onClick={onClose}>Закрыть</button></div>
      </div>
    </div>)
}
