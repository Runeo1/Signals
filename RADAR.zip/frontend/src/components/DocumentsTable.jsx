import React, { useEffect, useMemo, useState } from 'react'
import { api } from '../api.js'
import { downloadCsv } from '../utils/export.js'

// Сырые документы запуска из PostgreSQL (слой ETL)
export default function DocumentsTable({ runId }) {
  const [docs, setDocs] = useState(null)
  const [err, setErr] = useState('')
  const [src, setSrc] = useState('')
  const [q, setQ] = useState('')
  useEffect(() => { api.runDocuments(runId).then(setDocs).catch((e) => setErr(e.message)) }, [runId])
  const sources = useMemo(() => Array.from(new Set((docs || []).map((d) => d.source_id))).sort(), [docs])
  const shown = useMemo(() => (docs || []).filter((d) => (!src || d.source_id === src) && (!q || (d.title || '').toLowerCase().includes(q.toLowerCase()))), [docs, src, q])
  if (err) return <p className="error">{err}</p>
  if (!docs) return <p>Загрузка документов…</p>
  return (
    <div>
      <div className="row" style={{ marginBottom: 10 }}>
        <select value={src} onChange={(e) => setSrc(e.target.value)} style={{ width: 'auto' }}><option value="">Все источники ({docs.length})</option>{sources.map((s) => <option key={s} value={s}>{s} ({docs.filter((d) => d.source_id === s).length})</option>)}</select>
        <input placeholder="Фильтр по заголовку" value={q} onChange={(e) => setQ(e.target.value)} style={{ maxWidth: 320 }} />
        <button className="ghost" onClick={() => downloadCsv('documents-' + runId + '.csv', [['source_id', 'Источник'], ['type', 'Тип'], ['title', 'Заголовок'], ['url', 'Ссылка'], ['date', 'Дата'], ['language', 'Язык'], ['trust', 'Доверие']], shown)}>⬇ CSV</button>
        <span className="muted">Показано: {shown.length}</span>
      </div>
      <div className="tbl-wrap" style={{ maxHeight: 600 }}><table className="tbl"><thead><tr><th>Источник</th><th>Тип</th><th>Заголовок</th><th>Дата</th><th>Язык</th><th>Доверие</th></tr></thead><tbody>
        {shown.map((d, k) => <tr key={k}><td>{d.source_id}</td><td>{d.type}</td><td><a href={d.url} target="_blank" rel="noreferrer">{d.title}</a></td><td>{d.date}</td><td>{d.language}</td><td>{d.trust}</td></tr>)}
      </tbody></table></div>
    </div>)
}
