import React, { useEffect, useMemo, useState } from 'react'
import { api, pct } from '../api.js'
import { Predictors } from './TrendCard.jsx'

const P = (m) => (m == null ? '—' : typeof m === 'object' ? pct(m.mean) + ' ± ' + (100 * m.std).toFixed(1) : pct(m))

function CM({ m, title }) {
  if (!m || !m.confusion_matrix) return null
  const [[tn, fp], [fn, tp]] = m.confusion_matrix
  return (
    <div><b>{title}</b>
      <div className="cm" style={{ marginTop: 8 }}>
        <div /><div><small>Прогноз: фон</small></div><div><small>Прогноз: сигнал</small></div>
        <div><small>Факт: фон</small></div><div className="tn">{tn}</div><div className="fp">{fp}</div>
        <div><small>Факт: сигнал</small></div><div className="fn">{fn}</div><div className="tp">{tp}</div>
      </div>
    </div>)
}

export default function Validation() {
  const [info, setInfo] = useState(null)
  const [preds, setPreds] = useState([])
  const [filter, setFilter] = useState('errors')
  const [err, setErr] = useState('')
  const [upload, setUpload] = useState(null)
  const [busy, setBusy] = useState(false)
  const [manual, setManual] = useState({ name: '', why: '', stage: '', trend: '', mode: 'hybrid' })
  const [manualRes, setManualRes] = useState(null)
  const [retrain, setRetrain] = useState(null)

  const load = () => {
    api.modelInfo().then(setInfo).catch((e) => setErr(e.message))
    api.predictions().then(setPreds).catch(() => {})
  }
  useEffect(load, [])

  const rows = useMemo(() => preds.filter((p) => filter === 'all' || (filter === 'errors' ? p.correct === '0' : filter === 'dataset' ? p.origin === 'датасет' : p.origin !== 'датасет')), [preds, filter])

  const doUpload = async (e) => {
    const f = e.target.files[0]; if (!f) return
    setBusy(true); setUpload(null)
    try { setUpload(await api.validate(f)) } catch (e2) { setUpload({ error: e2.message }) } finally { setBusy(false); e.target.value = '' }
  }
  const doManual = async (e) => { e.preventDefault(); setManualRes(await api.score(manual)) }
  const doRetrain = async () => { setRetrain({ busy: true }); try { setRetrain(await api.retrain()); load() } catch (e) { setRetrain({ error: e.message }) } }

  if (err) return <div className="section error">{err}</div>
  if (!info) return <div className="section">Загрузка метрик…</div>
  const r = info.report || {}
  const cv = r.main_model_repeated_cv || {}
  const st = r.stress_test_hard_background || {}
  const setM = (k) => (e) => setManual({ ...manual, [k]: e.target.value })

  return (
    <div className="section">
      <h2>🧪 Проверка методологии на датасете</h2>
      <p className="lead">Доказательная часть: насколько авторская ТРИЗ-методология и обученная на ней модель отличают <b>зарождающиеся тренды</b> (100 слабых сигналов из датасета) от <b>хайпового фона</b> (132 контрольных примера: зрелые технологии, хайп, шум, в том числе 36 «трудных» примеров в стиле датасета). Целевой порог ТЗ — не ниже 75–80%.</p>
      <div className={'callout ' + (r.target_met ? 'good' : '')}>
        {r.target_met ? '✅ Целевой порог 75–80% достигнут. ' : '⚠️ Целевой порог не достигнут. '}
        Повторная кросс-валидация 10×5: точность <b>{P(cv.accuracy)}</b>, F1 <b>{P(cv.f1)}</b>. Без обучения, только по формуле методологии (ТРИЗ-индекс): точность <b>{P(r.methodology_index_no_training?.accuracy)}</b>. Жёсткий стресс-тест на невиданных «трудных» примерах фона: точность <b>{P(st.accuracy)}</b>, полнота <b>{P(st.recall)}</b>.
      </div>
      <div className="kpis">
        <div className="kpi accent"><strong>{P(cv.accuracy?.mean)}</strong><span>Точность (CV 10×5)</span></div>
        <div className="kpi"><strong>{P(cv.f1?.mean)}</strong><span>F1-мера</span></div>
        <div className="kpi"><strong>{P(cv.roc_auc?.mean)}</strong><span>ROC-AUC</span></div>
        <div className="kpi"><strong>{P(r.leave_one_area_out?.overall?.accuracy)}</strong><span>Перенос на новую отрасль</span></div>
        <div className="kpi"><strong>{P(r.methodology_index_no_training?.accuracy)}</strong><span>ТРИЗ-индекс без обучения</span></div>
        <div className="kpi"><strong>{P(st.accuracy)}</strong><span>Стресс-тест (трудный фон)</span></div>
      </div>

      <div className="two">
        <div className="src-group">
          <h4>Сравнение подходов</h4>
          <table className="tbl"><thead><tr><th>Метод</th><th>Точность</th><th>F1</th></tr></thead><tbody>
            <tr><td><b>Модель по методологии (логистическая регрессия)</b></td><td>{P(cv.accuracy)}</td><td>{P(cv.f1)}</td></tr>
            <tr><td>ТРИЗ-индекс без обучения (фиксированные веса)</td><td>{P(r.methodology_index_no_training?.accuracy)}</td><td>{P(r.methodology_index_no_training?.f1)}</td></tr>
            <tr><td>Только признаки ТРИЗ (абляция)</td><td>{P(r.ablation_triz_only?.accuracy)}</td><td>{P(r.ablation_triz_only?.f1)}</td></tr>
            <tr><td>Random Forest (контроль)</td><td>{P(r.baseline_random_forest?.accuracy)}</td><td>{P(r.baseline_random_forest?.f1)}</td></tr>
            <tr><td>TF-IDF по тексту (контроль)</td><td>{P(r.baseline_tfidf_text?.accuracy)}</td><td>{P(r.baseline_tfidf_text?.f1)}</td></tr>
            <tr><td>Только стадия развития (наивный)</td><td>{P(r.baseline_stage_only?.accuracy)}</td><td>{P(r.baseline_stage_only?.f1)}</td></tr>
          </tbody></table>
        </div>
        <div className="src-group">
          <h4>Матрицы ошибок</h4>
          <div className="two"><CM m={r.main_model_oof} title="Out-of-fold (232 примера)" /><CM m={st} title="Стресс-тест" /></div>
        </div>
      </div>

      <div className="callout info"><b>Честные оговорки.</b> Датасет содержит только положительные примеры (слабые сигналы), поэтому контрольный «фон» подготовлен командой по описанию хайпового фона из ТЗ и методологии — на нём высокие метрики частично объясняются различием стилей описаний. Поэтому дополнительно приведены: перенос на невиданную отрасль, ТРИЗ-индекс без обучения и стресс-тест на «трудных» примерах, написанных в стиле датасета ({P(st.precision)} precision — модель склонна принимать зрелые технологии с «ранней» риторикой за сигналы). Загрузите собственный размеченный файл ниже, чтобы проверить методологию независимо.</div>

      <div className="src-group" style={{ marginTop: 16 }}>
        <h4>Коэффициенты модели (вклад признаков методологии)</h4>
        <Predictors list={(info.coefficients || []).map((c) => ({ feature: c.feature, title: c.title, contribution: c.coef, meaning: (info.features.find((f) => f.name === c.feature) || {}).meaning }))} />
      </div>

      <div className="src-group" style={{ marginTop: 16 }}>
        <h4>Предсказания по каждой строке (out-of-fold)
          <select value={filter} onChange={(e) => setFilter(e.target.value)} style={{ width: 'auto', padding: '6px 10px' }}>
            <option value="errors">Только ошибки</option><option value="dataset">Датасет (100)</option><option value="bg">Контрольный фон (132)</option><option value="all">Все (232)</option>
          </select></h4>
        <div className="tbl-wrap"><table className="tbl"><thead><tr><th>№</th><th>Технология</th><th>Область</th><th>Факт</th><th>Вероятность</th><th>ТРИЗ-индекс</th><th>Верно</th><th>Главные предикторы</th></tr></thead><tbody>
          {rows.map((p, k) => <tr key={k}><td>{p.row}</td><td>{p.name}{p.bg_type && <><br /><small className="muted">{p.bg_type}</small></>}</td><td>{p.area}</td><td>{p.true_label === '1' ? 'сигнал' : 'фон'}</td><td>{pct(+p.p_oof)}</td><td>{pct(+p.p_methodology)}</td><td>{p.correct === '1' ? '✅' : '❌'}</td><td><small>{p.top_predictors}</small></td></tr>)}
        </tbody></table></div>
      </div>

      <div className="two" style={{ marginTop: 16 }}>
        <div className="src-group">
          <h4>📤 Проверить свой датасет</h4>
          <p className="muted">Excel/CSV со столбцами «Технология», «Почему это слабый сигнал», «Стадия развития», «Тренд упоминаний» (как в датасете). Если есть столбец «label»/«Метка» (1 — слабый сигнал, 0 — фон), будут рассчитаны Accuracy, Precision, Recall, F1.</p>
          <input type="file" accept=".xlsx,.xls,.csv,.json" onChange={doUpload} disabled={busy} />
          {busy && <p>Обработка…</p>}
          {upload && upload.error && <p className="error">{upload.error}</p>}
          {upload && !upload.error && (
            <>
              <p><b>Строк:</b> {upload.n_rows} · <b>распознано слабых сигналов:</b> {upload.n_predicted_weak} · <b>с уверенностью &gt;75%:</b> {upload.n_confident}</p>
              {upload.metrics ? <p className="ok">Accuracy {pct(upload.metrics.accuracy)} · Precision {pct(upload.metrics.precision)} · Recall {pct(upload.metrics.recall)} · F1 {pct(upload.metrics.f1)}</p> : <p className="muted">{upload.note}</p>}
              <div className="tbl-wrap"><table className="tbl"><thead><tr><th>№</th><th>Технология</th><th>Метка</th><th>Вероятность</th><th>Вывод</th></tr></thead><tbody>
                {upload.rows.map((o) => <tr key={o.row}><td>{o.row}</td><td>{o.name}</td><td>{o.label == null ? '—' : o.label}</td><td>{pct(o.probability)}</td><td>{o.is_weak_signal ? 'слабый сигнал' : 'фон'}</td></tr>)}
              </tbody></table></div>
            </>)}
        </div>
        <div className="src-group">
          <h4>✍️ Проверить одну технологию</h4>
          <form className="form" onSubmit={doManual}>
            <input placeholder="Технология" value={manual.name} onChange={setM('name')} />
            <textarea placeholder="Почему это может быть слабым сигналом (описание, факты)" value={manual.why} onChange={setM('why')} />
            <input placeholder="Стадия развития (например: Прототип/PoC)" value={manual.stage} onChange={setM('stage')} />
            <input placeholder="Тренд упоминаний (например: Растёт быстро)" value={manual.trend} onChange={setM('trend')} />
            <button disabled={!manual.name}>Оценить</button>
          </form>
          {manualRes && <>
            <p className={manualRes.is_weak_signal ? 'ok' : 'error'}>{manualRes.is_weak_signal ? 'Слабый сигнал' : 'Не слабый сигнал'}: {pct(manualRes.probability)} (модель {pct(manualRes.p_model)}, ТРИЗ-индекс {pct(manualRes.p_methodology)})</p>
            <Predictors list={manualRes.predictors.slice(0, 6)} />
            {manualRes.exclusion_reasons.length > 0 && <p className="error">{manualRes.exclusion_reasons.join(' ')}</p>}
          </>}
        </div>
      </div>
      <div className="row" style={{ marginTop: 16 }}>
        <button className="purple" onClick={doRetrain} disabled={retrain && retrain.busy}>{retrain && retrain.busy && <span className="spin" />}🔁 Переобучить модель на датасете</button>
        <a href={api.apiBase() + '/api/model/report.md'} target="_blank" rel="noreferrer">⬇ Отчёт о валидации (Markdown)</a>
        {retrain && retrain.accuracy && <span className="ok">Переобучено: точность {P(retrain.accuracy.accuracy)}</span>}
        {retrain && retrain.error && <span className="error">{retrain.error}</span>}
        <span className="muted">Обучено: {info.meta.trained_at} · {info.meta.algorithm}</span>
      </div>
    </div>
  )
}
