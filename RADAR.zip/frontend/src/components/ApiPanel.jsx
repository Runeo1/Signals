import React, { useEffect, useState } from 'react'
import { api } from '../api.js'
import KeyModal from './KeyModal.jsx'
import LlmSettings from './LlmSettings.jsx'
import ProgressBox from './ProgressBox.jsx'
import { useSearchJob } from '../utils/useSearchJob.js'

const ACCESS_CLS = { free: 'free', optional: 'optional', key: 'key', link: 'link' }
export const ACCESS_SHORT = { free: 'без ключа', optional: 'ключ по желанию', key: 'нужен ключ', link: 'ручной поиск' }
const STATUS_RU = { ok: 'доступен', error: 'ошибка', need_key: 'нужен ключ', link: 'ручной поиск по ссылке', checking: 'проверка…' }

export default function ApiPanel({ onUpdate, onOpenResult }) {
  const [list, setList] = useState([])
  const [status, setStatus] = useState({})
  const [testing, setTesting] = useState(false)
  const [keyFor, setKeyFor] = useState(null)
  const [err, setErr] = useState('')
  const [progress, setProgress] = useState(0)

  const [topic, setTopic] = useState('слабые сигналы в области искусственного интеллекта')
  const [showUpdate, setShowUpdate] = useState(false)
  const upd = useSearchJob((j) => onUpdate && onUpdate(j))
  const load = () => api.sources().then(setList).catch((e) => setErr(e.message))
  const runUpdate = () => {
    const ids = list.filter((s) => s.usable && (s.default || s.has_key)).map((s) => s.id)
    upd.start(topic.trim(), 'hybrid', ids)
  }
  useEffect(() => { load() }, [])

  const test = async () => {
    setTesting(true); setProgress(0)
    const ids = list.map((s) => s.id)
    const st = {}
    ids.forEach((i) => { st[i] = { status: 'checking' } })
    setStatus({ ...st })
    let done = 0
    // по 4 источника за запрос — прогресс виден оператору
    for (let k = 0; k < ids.length; k += 4) {
      const chunk = ids.slice(k, k + 4)
      try {
        const res = await api.testSources(chunk)
        res.forEach((r) => { st[r.id] = r })
      } catch (e) { chunk.forEach((i) => { st[i] = { status: 'error', error: e.message } }) }
      done += chunk.length
      setProgress(Math.round(100 * done / ids.length)); setStatus({ ...st })
    }
    setTesting(false)
  }

  const groups = {}
  list.forEach((s) => { (groups[s.group] = groups[s.group] || []).push(s) })
  const okCount = Object.values(status).filter((s) => s.status === 'ok').length

  return (
    <section className="api-panel">
      <h3>🔌 Подключение к внешним источникам данных</h3>
      <p className="note">Для автоматического сбора актуальных данных используются открытые научные библиотеки, патентные, клинические, новостные и книжные источники. Обновление не прекращается при недоступности отдельной внешней базы. Источники без ключа работают сразу; для источников с ключом нажмите «Ввести ключ» — появится справка, где его получить, после ввода источник подключается и проверяется автоматически.</p>
      <div className="row" style={{ marginBottom: 12 }}>
        <button onClick={test} disabled={testing || !list.length}>{testing && <span className="spin" />}🧪 Тестировать подключение</button>
        <button className="green" onClick={() => setShowUpdate(true)} disabled={upd.running}>{upd.running && <span className="spin" />}🔄 Обновить данные</button>
        {Object.keys(status).length > 0 && <span className="muted">Доступно: {okCount} из {list.length}</span>}
      </div>
      {showUpdate && (
        <div className="update-box">
          <b>🔄 Обновление справочника свежими данными из источников</b>
          <p className="muted" style={{ margin: '6px 0 10px' }}>Выполняется реальный поиск по всем доступным источникам (режим «Гибрид»). Найденные слабые сигналы добавятся в справочник.</p>
          <div className="search-box">
            <input value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="Тема обновления" disabled={upd.running} />
            <button onClick={runUpdate} disabled={upd.running || topic.trim().length < 2 || !list.length}>Запустить обновление</button>
          </div>
          {!upd.job && !upd.error && <><div className="progress"><div style={{ width: '0%' }} /></div><div className="progress-row"><span>Подготовка поиска…</span><span>0%</span></div></>}
          {upd.error && <p className="error">{upd.error}</p>}
          <ProgressBox job={upd.job} onCancel={upd.cancel} />
          {upd.job && upd.job.status === 'done' && onOpenResult && <button className="link" onClick={() => onOpenResult(upd.job.id)}>Открыть отчёт ТОП-15 →</button>}
        </div>)}
      {testing && <><div className="progress"><div style={{ width: progress + '%' }} /></div><div className="progress-row"><span>Проверка источников…</span><span>{progress}%</span></div></>}
      {err && <p className="error">{err}</p>}
      <div className="source-groups">
        {Object.entries(groups).map(([g, items]) => (
          <div className="src-group" key={g}>
            <h4>{g} <span className="muted" style={{ fontWeight: 500 }}>{items.length}</span></h4>
            {items.map((s) => {
              const st = status[s.id]
              const dotCls = st ? st.status : (s.access === 'link' ? 'link_only' : (s.access === 'key' && !s.has_key ? 'need_key' : ''))
              return (
                <div className="src" key={s.id}>
                  <span className={'dot ' + (dotCls === 'link' ? 'link_only' : dotCls)} title={st ? STATUS_RU[st.status] : ''} />
                  <div>
                    <div className="src-name">{s.name}</div>
                    <small>
                      {st ? (STATUS_RU[st.status] || st.status) + (st.n ? ` · ${st.n} док.` : '') + (st.ms ? ` · ${(st.ms / 1000).toFixed(1)} с` : '') + (st.error && st.status !== 'need_key' ? ' · ' + st.error : '') : s.access_ru}
                      {s.has_key && ' · ключ: ' + (s.key_masked || 'задан')}
                    </small>
                    <div className="row" style={{ gap: 8, marginTop: 4 }}>
                      <span className={'badge ' + ACCESS_CLS[s.access]} title={s.access_ru}>{ACCESS_SHORT[s.access]}</span>
                      {(s.access === 'key' || s.access === 'optional') && <button className="link key-btn" onClick={() => setKeyFor(s)}>{s.has_key ? '🔑 Изменить ключ' : '🔑 Ввести ключ'}</button>}
                    </div>
                  </div>
                </div>)
            })}
          </div>))}
      </div>
      <LlmSettings />
      <p className="note" style={{ marginTop: 14 }}>Прямые запросы к закрытым API выполняются через серверный прокси (backend) с вашими ключами — ключи не передаются в браузер. Для источников «ручной поиск» карточки содержат интерактивные ссылки на первичные источники и поисковые выдачи.</p>
      {keyFor && <KeyModal source={keyFor} onClose={() => setKeyFor(null)} onSaved={() => { load() }} />}
    </section>
  )
}
