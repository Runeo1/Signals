import React, { useEffect, useState } from 'react'
import { api, pct } from '../api.js'
import InsightReport from './InsightReport.jsx'
import { ACCESS_SHORT } from './ApiPanel.jsx'
import ProgressBox from './ProgressBox.jsx'
import DocumentsTable from './DocumentsTable.jsx'
import { useSearchJob } from '../utils/useSearchJob.js'
import { downloadCsv, downloadJson } from '../utils/export.js'

const EXAMPLES = ['технологии в ИИ', 'перспективные решения в финтехе', 'слабые сигналы в области кибербезопасности',
  'нейроморфные вычисления', 'твердотельные аккумуляторы', 'квантовые сенсоры в медицине']
const MODES = [
  ['hybrid', 'Гибрид (рекомендуется)', 'Сбор из библиотек через API + скоринг по авторской ТРИЗ-методологии и ML-модели (60% модель + 40% ТРИЗ-индекс).'],
  ['methodology', 'Авторская методология', 'Только ТРИЗ-индекс: противоречие → смена принципа, надсистема, идеальность, микроуровень, S-кривая, отсев хайпа и зрелости.'],
  ['library', 'Библиотеки', 'Поиск в библиотеках с обязательной проверкой доказательств, зрелости и гибридным скорингом.'],
]

export default function SearchPage({ initialRun, onDone }) {
  const [query, setQuery] = useState('')
  const [mode, setMode] = useState('hybrid')
  const [sources, setSources] = useState([])
  const [selected, setSelected] = useState([])
  const [showSources, setShowSources] = useState(false)
  const [err, setErr] = useState('')
  const [section, setSection] = useState('top')
  const sj = useSearchJob(() => onDone && onDone())
  const job = sj.job

  useEffect(() => {
    api.sources().then((list) => { setSources(list); setSelected(list.filter((s) => (s.default || s.has_key) && s.usable).map((s) => s.id)) }).catch((e) => setErr(e.message))
  }, [])
  useEffect(() => { if (initialRun) sj.open(initialRun) }, [initialRun])

  const start = (q) => {
    const text = (q ?? query).trim()
    if (text.length < 2) return
    setSection('top'); sj.start(text, mode, selected)
  }
  const groups = {}
  sources.forEach((s) => { (groups[s.group] = groups[s.group] || []).push(s) })
  const toggleGroup = (g, on) => {
    const ids = groups[g].filter((s) => s.usable).map((s) => s.id)
    setSelected(on ? Array.from(new Set([...selected, ...ids])) : selected.filter((i) => !ids.includes(i)))
  }
  const toggle = (id) => setSelected(selected.includes(id) ? selected.filter((i) => i !== id) : [...selected, id])
  const running = sj.running
  const r = job?.result?.stats ? job.result : null
  const exportTop = () => downloadCsv('top15-' + job.id + '.csv', [
    ['rank', '№'], ['name', 'Технология'], ['name_original', 'Оригинал'], [(i) => Math.round(i.probability * 100) + '%', 'Вероятность'],
    ['stage', 'Стадия'], ['trend', 'Аналитика / тренд'], ['strength', 'Сила'], ['impact', 'Влияние'], ['horizon', 'Горизонт'],
    ['description', 'Краткое описание'], ['advantage', 'Ключевое преимущество'], [(i) => (i.case ? i.case.kind + ': ' + (i.case.title_ru || i.case.title) + ' ' + (i.case.url || '') : ''), 'Кейс-пример'],
    ['status_explanation', 'Статус и объяснение'], [(i) => i.sources.map((s) => s.url).join(' '), 'Источники']], r.items)

  return (
    <div className="section">
      <h2>🔎 Открытый поиск слабых сигналов</h2>
      <p className="lead">Введите тему на русском или английском. Сервис соберёт документы из выбранных библиотек, выделит технологии-кандидаты, проверит каждую по методологии (стадия, динамика публикаций, патенты, фантастика, признаки ТРИЗ) и сформирует ТОП-15 инсайтов на русском языке со ссылками на первоисточники.</p>
      <div className="search-box">
        <textarea placeholder="Например: слабые сигналы в области кибербезопасности" value={query} onChange={(e) => setQuery(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); start() } }} />
        <button onClick={() => start()} disabled={running || query.trim().length < 2 || !selected.length} style={{ height: 56, minWidth: 190 }}>{running && <span className="spin" />}Найти слабые сигналы</button>
      </div>
      <div className="examples">{EXAMPLES.map((x) => <button key={x} disabled={running} onClick={() => { setQuery(x); start(x) }}>{x}</button>)}</div>
      <div className="modes">{MODES.map(([id, t, d]) => (
        <div key={id} className={'mode' + (mode === id ? ' active' : '')} onClick={() => setMode(id)}><b>{mode === id ? '◉' : '○'} {t}</b><span>{d}</span></div>))}</div>
      <div className="group-select">
        {Object.entries(groups).map(([g, items]) => {
          const usable = items.filter((s) => s.usable)
          const on = usable.length > 0 && usable.every((s) => selected.includes(s.id))
          return <label key={g} className="check"><input type="checkbox" checked={on} disabled={!usable.length} onChange={(e) => toggleGroup(g, e.target.checked)} /> {g} ({usable.filter((s) => selected.includes(s.id)).length}/{items.length})</label>
        })}
        <button className="link" onClick={() => setShowSources(!showSources)}>{showSources ? 'Скрыть список источников' : 'Выбрать источники вручную'}</button>
        <span className="muted">Выбрано источников: {selected.length}</span>
      </div>
      {showSources && (
        <div className="source-groups" style={{ marginBottom: 16 }}>
          {Object.entries(groups).map(([g, items]) => (
            <div className="src-group" key={g}><h4>{g}</h4>
              {items.map((s) => (
                <label key={s.id} className="check" style={{ padding: '4px 0', opacity: s.usable ? 1 : 0.55 }}>
                  <input type="checkbox" disabled={!s.usable} checked={selected.includes(s.id)} onChange={() => toggle(s.id)} /> {s.name}
                  <span className={'badge ' + s.access}>{s.usable ? ACCESS_SHORT[s.access] : (s.access === 'link' ? 'ручной поиск' : 'нужен ключ')}</span>
                </label>))}
            </div>))}
        </div>)}
      {(err || sj.error) && <p className="error">{err || sj.error}</p>}
      {job && job.status !== 'done' && <ProgressBox job={job} onCancel={sj.cancel} />}

      {r && (
        <>
          {r.notice && <div className="callout">{r.notice}</div>}
          <p className="muted">Скоринг модели не является калиброванной вероятностью правильности. Выдача требует экспертной проверки.</p>
          <div className="kpis">
            <div className="kpi"><strong>{r.stats.sources_ok}/{r.stats.sources_requested}</strong><span>Обработано источников</span></div>
            <div className="kpi"><strong>{r.stats.documents}</strong><span>Документов собрано</span></div>
            <div className="kpi"><strong>{r.stats.candidates}</strong><span>Технологий-кандидатов</span></div>
            <div className="kpi"><strong>{r.stats.top}</strong><span>Инсайтов в ТОП</span></div>
            <div className="kpi accent"><strong>{r.stats.confident_75}</strong><span>Слабых сигналов с уверенностью &gt;75%</span></div>
            <div className="kpi"><strong>{r.stats.excluded}</strong><span>Исключено (зрелые / хайп / шум)</span></div>
          </div>
          <div className="row no-print" style={{ marginBottom: 10 }}>
            <button className="orange" onClick={() => window.print()}>📄 Экспорт отчёта в PDF</button>
            <button className="ghost" onClick={exportTop}>⬇ ТОП-15 в Excel (CSV)</button>
            <button className="ghost" onClick={() => downloadJson('weak-signals-' + job.id + '.json', r)}>⬇ JSON</button>
            <span className="muted">Запрос: «{r.query}» → «{r.query_en}» · режим: {MODES.find((m) => m[0] === r.mode)?.[1]} · {new Date(r.generated_at).toLocaleString('ru-RU')}{r.llm_configured ? ' · Настроенная LLM: ' + r.llm_configured : ''}</span>
          </div>
          <nav className="tabs no-print" style={{ padding: '0 0 0 0', marginBottom: 8 }}>
            {[['top', 'ТОП-' + r.items.length + ' инсайтов'], ['excluded', 'Отсеяно (' + r.excluded.length + ')'], ['incomplete', 'Неполные отчёты (' + (r.incomplete || []).length + ')'], ['candidates', 'Все кандидаты (' + (r.all_candidates || []).length + ')'], ['sources', 'Источники (' + r.stats.sources_ok + '/' + r.stats.sources_requested + ')'], ['docs', 'Собранные документы (' + r.stats.documents + ')'], ['log', 'Журнал']].map(([id, t]) =>
              <button key={id} className={section === id ? 'active' : ''} onClick={() => setSection(id)}>{t}</button>)}
          </nav>
          {section === 'top' && <>
            <h2 style={{ marginTop: 16 }}>ТОП-{r.items.length} инсайтов: «{r.query}»</h2>
            {r.items.length === 0 && <div className="callout">Слабых сигналов не найдено: ни один кандидат не прошёл все проверки доказательств и полноты отчёта. Попробуйте переформулировать запрос или подключить дополнительные источники.</div>}
            {r.items.map((it) => <InsightReport key={it.id} item={it} />)}
          </>}
          {(section === 'excluded' || section === 'top') && r.excluded.length > 0 && (
            <div className="report">
              <h3>🚫 Отсеяно методологией (хайповый фон, зрелые технологии, шум)</h3>
              <p className="muted">Кандидаты, которые встречаются в источниках, но не являются слабыми сигналами. Показаны причины исключения.</p>
              <table className="tbl"><thead><tr><th>Кандидат</th><th>Оценка</th><th>Стадия</th><th>Публикаций</th><th>Причины</th></tr></thead><tbody>
                {r.excluded.map((e) => <tr key={e.name}><td><b>{e.name_ru}</b><br /><small className="muted">{e.name}</small></td><td>{pct(e.probability)}</td><td>{e.stage}</td><td>{e.publications_total ?? '—'}</td><td>{e.reasons.join(' ')}</td></tr>)}
              </tbody></table>
            </div>)}
          {section === 'incomplete' && <div className="report"><h3>Требуют доработки</h3>
            {(r.incomplete || []).map(i => <div key={i.id}><b>{i.name || 'Перевод названия недоступен'}</b><p>{i.name_original}</p><p>{i.report_issues.join(' ')}</p>
              <p>{i.sources.map(s => <a key={s.url} href={s.url} target="_blank" rel="noreferrer">{s.name} </a>)}</p></div>)}
          </div>}
          {section === 'candidates' && (
            <div className="tbl-wrap"><table className="tbl"><thead><tr><th>#</th><th>Кандидат (оригинал)</th><th>Документов</th><th>Вероятность</th><th>Итог</th></tr></thead><tbody>
              {(r.all_candidates || []).map((c, k) => {
                const inTop = r.items.find((i) => i.name_original === c.name); const ex = r.excluded.find((e) => e.name === c.name)
                return <tr key={k}><td>{k + 1}</td><td>{c.name}</td><td>{c.docs}</td><td>{pct(c.probability)}</td><td>{inTop ? '✅ ТОП-' + inTop.rank : ex ? '🚫 отсеян' : '— за пределами ТОП-15'}</td></tr>
              })}</tbody></table></div>)}
          {section === 'sources' && (
            <table className="tbl"><thead><tr><th>Источник</th><th>Статус</th><th>Документов</th><th>Время</th><th>Ручной поиск</th></tr></thead><tbody>
              {r.sources_status.map((s) => <tr key={s.id}><td>{s.name}</td><td><span className={'dot ' + s.status} /> {s.status === 'ok' ? 'ок' : (s.error || s.status)}</td><td>{s.n}</td><td>{(s.ms / 1000).toFixed(1)} с</td><td>{s.link && <a href={s.link} target="_blank" rel="noreferrer">открыть</a>}</td></tr>)}
            </tbody></table>)}
          {section === 'docs' && <DocumentsTable runId={job.id} />}
          {section === 'log' && <div className="log" style={{ maxHeight: 520 }}>{(job.log || []).join('\n') || 'Журнал недоступен для запусков из истории.'}</div>}
        </>)}
    </div>
  )
}
