import React, { useEffect, useState } from 'react'
import { api } from '../api.js'
import { downloadCsv } from '../utils/export.js'

const MODE_RU = { hybrid: 'Гибрид', methodology: 'Методология', library: 'Библиотеки' }
const STATUS_RU = { done: 'готово', running: 'выполняется', error: 'ошибка', cancelled: 'остановлен' }

export default function History({ onOpen, onChanged }) {
  const [runs, setRuns] = useState(null)
  const [err, setErr] = useState('')
  const [q, setQ] = useState('')
  const [confirmId, setConfirmId] = useState(null)
  const load = () => api.runs().then(setRuns).catch((e) => setErr(e.message))
  useEffect(() => { load() }, [])
  const del = async (r) => {
    // двухшаговое подтверждение без window.confirm (работает и во встроенных окнах)
    if (confirmId !== r.id) { setConfirmId(r.id); return }
    setConfirmId(null)
    try { await api.deleteRun(r.id); load(); onChanged && onChanged() } catch (e) { setErr(e.message) }
  }
  const shown = (runs || []).filter((r) => !q || r.query.toLowerCase().includes(q.toLowerCase()))
  const date = (r) => (r.started_at ? new Date(r.started_at + 'Z').toLocaleString('ru-RU') : '')
  return (
    <div className="section">
      <h2>🕘 История запусков</h2>
      <p className="lead">Все запуски сохраняются в базе данных: сырые документы, кандидаты, итоговые отчёты. Откройте запуск, чтобы посмотреть ТОП-15.</p>
      <div className="row" style={{ marginBottom: 12 }}>
        <input placeholder="Фильтр по запросу" value={q} onChange={(e) => setQ(e.target.value)} style={{ maxWidth: 320 }} />
        <button className="ghost" onClick={load}>↻ Обновить</button>
        <button className="ghost" disabled={!shown.length} onClick={() => downloadCsv('history.csv', [[date, 'Дата'], ['query', 'Запрос'], [(r) => MODE_RU[r.mode] || r.mode, 'Режим'], [(r) => STATUS_RU[r.status] || r.status, 'Статус'], [(r) => r.stats ? r.stats.documents : '', 'Документы'], [(r) => r.stats ? r.stats.confident_75 : '', 'Уверенность >75%']], shown)}>⬇ CSV</button>
      </div>
      {err && <p className="error">{err}</p>}
      {!runs && !err && <p>Загрузка…</p>}
      {runs && runs.length === 0 && <div className="callout info">Запусков пока нет. Перейдите на вкладку «Открытый поиск».</div>}
      {shown.length > 0 && (
        <table className="tbl"><thead><tr><th>Дата</th><th>Запрос</th><th>Режим</th><th>Статус</th><th>Источники</th><th>Документы</th><th>Уверенность &gt;75%</th><th /></tr></thead><tbody>
          {shown.map((r) => <tr key={r.id}><td>{date(r)}</td><td><b>{r.query}</b></td><td>{MODE_RU[r.mode] || r.mode}</td>
            <td>{STATUS_RU[r.status] || r.status}</td><td>{r.stats ? `${r.stats.sources_ok}/${r.stats.sources_requested}` : '—'}</td>
            <td>{r.stats ? r.stats.documents : '—'}</td><td>{r.stats ? r.stats.confident_75 : '—'}</td>
            <td style={{ whiteSpace: 'nowrap' }}>{r.status === 'done' && <button className="link" onClick={() => onOpen(r.id)}>Открыть</button>}{' '}
              {r.status !== 'running' && <button className="link" style={{ color: 'var(--rose)' }} onClick={() => del(r)}>{confirmId === r.id ? 'Точно удалить?' : 'Удалить'}</button>}
              {confirmId === r.id && <button className="link" style={{ marginLeft: 8 }} onClick={() => setConfirmId(null)}>Отмена</button>}</td></tr>)}
        </tbody></table>)}
    </div>
  )
}
