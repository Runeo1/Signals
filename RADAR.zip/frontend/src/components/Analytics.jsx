import React, { useMemo } from 'react'

function Dist({ title, data, color }) {
  const max = Math.max(1, ...data.map((d) => d[1]))
  return (
    <div className="src-group">
      <h4>{title}</h4>
      <div className="bars">
        {data.map(([k, v]) => (
          <div className="bar" key={k} style={{ gridTemplateColumns: '200px 1fr 50px' }}>
            <span title={k}>{k.length > 32 ? k.slice(0, 31) + '…' : k}</span>
            <div className="track"><div className="fill" style={{ width: (100 * v / max) + '%', background: color }} /></div>
            <b>{v}</b>
          </div>))}
      </div>
    </div>)
}

// Аналитика по текущей выборке справочника
export default function Analytics({ items }) {
  const agg = useMemo(() => {
    const count = (fn) => {
      const m = {}
      items.forEach((i) => { const k = fn(i) || '—'; m[k] = (m[k] || 0) + 1 })
      return Object.entries(m).sort((a, b) => b[1] - a[1])
    }
    const bucket = (p) => (p == null ? '—' : p >= 0.9 ? '90–100%' : p >= 0.75 ? '75–90%' : p >= 0.5 ? '50–75%' : 'ниже 50%')
    return {
      industry: count((i) => i.industry).slice(0, 10),
      strength: count((i) => i.strength),
      impact: count((i) => i.impact),
      prob: ['90–100%', '75–90%', '50–75%', 'ниже 50%'].map((b) => [b, items.filter((i) => bucket(i.probability) === b).length]),
      stage: count((i) => (i.stage || '').split('(')[0].trim()).slice(0, 8),
      origin: count((i) => (i.origin || '').startsWith('Открытый') ? 'Открытый поиск' : 'Датасет'),
    }
  }, [items])
  return (
    <div className="section" style={{ paddingBottom: 0 }}>
      <h2>📈 Аналитика по выборке ({items.length})</h2>
      <p className="lead">Распределения пересчитываются при каждом применении фильтров.</p>
      <div className="source-groups">
        <Dist title="🏭 По отраслям / запросам" data={agg.industry} color="var(--primary)" />
        <Dist title="📊 По силе сигнала" data={agg.strength} color="var(--amber)" />
        <Dist title="💡 По потенциальному влиянию" data={agg.impact} color="var(--teal)" />
        <Dist title="🎯 По вероятности слабого сигнала" data={agg.prob} color="var(--green)" />
        <Dist title="🧭 По стадии развития" data={agg.stage} color="var(--blue)" />
        <Dist title="🗂 По происхождению" data={agg.origin} color="var(--violet)" />
      </div>
    </div>)
}
