// Клиент REST API backend (FastAPI)
const BASE = (window.RADAR_API || '').replace(/\/$/, '')
const TOKEN_KEY = 'wsr_token'

let memToken = ''
export const token = {
  // sessionStorage недоступен в изолированных iframe — тогда токен хранится в памяти вкладки
  get: () => { try { return sessionStorage.getItem(TOKEN_KEY) || '' } catch { return memToken } },
  set: (t) => { memToken = t; try { sessionStorage.setItem(TOKEN_KEY, t) } catch { /* память */ } },
  clear: () => { memToken = ''; try { sessionStorage.removeItem(TOKEN_KEY) } catch { /* память */ } },
}

export class ApiError extends Error {
  constructor(status, message) { super(message); this.status = status }
}

async function request(method, path, body, isForm) {
  const headers = {}
  const t = token.get()
  if (t) headers.Authorization = 'Bearer ' + t
  let payload
  if (body !== undefined) {
    if (isForm) payload = body
    else { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body) }
  }
  let res
  try {
    res = await fetch(BASE + path, { method, headers, body: payload })
  } catch (e) {
    throw new ApiError(0, 'Сервер справочника не отвечает. Проверьте, что окно запуска (START_WINDOWS.bat / start.sh) открыто или контейнеры Docker запущены, и нажмите «Повторить». Подробнее — INSTRUKCIYA_ZAPUSK_I_PROVERKA.md, раздел «Если что-то не работает».')
  }
  const text = await res.text()
  let data = null
  try { data = text ? JSON.parse(text) : null } catch { data = text }
  if (!res.ok) {
    let msg = (data && data.detail) || res.statusText || 'Ошибка запроса'
    if (Array.isArray(msg)) msg = msg.map((d) => d.msg).join('; ')
    throw new ApiError(res.status, msg)
  }
  return data
}

export const api = {
  health: () => request('GET', '/api/health'),
  authStatus: () => request('GET', '/api/auth/status'),
  setup: (password) => request('POST', '/api/auth/setup', { password }),
  login: (password) => request('POST', '/api/auth/login', { password }),
  openLogin: () => request('POST', '/api/auth/open'),
  changePassword: (current, next) => request('POST', '/api/auth/change', { current, new: next }),
  setRequire: (require_password, current) => request('POST', '/api/auth/require', { require_password, current }),
  sources: () => request('GET', '/api/sources'),
  testSources: (ids) => request('POST', '/api/sources/test', ids),
  setKey: (source_id, key) => request('PUT', '/api/keys', { source_id, key }),
  deleteKey: (id) => request('DELETE', '/api/keys/' + encodeURIComponent(id)),
  llm: () => request('GET', '/api/llm'),
  setLlm: (cfg) => request('PUT', '/api/llm', cfg),
  catalog: () => request('GET', '/api/catalog'),
  search: (query, mode, sources) => request('POST', '/api/search', { query, mode, sources }),
  job: (id) => request('GET', '/api/search/' + id),
  cancel: (id) => request('POST', '/api/search/' + id + '/cancel'),
  deleteRun: (id) => request('DELETE', '/api/runs/' + id),
  runDocuments: (id) => request('GET', '/api/runs/' + id + '/documents'),
  runs: () => request('GET', '/api/runs'),
  modelInfo: () => request('GET', '/api/model/info'),
  predictions: () => request('GET', '/api/model/predictions'),
  score: (rec) => request('POST', '/api/model/score', rec),
  validate: (file) => { const f = new FormData(); f.append('file', file); return request('POST', '/api/model/validate', f, true) },
  retrain: () => request('POST', '/api/model/retrain'),
  apiBase: () => BASE,
}

export const pct = (p) => (p == null ? '—' : Math.round(p * 100) + '%')
