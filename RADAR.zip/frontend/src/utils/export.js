// Экспорт таблиц в CSV (открывается в Excel: UTF-8 с BOM, разделитель «;»)
export function downloadCsv(filename, columns, rows) {
  const esc = (v) => {
    const s = v == null ? '' : Array.isArray(v) ? v.join('; ') : String(v)
    return '"' + s.replace(/"/g, '""') + '"'
  }
  const lines = [columns.map((c) => esc(c[1])).join(';')]
  rows.forEach((r) => lines.push(columns.map((c) => esc(typeof c[0] === 'function' ? c[0](r) : r[c[0]])).join(';')))
  const blob = new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' })
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob); a.download = filename; a.click()
  setTimeout(() => URL.revokeObjectURL(a.href), 2000)
}

export function downloadJson(filename, data) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob); a.download = filename; a.click()
  setTimeout(() => URL.revokeObjectURL(a.href), 2000)
}

export const CATALOG_COLUMNS = [
  ['name', 'Технология'], ['name_original', 'Оригинальное название'], ['industry', 'Отрасль / запрос'], ['strength', 'Сила сигнала'],
  ['impact', 'Потенциальное влияние'], [(r) => (r.probability == null ? '' : Math.round(r.probability * 100) + '%'), 'Вероятность слабого сигнала'],
  [(r) => (r.p_model == null ? '' : Math.round(r.p_model * 100) + '%'), 'ML-модель'], [(r) => (r.p_methodology == null ? '' : Math.round(r.p_methodology * 100) + '%'), 'ТРИЗ-индекс'],
  ['stage', 'Стадия'], ['trend', 'Тренд упоминаний'], ['horizon', 'Горизонт'], ['companies', 'Компании'], ['description', 'Описание'],
  [(r) => (r.links || []).map((l) => l.url).join(' '), 'Источники'], ['origin', 'Происхождение'], ['date', 'Дата'],
]
