import { useEffect, useRef, useState } from 'react'
import { api } from '../api.js'

// Запуск поиска на backend и опрос прогресса каждые 1,5 с
export function useSearchJob(onDone) {
  const [job, setJob] = useState(null)
  const [error, setError] = useState('')
  const timer = useRef(null)
  const alive = useRef(true)

  useEffect(() => { alive.current = true; return () => { alive.current = false; clearTimeout(timer.current) } }, [])

  const poll = async (id) => {
    try {
      const j = await api.job(id)
      if (!alive.current) return
      setJob(j)
      if (j.status === 'running') timer.current = setTimeout(() => poll(id), 1500)
      else if (j.status === 'done' && onDone) onDone(j)
    } catch (e) {
      if (!alive.current) return
      setError(e.message)
      timer.current = setTimeout(() => poll(id), 4000) // сеть могла моргнуть — продолжаем опрос
    }
  }
  const start = async (query, mode, sources) => {
    setError(''); setJob(null); clearTimeout(timer.current)
    try {
      const r = await api.search(query, mode, sources)
      setJob({ id: r.id, query, mode, status: 'running', progress: 0, stage: 'Подготовка поиска…', log: [] })
      poll(r.id)
    } catch (e) { setError(e.message) }
  }
  const open = (id) => { clearTimeout(timer.current); setError(''); poll(id) }
  const cancel = async () => { if (job) { try { await api.cancel(job.id) } catch (e) { setError(e.message) } } }
  return { job, error, start, open, cancel, running: !!job && job.status === 'running' }
}
