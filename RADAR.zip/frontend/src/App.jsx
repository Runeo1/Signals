import React, { useCallback, useEffect, useState } from 'react'
import { api, token } from './api.js'
import Login from './components/Login.jsx'
import Catalog from './components/Catalog.jsx'
import ApiPanel from './components/ApiPanel.jsx'
import SearchPage from './components/SearchPage.jsx'
import Validation from './components/Validation.jsx'
import History from './components/History.jsx'
import PasswordModal from './components/PasswordModal.jsx'
import HelpModal from './components/HelpModal.jsx'
import SystemStatus from './components/SystemStatus.jsx'

const TABS = [
  ['catalog', '📚 Справочник трендов'],
  ['search', '🔎 Открытый поиск (ТОП-15)'],
  ['validation', '🧪 Проверка методологии'],
  ['history', '🕘 История запусков'],
]

export default function App() {
  const [auth, setAuth] = useState(null) // {password_set, require_password}
  const [logged, setLogged] = useState(false)
  const [tab, setTab] = useState('catalog')
  const [showApi, setShowApi] = useState(false)
  const [showPwd, setShowPwd] = useState(false)
  const [bootError, setBootError] = useState('')
  const [openRun, setOpenRun] = useState(null)
  const [catalogVersion, setCatalogVersion] = useState(0)
  const [showHelp, setShowHelp] = useState(false)

  const refreshAuth = useCallback(async () => {
    try {
      const st = await api.authStatus()
      setAuth(st)
      if (st.password_set && !st.require_password && !token.get()) {
        const r = await api.openLogin(); token.set(r.token); setLogged(true)
      } else if (token.get()) {
        try { await api.sources(); setLogged(true) } catch { token.clear(); setLogged(false) }
      }
      setBootError('')
    } catch (e) { setBootError(e.message) }
  }, [])

  useEffect(() => { refreshAuth() }, [refreshAuth])

  const logout = () => { token.clear(); setLogged(false); refreshAuth() }

  if (bootError) return (
    <div className="login"><h1>🔐 Справочник слабых сигналов</h1><p className="error">{bootError}</p>
      <button onClick={refreshAuth}>Повторить</button><Copyright /></div>)
  if (!auth) return <div className="login"><h1>🔐 Справочник слабых сигналов</h1><p>Загрузка…</p><Copyright /></div>
  if (!logged) return <><Login status={auth} onDone={() => { setLogged(true); refreshAuth() }} /><Copyright /></>

  return (
    <>
      <div className="app">
        <header className="hero">
          <h1>🔭 Справочник слабых сигналов</h1>
          <p>Интерактивная база данных зарождающихся трендов в научно-технологических отраслях</p>
        </header>
        <div className="user-bar">
          <small>🔓 Авторизован | Пароль установлен{auth.require_password ? '' : ' · вход без пароля включён'}</small>
          <div className="buttons">
            <button className="purple" onClick={() => setShowPwd(true)}>⚙️ Настройки пароля</button>
            <button className="teal" onClick={() => setShowApi((v) => !v)}>🔌 API источники</button>
            <button className="gray" onClick={() => setShowHelp(true)}>❓ Справка</button>
            {auth.require_password && <button className="red" onClick={logout}>🚪 Выйти</button>}
          </div>
        </div>
        {showApi && <ApiPanel onUpdate={() => setCatalogVersion((v) => v + 1)} onOpenResult={(id) => { setOpenRun(id); setTab('search') }} />}
        <nav className="tabs">
          {TABS.map(([id, title]) => (
            <button key={id} className={tab === id ? 'active' : ''} onClick={() => setTab(id)}>{title}</button>
          ))}
        </nav>
        {tab === 'catalog' && <Catalog version={catalogVersion} />}
        {tab === 'search' && <SearchPage initialRun={openRun} onDone={() => setCatalogVersion((v) => v + 1)} />}
        {tab === 'validation' && <Validation />}
        {tab === 'history' && <History onOpen={(id) => { setOpenRun(id); setTab('search') }} onChanged={() => setCatalogVersion((v) => v + 1)} />}
        <footer className="foot">🔐 Защищённая версия | Справочник слабых сигналов · <a href={api.apiBase() + '/docs'} target="_blank" rel="noreferrer">API (Swagger)</a><SystemStatus /></footer>
      </div>
      {showPwd && <PasswordModal status={auth} onClose={() => setShowPwd(false)} onChanged={refreshAuth} />}
      {showHelp && <HelpModal onClose={() => setShowHelp(false)} />}
      <Copyright />
    </>
  )
}

function Copyright() { return <div className="copyright">(С) РуНео 2026</div> }
