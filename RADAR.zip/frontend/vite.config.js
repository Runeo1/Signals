import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// В режиме разработки запросы /api проксируются на FastAPI (порт 8000)
export default defineConfig({
  plugins: [react()],
  base: './',
  server: { port: 5173, host: true, proxy: { '/api': 'http://127.0.0.1:8000', '/docs': 'http://127.0.0.1:8000', '/openapi.json': 'http://127.0.0.1:8000' } },
  build: { outDir: 'dist', sourcemap: false }
})
