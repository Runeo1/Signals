#!/usr/bin/env bash
# Быстрая проверка работающего сервиса: ./scripts/smoke_test.sh [адрес] [пароль]
BASE=${1:-http://localhost:8000}; PASS=${2:-}
ok(){ echo "  [OK]   $1"; }; bad(){ echo "  [FAIL] $1"; FAIL=1; }
echo "Проверка $BASE"
H=$(curl -s "$BASE/api/health"); echo "$H" | grep -q '"status":"ok"' && ok "backend отвечает: $(echo $H | head -c 90)…" || bad "backend не отвечает"
echo "$H" | grep -q '"database_ok":true' && ok "база данных доступна" || bad "база данных"
curl -s "$BASE/" | grep -q '<div id="root">' && ok "интерфейс (SPA) раздаётся" || bad "интерфейс не найден (соберите frontend)"
curl -s "$BASE/docs" | grep -qi swagger && ok "Swagger UI" || bad "Swagger UI"
ST=$(curl -s "$BASE/api/auth/status"); echo "  статус пароля: $ST"
if [ -n "$PASS" ]; then
  TOK=$(curl -s -X POST "$BASE/api/auth/login" -H 'Content-Type: application/json' -d "{\"password\":\"$PASS\"}" | sed -n 's/.*"token":"\([^"]*\)".*/\1/p')
  [ -n "$TOK" ] && ok "вход по паролю" || bad "вход по паролю"
  N=$(curl -s "$BASE/api/catalog" -H "Authorization: Bearer $TOK" | grep -o '"id"' | wc -l); [ "$N" -ge 100 ] && ok "справочник: $N карточек" || bad "справочник: $N карточек"
  curl -s "$BASE/api/model/info" -H "Authorization: Bearer $TOK" | grep -q cv_accuracy && ok "модель и метрики валидации" || bad "отчёт о валидации"
  echo "  проверка подключения к источникам (до 60 с)…"
  curl -s -m 120 -X POST "$BASE/api/sources/test" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' -d 'null' | grep -o '"status":"[a-z_]*"' | sort | uniq -c
fi
[ -z "$FAIL" ] && echo "Итог: всё в порядке" || { echo "Итог: есть ошибки"; exit 1; }
