@echo off
setlocal EnableExtensions
title Weak Signals Radar - (C) RuNeo 2026
REM ============================================================
REM  Spravochnik slabyh signalov - zapusk v Windows bez Docker.
REM  Dvazhdy shchelknite etot fayl. Okno ne zakryvayte - eto server.
REM ============================================================
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
chcp 65001 >nul 2>nul

cd /d "%~dp0..\backend"
if errorlevel 1 (
  echo [ERROR] Folder "backend" not found next to "scripts". Unpack the whole archive.
  goto :fail
)

REM ---- 1. Python ----
set "PY_EXE="
set "PY_ARGS="
REM Prefer the Python launcher, then check the usual per-user/system install paths.
py -3.14 -c "import sys" >nul 2>nul && (set "PY_EXE=py" & set "PY_ARGS=-3.14")
if not defined PY_EXE if exist "%LocalAppData%\Programs\Python\Python314\python.exe" set "PY_EXE=%LocalAppData%\Programs\Python\Python314\python.exe"
if not defined PY_EXE if exist "%ProgramFiles%\Python314\python.exe" set "PY_EXE=%ProgramFiles%\Python314\python.exe"
if not defined PY_EXE if exist "%ProgramFiles(x86)%\Python314\python.exe" set "PY_EXE=%ProgramFiles(x86)%\Python314\python.exe"
if not defined PY_EXE (
  python -c "import sys; sys.exit(0 if sys.version_info[:2] == (3,14) else 1)" >nul 2>nul && set "PY_EXE=python"
)
if not defined PY_EXE (
  echo [ERROR] Python not found.
  echo         Install CPython 3.14.7 x64 from https://www.python.org/downloads/
  echo         and tick "Add python.exe to PATH" in the installer.
  echo         You can also repair the installation and enable "Python Launcher".
  goto :fail
)
if "%PY_EXE%"=="py" (set "PY_RUN=py -3.14") else (set PY_RUN="%PY_EXE%")
%PY_RUN% -c "import sys; sys.exit(0 if sys.version_info[:2] == (3,14) else 1)"
if errorlevel 1 (
  echo [ERROR] Python 3.14 is required. Install Python 3.14 from https://www.python.org/downloads/.
  goto :fail
)
for /f "delims=" %%v in ('%PY_RUN% -c "import sys; print(sys.version.split()[0])"') do echo Python %%v

REM ---- 2. Virtual environment ----
if not exist ".venv314\Scripts\python.exe" (
  echo Creating virtual environment .venv314 ...
  %PY_RUN% -m venv .venv314
  if errorlevel 1 (
    echo [ERROR] Could not create virtual environment.
    goto :fail
  )
)
set "VPY=%CD%\.venv314\Scripts\python.exe"

REM ---- 3. Dependencies (only if missing) ----
"%VPY%" -c "import fastapi, uvicorn, sqlalchemy, sklearn, pandas, numpy, httpx, bcrypt, jwt, openpyxl, wordfreq, multipart" >nul 2>nul
if errorlevel 1 (
  echo Installing dependencies, 2-5 minutes on first run ...
  "%VPY%" -m pip install --disable-pip-version-check -q --upgrade pip
  "%VPY%" -m pip install --disable-pip-version-check --only-binary=:all: -r requirements.txt
  if errorlevel 1 (
    echo [ERROR] pip install failed. Check the internet connection and run this file again.
    goto :fail
  )
)

REM ---- 4. Start: the browser opens automatically when the server is ready ----
"%VPY%" run.py
if errorlevel 1 goto :fail
echo.
echo Server stopped.
pause
exit /b 0

:fail
echo.
echo Startup failed - see the messages above.
pause
exit /b 1
