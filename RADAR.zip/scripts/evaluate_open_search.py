"""Export blind review sheets and score independently annotated live search results.

python scripts/evaluate_open_search.py export run.json review.csv
python scripts/evaluate_open_search.py score run.json review.csv metrics.json
Do not use training-set labels or model predictions as expert truth.
"""
import csv
import hashlib
import json
import sys
from pathlib import Path

FIELDS = ['candidate_id', 'technology', 'source_urls', 'is_weak', 'is_mature', 'relevant', 'case_supported', 'sources_complete', 'reviewer', 'notes']
LABELS = ['is_weak', 'is_mature', 'relevant', 'case_supported', 'sources_complete']

def result(path):
    data=json.loads(Path(path).read_text(encoding='utf-8'))
    return data.get('result') or data


def cid(item):
    return hashlib.sha256(item['name_original'].encode()).hexdigest()[:16]


def export(run_path, review_path):
    items=result(run_path)['items'][:15]
    with open(review_path,'w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader()
        for item in items:
            w.writerow(dict(candidate_id=cid(item),technology=item['name_original'],source_urls=' '.join(s['url'] for s in item['sources'])))


def score(run_path, review_path):
    items=result(run_path)['items'][:15]
    with open(review_path,encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
    if len({r['candidate_id'] for r in rows})!=len(rows):raise ValueError('Duplicate annotations')
    labels={r['candidate_id']:r for r in rows}
    if set(labels)!={cid(i) for i in items}:raise ValueError('Annotations must match exactly this TOP list')
    for r in rows:
        if not r['reviewer'].strip() or any(r[k] not in {'0','1'} for k in LABELS):
            raise ValueError('Each field needs an independent human label (0/1) and reviewer identity')
    n=len(items)
    valid=sum(int(r['is_weak']) and not int(r['is_mature']) and int(r['relevant']) and int(r['case_supported']) for r in rows)
    return dict(returned=n,coverage_at_15=n/15,precision_at_15=valid/15,
                precision_returned=valid/n if n else None,
                mature_share=sum(int(r['is_mature']) for r in rows)/n if n else None,
                relevance=sum(int(r['relevant']) for r in rows)/n if n else None,
                sources_complete=sum(int(r['sources_complete']) for r in rows)/n if n else None,
                review_status='scored' if n else 'no_results',
                note='Precision@15 penalizes missing positions; precision_returned uses only returned positions. Independent expert review required.')

if __name__=='__main__':
    try:
        if sys.argv[1]=='export':export(*sys.argv[2:4])
        elif sys.argv[1]=='score':Path(sys.argv[4]).write_text(json.dumps(score(*sys.argv[2:4]),ensure_ascii=False,indent=2),encoding='utf-8')
        else:raise ValueError('Use export or score')
    except (IndexError,ValueError,KeyError) as e:
        raise SystemExit(str(e))
