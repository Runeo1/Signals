"""Run inside backend Docker container against its configured PostgreSQL.
Creates isolated uniquely named run records and rolls back all changes.
"""
import sys,uuid
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from app import db
assert db.db_kind()=='PostgreSQL', 'This check requires PostgreSQL'
db.init_db()
with db.SessionLocal() as s:
    try:
        key='verify-'+uuid.uuid4().hex[:12]
        run=db.SearchRun(id=key,query='Проверка PostgreSQL',mode='hybrid',status='done',sources=[],result={'items':[],'stats':{'top':0}})
        s.add(run);s.flush()
        s.add(db.RawDocument(run_id=key,title='Проверка UTF-8',source_id='test',url='https://example.org/test'))
        s.add(db.Candidate(run_id=key,name='Тестовый кандидат',probability=.1,is_weak_signal=False,excluded=True,payload={'reasons':['Тест']}))
        s.flush();s.expire_all()
        assert s.get(db.SearchRun,key).result['stats']['top']==0
        assert s.query(db.RawDocument).filter_by(run_id=key).one().title=='Проверка UTF-8'
        assert s.query(db.Candidate).filter_by(run_id=key).one().excluded is True
        print('PostgreSQL JSON, UTF-8, run/document/candidate persistence: OK')
    finally:s.rollback()
