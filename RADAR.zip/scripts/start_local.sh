#!/usr/bin/env bash
# Запуск справочника без Docker (Linux / macOS). Браузер откроется сам, когда сервер будет готов.
# Адрес: http://localhost:8000 (если порт занят — будет выбран 8001, 8002…; адрес печатается в консоли)
set -e
cd "$(dirname "$0")/../backend"
PY=${PYTHON:-python3}
command -v "$PY" >/dev/null || { echo "ОШИБКА: не найден $PY. Установите Python 3.14."; exit 1; }
"$PY" -c 'import sys; sys.exit(0 if sys.version_info[:2] == (3, 14) else 1)' || { echo "ОШИБКА: нужен Python 3.14."; exit 1; }
if [ ! -x .venv314/bin/python ]; then
  "$PY" -m venv .venv314 || { echo "ОШИБКА: не удалось создать .venv (Debian/Ubuntu: sudo apt install python3-venv)"; exit 1; }
fi
VPY=.venv314/bin/python
if ! "$VPY" -c "import fastapi, uvicorn, sqlalchemy, sklearn, pandas, numpy, httpx, bcrypt, jwt, openpyxl, wordfreq, multipart" 2>/dev/null; then
  echo "Устанавливаю зависимости (первый запуск, 2–5 минут)…"
  "$VPY" -m pip install -q --disable-pip-version-check --upgrade pip
  "$VPY" -m pip install --only-binary=:all: --disable-pip-version-check -r requirements.txt
fi
if [[ "${DATABASE_URL:-}" == postgresql* ]]; then "$VPY" -m pip install -q -r requirements-postgres.txt; fi
exec "$VPY" run.py
