// Демонстрационный стенд: backend доступен через прокси
window.RADAR_API = "port/8000";
